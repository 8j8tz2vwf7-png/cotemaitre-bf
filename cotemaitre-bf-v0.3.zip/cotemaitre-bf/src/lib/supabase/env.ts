/**
 * Lecture et VALIDATION de la configuration Supabase côté navigateur.
 *
 * Règle d'or : seules deux valeurs PUBLIQUES entrent dans le navigateur
 *   - VITE_SUPABASE_URL
 *   - VITE_SUPABASE_ANON_KEY  (clé « anon » ou « publishable »)
 * Tout ce qui est préfixé VITE_ est embarqué dans le JavaScript livré aux visiteurs.
 * Les clés privées (service_role / sb_secret_*, API-Football) ne doivent JAMAIS y figurer :
 * si une clé secrète est détectée ici, elle est REFUSÉE et l'application reste en démonstration.
 */

export type SupabaseEnvStatus =
  | { state: 'unconfigured'; reason: string }                 // variables absentes ou exemples non remplacés → mode démo
  | { state: 'invalid'; reason: string }                      // variables présentes mais dangereuses/incorrectes → mode démo
  | { state: 'configured'; url: string; anonKey: string };

export interface RawEnv {
  VITE_SUPABASE_URL?: string;
  VITE_SUPABASE_ANON_KEY?: string;
  VITE_FORCE_DEMO?: string;
}

const PLACEHOLDER = /your[-_ ]|xxxx|<[^>]*>|example\.|changeme|votre[-_ ]/i;

function decodeJwtPayload(token: string): Record<string, unknown> | null {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  try {
    const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
    return JSON.parse(atob(padded)) as Record<string, unknown>;
  } catch {
    return null;
  }
}

export function validateSupabaseEnv(raw: RawEnv): SupabaseEnvStatus {
  if ((raw.VITE_FORCE_DEMO ?? '').trim().toLowerCase() === 'true') {
    return { state: 'unconfigured', reason: 'Mode démonstration forcé (VITE_FORCE_DEMO=true).' };
  }
  const url = (raw.VITE_SUPABASE_URL ?? '').trim();
  const key = (raw.VITE_SUPABASE_ANON_KEY ?? '').trim();
  if (!url && !key) return { state: 'unconfigured', reason: 'Variables VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY absentes.' };
  if (!url || !key) return { state: 'invalid', reason: 'Configuration incomplète : il faut à la fois VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY.' };
  if (PLACEHOLDER.test(url) || PLACEHOLDER.test(key)) {
    return { state: 'unconfigured', reason: 'Valeurs d\'exemple non remplacées dans le fichier .env.' };
  }

  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return { state: 'invalid', reason: 'VITE_SUPABASE_URL n\'est pas une URL valide.' };
  }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname);
  if (parsed.protocol !== 'https:' && !(parsed.protocol === 'http:' && local)) {
    return { state: 'invalid', reason: 'VITE_SUPABASE_URL doit être en https (http n\'est toléré qu\'en local).' };
  }
  if (parsed.username || parsed.password) return { state: 'invalid', reason: 'VITE_SUPABASE_URL ne doit pas contenir d\'identifiants.' };

  if (key.startsWith('sb_secret_')) {
    return { state: 'invalid', reason: 'CLÉ SECRÈTE détectée dans VITE_SUPABASE_ANON_KEY : refusée. Utilisez la clé publique (anon / publishable).' };
  }
  const payload = decodeJwtPayload(key);
  if (payload) {
    if (payload.role === 'service_role') {
      return { state: 'invalid', reason: 'CLÉ SERVICE_ROLE détectée dans VITE_SUPABASE_ANON_KEY : refusée. Cette clé donne tous les droits et ne doit jamais être dans le navigateur.' };
    }
    if (payload.role !== 'anon') {
      return { state: 'invalid', reason: `La clé fournie n'a pas le rôle « anon » (rôle lu : ${String(payload.role)}).` };
    }
  } else if (!key.startsWith('sb_publishable_')) {
    return { state: 'invalid', reason: 'Format de clé non reconnu : attendu la clé « anon » (JWT) ou « publishable » (sb_publishable_…).' };
  }

  return { state: 'configured', url: parsed.origin, anonKey: key };
}

/** Lit les variables injectées par Vite (valeurs figées à la compilation). */
export function readSupabaseEnv(): SupabaseEnvStatus {
  // Accès EXPLICITES (pas d'alias de import.meta.env) : requis pour que l'outil de build remplace chaque valeur.
  return validateSupabaseEnv({
    VITE_SUPABASE_URL: import.meta.env.VITE_SUPABASE_URL,
    VITE_SUPABASE_ANON_KEY: import.meta.env.VITE_SUPABASE_ANON_KEY,
    VITE_FORCE_DEMO: import.meta.env.VITE_FORCE_DEMO,
  });
}

export const supabaseEnv: SupabaseEnvStatus = readSupabaseEnv();
if (supabaseEnv.state === 'invalid') {
  console.error('[COTEMAÎTRE BF] Configuration Supabase refusée — l\'application reste en mode démonstration. ' + supabaseEnv.reason);
}

/** Hôte affichable (sans chemin ni clé). */
export const supabaseHost = supabaseEnv.state === 'configured' ? new URL(supabaseEnv.url).host : null;
