/**
 * Client Supabase léger (fetch) : Auth (GoTrue) + REST (PostgREST) + RPC.
 *
 * Pourquoi pas @supabase/supabase-js ? Il n'a pas pu être installé ni vérifié dans l'environnement de
 * développement de l'étape 2 (registre npm inaccessible). Ce module couvre exactement les besoins actuels
 * (connexion e-mail/mot de passe, session persistante avec rafraîchissement, lecture/écriture avec RLS).
 * Il est isolé derrière cette interface : le remplacer par supabase-js ne touche que ce fichier et
 * src/services/auth.ts. Voir le README, section « Passer à supabase-js ».
 *
 * Sécurité :
 *  - n'utilise QUE la clé publique (anon/publishable) ; l'identité de l'utilisateur est portée par son JWT ;
 *  - les droits réels sont imposés par PostgreSQL (RLS + triggers), jamais par ce code ;
 *  - jeton de session stocké dans localStorage (comme supabase-js par défaut) : il reste donc exposé à toute faille XSS ;
 *    ne jamais injecter de HTML non maîtrisé dans l'application.
 */

export const SESSION_STORAGE_KEY = 'cotemaitre-bf-supabase-session';
/** Rafraîchir le jeton quand il reste moins de N secondes. */
export const REFRESH_MARGIN_S = 60;

export interface AuthUser { id: string; email: string }
export interface AuthSession {
  accessToken: string;
  refreshToken: string;
  /** Expiration, en secondes epoch. */
  expiresAt: number;
  user: AuthUser;
}
export type AuthEvent = 'SIGNED_IN' | 'SIGNED_OUT' | 'TOKEN_REFRESHED';

export class AuthError extends Error {
  constructor(message: string, readonly code: string, readonly status?: number) {
    super(message);
    this.name = 'AuthError';
  }
}
export class RestError extends Error {
  constructor(message: string, readonly code: string, readonly status: number, readonly details?: string) {
    super(message);
    this.name = 'RestError';
  }
}

type Query = Record<string, string | number | boolean | undefined>;

export interface SupabaseLite {
  readonly url: string;
  readonly auth: {
    signInWithPassword(email: string, password: string): Promise<AuthSession>;
    signOut(): Promise<void>;
    getSession(): Promise<AuthSession | null>;
    onAuthStateChange(cb: (event: AuthEvent, session: AuthSession | null) => void): () => void;
  };
  get<T>(table: string, query?: Query): Promise<T>;
  post<T>(table: string, body: unknown, query?: Query): Promise<T>;
  patch<T>(table: string, body: unknown, query: Query): Promise<T>;
  delete<T>(table: string, query: Query): Promise<T>;
  rpc<T>(fn: string, args?: Record<string, unknown>): Promise<T>;
  /** Vérifie que la base répond ET que les migrations sont installées (table publique subscription_plans). */
  ping(): Promise<{ ok: true } | { ok: false; reason: 'network' | 'schema' | 'auth' | 'other'; message: string }>;
}

const AUTH_MESSAGES: Record<string, string> = {
  invalid_credentials: 'Identifiants incorrects.',
  email_not_confirmed: 'Adresse e-mail non confirmée.',
  user_banned: 'Ce compte est suspendu.',
  over_request_rate_limit: 'Trop de tentatives : réessayez dans quelques minutes.',
  over_email_send_rate_limit: 'Trop de tentatives : réessayez dans quelques minutes.',
};

function qs(query?: Query): string {
  if (!query) return '';
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) if (v !== undefined) p.set(k, String(v));
  const s = p.toString();
  return s ? `?${s}` : '';
}

function safeStorage() {
  try { return window.localStorage; } catch { return null; }
}

export function createSupabaseLite(url: string, anonKey: string): SupabaseLite {
  const base = url.replace(/\/+$/, '');
  const listeners = new Set<(e: AuthEvent, s: AuthSession | null) => void>();
  let session: AuthSession | null = null;
  let loaded = false;
  let refreshing: Promise<AuthSession | null> | null = null;
  let timer: ReturnType<typeof setTimeout> | undefined;

  const emit = (e: AuthEvent) => listeners.forEach((cb) => { try { cb(e, session); } catch { /* un écouteur ne doit pas casser les autres */ } });

  const persist = () => {
    const st = safeStorage();
    try {
      if (!st) return;
      if (session) st.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
      else st.removeItem(SESSION_STORAGE_KEY);
    } catch { /* stockage indisponible : la session reste en mémoire */ }
  };

  const restore = () => {
    if (loaded) return;
    loaded = true;
    try {
      const raw = safeStorage()?.getItem(SESSION_STORAGE_KEY);
      if (!raw) return;
      const s = JSON.parse(raw) as Partial<AuthSession>;
      if (s && typeof s.accessToken === 'string' && typeof s.refreshToken === 'string' && typeof s.expiresAt === 'number' && s.user && typeof s.user.id === 'string') {
        session = s as AuthSession;
      }
    } catch { session = null; }
  };

  const schedule = () => {
    if (timer) clearTimeout(timer);
    if (!session) return;
    const ms = Math.max(1000, (session.expiresAt - REFRESH_MARGIN_S) * 1000 - Date.now());
    timer = setTimeout(() => { void refresh(); }, Math.min(ms, 2 ** 31 - 1));
  };

  const setSession = (s: AuthSession | null, event: AuthEvent | null) => {
    session = s;
    persist();
    schedule();
    if (event) emit(event);
  };

  const fromTokenResponse = (j: any): AuthSession => ({
    accessToken: String(j.access_token),
    refreshToken: String(j.refresh_token),
    expiresAt: typeof j.expires_at === 'number' ? j.expires_at : Math.floor(Date.now() / 1000) + Number(j.expires_in ?? 3600),
    user: { id: String(j.user?.id), email: String(j.user?.email ?? '') },
  });

  async function tokenRequest(grant: 'password' | 'refresh_token', body: Record<string, string>): Promise<AuthSession> {
    let res: Response;
    try {
      res = await fetch(`${base}/auth/v1/token?grant_type=${grant}`, {
        method: 'POST',
        headers: { apikey: anonKey, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
    } catch {
      throw new AuthError('Impossible de joindre le serveur d\'authentification.', 'network');
    }
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      const code = String(j.error_code ?? j.error ?? 'auth_error');
      throw new AuthError(AUTH_MESSAGES[code] ?? (res.status === 429 ? AUTH_MESSAGES.over_request_rate_limit : 'Échec de l\'authentification.'), code, res.status);
    }
    return fromTokenResponse(j);
  }

  function refresh(): Promise<AuthSession | null> {
    restore();
    if (!session) return Promise.resolve(null);
    if (refreshing) return refreshing;
    const rt = session.refreshToken;
    refreshing = tokenRequest('refresh_token', { refresh_token: rt })
      .then((s) => { setSession(s, 'TOKEN_REFRESHED'); return s; })
      .catch((e: unknown) => {
        // Jeton de rafraîchissement refusé : session terminée. Panne réseau : on garde la session et on réessaie plus tard.
        if (e instanceof AuthError && e.code !== 'network') setSession(null, 'SIGNED_OUT');
        else if (timer) { clearTimeout(timer); timer = setTimeout(() => { void refresh(); }, 15000); }
        return null;
      })
      .finally(() => { refreshing = null; });
    return refreshing;
  }

  async function currentToken(): Promise<string> {
    restore();
    if (!session) return anonKey;
    if (session.expiresAt - REFRESH_MARGIN_S <= Date.now() / 1000) {
      const s = await refresh();
      return s ? s.accessToken : session ? session.accessToken : anonKey;
    }
    return session.accessToken;
  }

  async function request<T>(method: string, path: string, opts: { query?: Query; body?: unknown; prefer?: string } = {}, retried = false): Promise<T> {
    const token = await currentToken();
    const headers: Record<string, string> = { apikey: anonKey, Authorization: `Bearer ${token}`, Accept: 'application/json' };
    if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
    if (opts.prefer) headers.Prefer = opts.prefer;
    let res: Response;
    try {
      res = await fetch(`${base}/rest/v1/${path}${qs(opts.query)}`, { method, headers, body: opts.body === undefined ? undefined : JSON.stringify(opts.body) });
    } catch {
      throw new RestError('Impossible de joindre la base de données.', 'network', 0);
    }
    if (res.status === 401 && !retried && session) {
      const s = await refresh();
      if (s) return request<T>(method, path, opts, true);
    }
    const text = await res.text();
    const j = text ? (JSON.parse(text) as unknown) : null;
    if (!res.ok) {
      const e = (j ?? {}) as { code?: string; message?: string; details?: string };
      throw new RestError(e.message ?? `Erreur ${res.status}`, e.code ?? String(res.status), res.status, e.details);
    }
    return j as T;
  }

  // Synchronisation entre onglets : une déconnexion dans un onglet s'applique aux autres.
  if (typeof window !== 'undefined') {
    window.addEventListener('storage', (ev) => {
      if (ev.key !== SESSION_STORAGE_KEY) return;
      const had = !!session;
      loaded = false; session = null; restore(); schedule();
      if (had && !session) emit('SIGNED_OUT');
      else if (!had && session) emit('SIGNED_IN');
    });
  }

  return {
    url: base,
    auth: {
      async signInWithPassword(email, password) {
        const s = await tokenRequest('password', { email: email.trim(), password });
        setSession(s, 'SIGNED_IN');
        return s;
      },
      async signOut() {
        restore();
        const token = session?.accessToken;
        setSession(null, 'SIGNED_OUT');
        if (token) {
          try { await fetch(`${base}/auth/v1/logout`, { method: 'POST', headers: { apikey: anonKey, Authorization: `Bearer ${token}` } }); } catch { /* déjà déconnecté localement */ }
        }
      },
      async getSession() {
        restore();
        if (!session) return null;
        if (session.expiresAt - REFRESH_MARGIN_S <= Date.now() / 1000) return refresh();
        schedule();
        return session;
      },
      onAuthStateChange(cb) {
        listeners.add(cb);
        return () => { listeners.delete(cb); };
      },
    },
    get: <T,>(table: string, query?: Query) => request<T>('GET', table, { query }),
    post: <T,>(table: string, body: unknown, query?: Query) => request<T>('POST', table, { body, query, prefer: 'return=representation' }),
    patch: <T,>(table: string, body: unknown, query: Query) => request<T>('PATCH', table, { body, query, prefer: 'return=representation' }),
    delete: <T,>(table: string, query: Query) => request<T>('DELETE', table, { query, prefer: 'return=representation' }),
    rpc: <T,>(fn: string, args: Record<string, unknown> = {}) => request<T>('POST', `rpc/${fn}`, { body: args }),
    async ping() {
      try {
        await request<unknown>('GET', 'subscription_plans', { query: { select: 'id', limit: 1 } });
        return { ok: true as const };
      } catch (e) {
        if (!(e instanceof RestError)) return { ok: false as const, reason: 'other' as const, message: 'Erreur inattendue.' };
        if (e.code === 'network') return { ok: false as const, reason: 'network' as const, message: e.message };
        if (e.status === 401 || e.status === 403) return { ok: false as const, reason: 'auth' as const, message: 'Clé publique refusée par le serveur.' };
        if (e.code === '42P01' || e.code === 'PGRST205' || e.status === 404) return { ok: false as const, reason: 'schema' as const, message: 'Base joignable, mais le schéma n\'est pas installé : exécutez les migrations SQL.' };
        return { ok: false as const, reason: 'other' as const, message: e.message };
      }
    },
  };
}
