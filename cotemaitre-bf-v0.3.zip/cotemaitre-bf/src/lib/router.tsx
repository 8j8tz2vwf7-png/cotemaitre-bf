import { useEffect, useState, type ReactNode } from 'react';

// Routeur minimaliste basé sur le hash (#/chemin) : aucune dépendance,
// compatible avec n'importe quel hébergement statique.
const read = () => (window.location.hash.replace(/^#/, '') || '/').split('?')[0];

export function useRoute() {
  const [path, setPath] = useState(read());
  useEffect(() => {
    const f = () => {
      setPath(read());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener('hashchange', f);
    return () => window.removeEventListener('hashchange', f);
  }, []);
  return path;
}

export const navigate = (to: string) => {
  window.location.hash = to;
};

export function Link(props: { to: string; className?: string; children?: ReactNode; onClick?: () => void }) {
  return (
    <a href={'#' + props.to} className={props.className} onClick={props.onClick}>
      {props.children}
    </a>
  );
}
