import type { Prediction } from '../types';
import { MARKET_LABEL } from '../types';

export interface Perf {
  won: number;
  lost: number;
  void: number;
  settled: number;
  winRate: number | null; // gagnés / (gagnés + perdus)
  staked: number;
  profit: number;
  roi: number | null; // null si cotes/mises non renseignées
  withOdds: number;
}

/** Un pronostic compte dans les stats uniquement s'il est publié ET soldé. */
export const isSettled = (p: Prediction) => p.published && p.review === 'validated' && p.result !== 'pending';

export function computePerf(preds: Prediction[]): Perf {
  const s = preds.filter(isSettled);
  const won = s.filter((p) => p.result === 'won').length;
  const lost = s.filter((p) => p.result === 'lost').length;
  const voided = s.filter((p) => p.result === 'void').length;
  let staked = 0;
  let profit = 0;
  let withOdds = 0;
  for (const p of s) {
    if (p.odds && p.stake && p.result !== 'void') {
      withOdds++;
      staked += p.stake;
      profit += p.result === 'won' ? p.stake * (p.odds - 1) : -p.stake;
    }
  }
  return {
    won,
    lost,
    void: voided,
    settled: s.length,
    winRate: won + lost > 0 ? won / (won + lost) : null,
    staked,
    profit,
    roi: staked > 0 ? profit / staked : null,
    withOdds,
  };
}

export function groupPerf(preds: Prediction[], key: (p: Prediction) => string) {
  const map = new Map<string, Prediction[]>();
  for (const p of preds.filter(isSettled)) {
    const k = key(p);
    map.set(k, [...(map.get(k) ?? []), p]);
  }
  return [...map.entries()]
    .map(([name, list]) => ({ name, ...computePerf(list) }))
    .sort((a, b) => b.settled - a.settled);
}

export const byLeague = (preds: Prediction[]) => groupPerf(preds, (p) => p.league);
export const byMarket = (preds: Prediction[]) => groupPerf(preds, (p) => MARKET_LABEL[p.market]);

/** Courbe de profit cumulé (unités) dans l'ordre chronologique. */
export function profitCurve(preds: Prediction[]) {
  const s = preds
    .filter((p) => isSettled(p) && p.odds && p.stake && p.result !== 'void')
    .sort((a, b) => a.kickoff.localeCompare(b.kickoff));
  let acc = 0;
  return s.map((p) => {
    acc += p.result === 'won' ? p.stake! * (p.odds! - 1) : -p.stake!;
    return { at: p.kickoff, value: acc };
  });
}

/** Évalue un pari à partir du score final. null = non évaluable. */
export function evaluatePick(market: string, pick: string, hg: number, ag: number): 'won' | 'lost' | null {
  const total = hg + ag;
  const w = (c: boolean) => (c ? 'won' : 'lost') as 'won' | 'lost';
  switch (pick) {
    case 'Victoire domicile': return w(hg > ag);
    case 'Match nul': return w(hg === ag);
    case 'Victoire extérieure': return w(ag > hg);
    case '1X': return w(hg >= ag);
    case 'X2': return w(ag >= hg);
    case '12': return w(hg !== ag);
    case 'Plus de 1,5 buts': return w(total > 1.5);
    case 'Moins de 1,5 buts': return w(total < 1.5);
    case 'Plus de 2,5 buts': return w(total > 2.5);
    case 'Moins de 2,5 buts': return w(total < 2.5);
    case 'Plus de 3,5 buts': return w(total > 3.5);
    case 'Moins de 3,5 buts': return w(total < 3.5);
    case 'Les deux équipes marquent : Oui': return w(hg > 0 && ag > 0);
    case 'Les deux équipes marquent : Non': return w(!(hg > 0 && ag > 0));
    default: return market ? null : null;
  }
}
