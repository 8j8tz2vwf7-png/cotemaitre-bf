const FR = 'fr-FR';

export const fmtTime = (iso: string) =>
  new Date(iso).toLocaleTimeString(FR, { hour: '2-digit', minute: '2-digit' });

export const fmtDayLong = (iso: string | Date) => {
  const s = new Date(iso).toLocaleDateString(FR, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  return s.charAt(0).toUpperCase() + s.slice(1);
};

export const fmtDayMid = (iso: string) => {
  const s = new Date(iso).toLocaleDateString(FR, { weekday: 'long', day: 'numeric', month: 'long' });
  return s.charAt(0).toUpperCase() + s.slice(1);
};

export const fmtShort = (iso: string) =>
  new Date(iso).toLocaleDateString(FR, { day: '2-digit', month: 'short' });

export const fmtDateTime = (iso: string) =>
  new Date(iso).toLocaleString(FR, { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });

export const fmtYear = (iso: string) => new Date(iso).toLocaleDateString(FR, { month: 'short', year: 'numeric' });

export const pct = (n: number, d = 0) => (n * 100).toFixed(d).replace('.', ',') + ' %';
export const num = (n: number, d = 2) => n.toFixed(d).replace('.', ',');
export const signed = (n: number, d = 2) => (n > 0 ? '+' : '') + num(n, d);

export function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

/** Nombre de jours (locaux) entre aujourd'hui et la date ISO. */
export function dayDiff(iso: string) {
  const a = startOfDay(new Date()).getTime();
  const b = startOfDay(new Date(iso)).getTime();
  return Math.round((b - a) / 86400000);
}

export const uid = (p = 'id') => p + '_' + Math.random().toString(36).slice(2, 9);
