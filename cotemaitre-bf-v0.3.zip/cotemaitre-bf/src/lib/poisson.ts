import type { Probabilities } from '../types';

const fact = (n: number): number => (n <= 1 ? 1 : n * fact(n - 1));
const pois = (k: number, l: number) => (Math.exp(-l) * Math.pow(l, k)) / fact(k);

/**
 * Modèle de Poisson indépendant (version de démonstration du futur moteur).
 * Entrées : buts attendus domicile / extérieur. Sorties : probabilités de marchés.
 */
export function computeProbabilities(lambdaHome: number, lambdaAway: number, maxGoals = 8): Probabilities {
  let home = 0, draw = 0, away = 0, btts = 0, o15 = 0, o25 = 0, o35 = 0, total = 0;
  const scores: { score: string; p: number }[] = [];
  for (let h = 0; h <= maxGoals; h++) {
    for (let a = 0; a <= maxGoals; a++) {
      const p = pois(h, lambdaHome) * pois(a, lambdaAway);
      total += p;
      if (h > a) home += p; else if (h === a) draw += p; else away += p;
      if (h > 0 && a > 0) btts += p;
      if (h + a > 1.5) o15 += p;
      if (h + a > 2.5) o25 += p;
      if (h + a > 3.5) o35 += p;
      scores.push({ score: `${h}-${a}`, p });
    }
  }
  const n = (x: number) => x / total;
  scores.sort((x, y) => y.p - x.p);
  return {
    home: n(home),
    draw: n(draw),
    away: n(away),
    dc1X: n(home + draw),
    dcX2: n(draw + away),
    dc12: n(home + away),
    over: { '1.5': n(o15), '2.5': n(o25), '3.5': n(o35) },
    btts: n(btts),
    scores: scores.slice(0, 6).map((s) => ({ score: s.score, p: n(s.p) })),
    lambdaHome,
    lambdaAway,
  };
}
