import { supabaseClient } from '../services/auth';

/**
 * Mode de données de l'application.
 *  - 'live' : Supabase est configuré → TOUTES les données viennent de la base (aucune donnée de démonstration affichée).
 *  - 'demo' : Supabase non configuré → données fictives locales, clairement signalées.
 * Le mode ne dit rien sur une API sportive : voir `sportsSource.ts` (mode manuel tant qu'aucune API n'est branchée).
 */
export const LIVE = supabaseClient !== null;
export const dataMode: 'demo' | 'live' = LIVE ? 'live' : 'demo';
