/// <reference types="vite/client" />

// Variables PUBLIQUES uniquement : tout ce qui commence par VITE_ est embarqué dans le navigateur.
interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_ANON_KEY?: string;
  readonly VITE_FORCE_DEMO?: string;
}
