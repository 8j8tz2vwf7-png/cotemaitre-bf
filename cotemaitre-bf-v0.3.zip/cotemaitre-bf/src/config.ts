/**
 * Configuration publique du front (AUCUN secret ici).
 * Les clés API-Football / Supabase service-role ne doivent JAMAIS être
 * placées dans une variable VITE_* : tout ce qui est VITE_* est visible
 * dans le navigateur.
 */
export const CONFIG = {
  /** Intervalle prévu du scanner automatique (exécuté côté serveur). */
  scanIntervalMinutes: 15,
  storageKey: 'cotemaitre-bf-demo-v1',
};

