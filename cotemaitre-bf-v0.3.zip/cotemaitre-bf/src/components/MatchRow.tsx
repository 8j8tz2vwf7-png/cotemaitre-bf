import type { Match } from '../types';
import { Badge, Icon, TeamCrest } from './ui';
import { Link } from '../lib/router';
import { useData } from '../store/DataContext';
import { fmtTime } from '../lib/format';

export function StatusBadge({ m }: { m: Match }) {
  if (m.status === 'finished') return <Badge tone="slate">Terminé</Badge>;
  if (m.status === 'postponed') return <Badge tone="red">Reporté</Badge>;
  if (m.status === 'cancelled') return <Badge tone="red">Annulé</Badge>;
  if (m.status === 'live') return <Badge tone="amber">En cours</Badge>;
  return <Badge tone="emerald">Programmé</Badge>;
}

export function MatchRow({ m, showLeague = false, predCount = 0 }: { m: Match; showLeague?: boolean; predCount?: number }) {
  const d = useData();
  const h = d.team(m.homeId);
  const a = d.team(m.awayId);
  const finished = m.status === 'finished';
  return (
    <Link to={`/analyse/${m.id}`}
      className="group block rounded-xl border border-line bg-ink-900/60 p-3 transition hover:border-emerald-500/40 hover:bg-ink-800/80 sm:p-4">
      <div className="flex items-center gap-3 sm:gap-4">
        <div className="hidden w-14 shrink-0 text-center sm:block">
          <div className="font-mono text-sm font-semibold text-white">{fmtTime(m.kickoff)}</div>
        </div>
        <div className="grid min-w-0 flex-1 grid-cols-[1fr_auto_1fr] items-center gap-2 sm:gap-3">
          <div className="flex min-w-0 items-center justify-end gap-2 text-right">
            <span className="truncate text-sm font-semibold text-white">{h.name}</span>
            <TeamCrest team={h} size={32} />
          </div>
          <div className="min-w-[52px] text-center">
            {finished
              ? <span className="font-display text-lg font-bold text-white">{m.homeGoals} – {m.awayGoals}</span>
              : <span className="text-xs font-semibold text-slate-500">VS</span>}
          </div>
          <div className="flex min-w-0 items-center gap-2">
            <TeamCrest team={a} size={32} />
            <span className="truncate text-sm font-semibold text-white">{a.name}</span>
          </div>
        </div>
        <div className="hidden shrink-0 flex-col items-end gap-1 sm:flex">
          <StatusBadge m={m} />
          {predCount > 0 && <Badge tone="gold">{predCount} pronostic{predCount > 1 ? 's' : ''}</Badge>}
        </div>
        <Icon name="arrow" className="size-4 shrink-0 text-slate-600 transition group-hover:translate-x-0.5 group-hover:text-emerald-400" />
      </div>
      <div className="mt-2 flex items-center gap-2 sm:hidden">
        <span className="font-mono text-xs font-semibold text-white">{fmtTime(m.kickoff)}</span>
        <StatusBadge m={m} />
        {predCount > 0 && <Badge tone="gold">{predCount} pronostic{predCount > 1 ? 's' : ''}</Badge>}
        {showLeague && <span className="truncate text-[11px] text-slate-500">{d.league(m.leagueId).name}</span>}
      </div>
      {showLeague && <div className="mt-2 hidden pl-[68px] text-[11px] text-slate-500 sm:block">{d.league(m.leagueId).name}</div>}
    </Link>
  );
}
