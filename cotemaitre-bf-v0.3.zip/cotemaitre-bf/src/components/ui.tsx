import { useEffect, useId, type ReactNode } from 'react';
import { LIVE } from '../lib/mode';
import type { Result, Team } from '../types';
import { pct } from '../lib/format';

// ───────────── Icônes ─────────────
const ICONS = {
  home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',
  calendar: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',
  bot: 'M5 8h14v10H5zM12 4v4M9 13h.01M15 13h.01M9 16h6',
  target: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 8a4 4 0 100 8 4 4 0 000-8zM12 12h.01',
  history: 'M3 12a9 9 0 109-9 9 9 0 00-6.4 2.6L3 8M3 3v5h5M12 7v5l3 2',
  shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
  lock: 'M6 11h12v9H6zM8 11V8a4 4 0 018 0v3',
  crown: 'M3 8l4 4 5-7 5 7 4-4-2 11H5z',
  check: 'M5 12l5 5 9-10',
  x: 'M6 6l12 12M18 6L6 18',
  edit: 'M4 20h4L19 9l-4-4L4 16zM13 7l4 4',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 100 6 3 3 0 000-6z',
  eyeoff: 'M3 3l18 18M10 6.2A9 9 0 0112 6c6 0 10 6 10 6a17 17 0 01-3 3.6M6.5 7.5A17 17 0 002 12s4 6 10 6c1.5 0 2.8-.4 4-.9',
  refresh: 'M20 11a8 8 0 00-14-4L4 9M4 4v5h5M4 13a8 8 0 0014 4l2-2M20 20v-5h-5',
  menu: 'M4 7h16M4 12h16M4 17h16',
  chart: 'M4 20V4M4 20h16M8 16v-5M12 16V8M16 16v-8',
  trophy: 'M8 4h8v6a4 4 0 01-8 0zM8 6H4v2a3 3 0 003 3M16 6h4v2a3 3 0 01-3 3M12 14v4M8 20h8',
  alert: 'M12 3l10 18H2zM12 10v5M12 18h.01',
  logout: 'M10 4H5v16h5M15 8l4 4-4 4M19 12H9',
  server: 'M4 5h16v5H4zM4 14h16v5H4zM8 7.5h.01M8 16.5h.01',
  plus: 'M12 5v14M5 12h14',
  info: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 11v5M12 8h.01',
  user: 'M12 4a4 4 0 100 8 4 4 0 000-8zM4 21c0-4 4-6 8-6s8 2 8 6',
  arrow: 'M5 12h14M13 6l6 6-6 6',
  clock: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7v5l3 2',
} as const;
export type IconName = keyof typeof ICONS;

export function Icon({ name, className = 'size-5' }: { name: IconName; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d={ICONS[name]} />
    </svg>
  );
}

// ───────────── Logo ─────────────
export function LogoMark({ size = 38 }: { size?: number }) {
  const id = useId().replace(/:/g, '');
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id={`g${id}`} x1="6" y1="4" x2="42" y2="44">
          <stop stopColor="#34d399" />
          <stop offset="0.55" stopColor="#10b981" />
          <stop offset="1" stopColor="#d4af37" />
        </linearGradient>
      </defs>
      <path d="M24 3l18 10.5v21L24 45 6 34.5v-21z" fill="#06100c" stroke={`url(#g${id})`} strokeWidth="2" />
      <circle cx="24" cy="24" r="10.5" stroke={`url(#g${id})`} strokeWidth="1.6" />
      <path d="M24 17.5l6 4.4-2.3 7h-7.4l-2.3-7z" fill={`url(#g${id})`} />
      <path d="M24 17.5V13.5M30 21.9l3.8-1.2M27.7 28.9l2.4 3.3M20.3 28.9l-2.4 3.3M18 21.9l-3.8-1.2" stroke={`url(#g${id})`} strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <LogoMark size={compact ? 32 : 40} />
      <div className="leading-none">
        <div className="font-display text-[15px] font-extrabold tracking-[0.14em] text-white">
          COTEMAÎTRE <span className="gold-text">BF</span>
        </div>
        {!compact && <div className="mt-1.5 text-[9px] font-medium tracking-[0.18em] text-emerald-400/80">L'INTELLIGENCE AU SERVICE DU FOOTBALL.</div>}
      </div>
    </div>
  );
}

// ───────────── Briques ─────────────
export function Card({ children, className = '', gold = false }: { children?: ReactNode; className?: string; gold?: boolean }) {
  return (
    <div className={`rounded-2xl border ${gold ? 'border-gold-500/30 bg-gradient-to-br from-gold-500/[0.07] to-ink-900/80' : 'border-line bg-ink-900/70'} p-4 backdrop-blur sm:p-5 ${className}`}>
      {children}
    </div>
  );
}

type Tone = 'emerald' | 'gold' | 'red' | 'slate' | 'amber' | 'blue';
const TONES: Record<Tone, string> = {
  emerald: 'bg-emerald-500/10 text-emerald-300 ring-emerald-500/30',
  gold: 'bg-gold-500/10 text-gold-300 ring-gold-500/40',
  red: 'bg-red-500/10 text-red-300 ring-red-500/30',
  slate: 'bg-white/5 text-slate-300 ring-white/10',
  amber: 'bg-amber-500/10 text-amber-300 ring-amber-500/30',
  blue: 'bg-sky-500/10 text-sky-300 ring-sky-500/30',
};
export function Badge({ children, tone = 'slate', className = '' }: { children?: ReactNode; tone?: Tone; className?: string }) {
  return <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1 ring-inset ${TONES[tone]} ${className}`}>{children}</span>;
}

/** Affiché seulement en démonstration : en mode réel (Supabase configuré) rien n'est fictif. */
export const DemoBadge = ({ label = 'DÉMO' }: { label?: string }) => (LIVE ? null : <Badge tone="amber">{label}</Badge>);

export function ResultBadge({ r }: { r: Result }) {
  const map: Record<Result, [Tone, string]> = { won: ['emerald', 'Gagné'], lost: ['red', 'Perdu'], void: ['slate', 'Annulé'], pending: ['blue', 'En attente'] };
  return <Badge tone={map[r][0]}>{map[r][1]}</Badge>;
}

type BtnVariant = 'primary' | 'gold' | 'ghost' | 'danger' | 'outline';
const BTN: Record<BtnVariant, string> = {
  primary: 'bg-emerald-500 text-ink-950 hover:bg-emerald-400 shadow-[0_0_24px_-6px_rgba(16,185,129,0.7)]',
  gold: 'bg-gradient-to-r from-gold-600 via-gold-400 to-gold-500 text-ink-950 hover:brightness-110 shadow-[0_0_24px_-6px_rgba(212,175,55,0.7)]',
  ghost: 'text-slate-300 hover:bg-white/5',
  danger: 'bg-red-500/10 text-red-300 ring-1 ring-inset ring-red-500/30 hover:bg-red-500/20',
  outline: 'text-emerald-300 ring-1 ring-inset ring-emerald-500/40 hover:bg-emerald-500/10',
};
export function Button(props: {
  children?: ReactNode; onClick?: () => void; variant?: BtnVariant; size?: 'sm' | 'md' | 'lg';
  disabled?: boolean; className?: string; type?: 'button' | 'submit'; title?: string;
}) {
  const { variant = 'primary', size = 'md', className = '', type = 'button' } = props;
  const sz = size === 'sm' ? 'px-2.5 py-1.5 text-xs' : size === 'lg' ? 'px-6 py-3.5 text-sm' : 'px-4 py-2.5 text-sm';
  return (
    <button type={type} title={props.title} disabled={props.disabled} onClick={props.onClick}
      className={`inline-flex cursor-pointer items-center justify-center gap-2 rounded-xl font-semibold transition active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-50 ${sz} ${BTN[variant]} ${className}`}>
      {props.children}
    </button>
  );
}

export function StatCard({ label, value, hint, tone = 'emerald', icon }: { label: string; value: ReactNode; hint?: string; tone?: 'emerald' | 'gold'; icon: IconName }) {
  return (
    <div className="animate-fade-up rounded-2xl border border-line bg-ink-900/70 p-4">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">{label}</span>
        <span className={tone === 'gold' ? 'text-gold-400' : 'text-emerald-400'}><Icon name={icon} className="size-4" /></span>
      </div>
      <div className={`mt-2 font-display text-3xl font-bold ${tone === 'gold' ? 'gold-text' : 'text-white'}`}>{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-500">{hint}</div>}
    </div>
  );
}

export function PageHeader({ title, subtitle, right }: { title: string; subtitle?: string; right?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-2xl font-bold text-white sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 max-w-2xl text-sm text-slate-400">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

export function SectionTitle({ children, right }: { children?: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-2">
      <h2 className="font-display text-sm font-semibold uppercase tracking-wider text-emerald-300">{children}</h2>
      {right}
    </div>
  );
}

export function Tabs<T extends string>({ value, onChange, items }: { value: T; onChange: (v: T) => void; items: { id: T; label: string; count?: number; gold?: boolean }[] }) {
  return (
    <div className="-mx-1 mb-5 flex gap-1 overflow-x-auto px-1 pb-1">
      {items.map((it) => {
        const on = it.id === value;
        const activeCls = it.gold ? 'bg-gold-500/15 text-gold-300 ring-gold-500/40' : 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/40';
        return (
          <button key={it.id} onClick={() => onChange(it.id)}
            className={`flex cursor-pointer items-center gap-2 whitespace-nowrap rounded-xl px-3.5 py-2 text-sm font-semibold ring-1 ring-inset transition ${on ? activeCls : 'text-slate-400 ring-transparent hover:bg-white/5'}`}>
            {it.label}
            {it.count !== undefined && <span className="rounded-md bg-white/10 px-1.5 text-[11px]">{it.count}</span>}
          </button>
        );
      })}
    </div>
  );
}

export function Empty({ icon = 'info', title, text, action }: { icon?: IconName; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed border-line px-6 py-10 text-center">
      <span className="mb-3 text-slate-500"><Icon name={icon} className="size-8" /></span>
      <div className="font-semibold text-slate-200">{title}</div>
      {text && <p className="mt-1 max-w-md text-sm text-slate-500">{text}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function TeamCrest({ team, size = 36 }: { team: Team; size?: number }) {
  // Pas de logo réel en démo : écusson généré. Avec l'API, `team.logoUrl` est utilisé.
  if (team.logoUrl) return <img src={team.logoUrl} alt={team.name} width={size} height={size} className="shrink-0 object-contain" />;
  return (
    <span className="grid shrink-0 place-items-center rounded-xl font-display text-[11px] font-bold tracking-wide text-white ring-1 ring-white/15"
      style={{ width: size, height: size, background: `linear-gradient(145deg, hsl(${team.hue} 60% 32%), hsl(${team.hue} 55% 16%))` }}>
      {team.short}
    </span>
  );
}

export function FormChips({ results }: { results: ('W' | 'D' | 'L')[] }) {
  const cls = { W: 'bg-emerald-500 text-ink-950', D: 'bg-slate-500 text-white', L: 'bg-red-500 text-white' };
  const lab = { W: 'V', D: 'N', L: 'D' };
  return (
    <div className="flex gap-1">
      {results.map((r, i) => (
        <span key={i} className={`grid size-6 place-items-center rounded-md text-[11px] font-bold ${cls[r]}`}>{lab[r]}</span>
      ))}
    </div>
  );
}

export function ProbBar({ label, value, tone = 'emerald', highlight = false }: { label: string; value: number; tone?: 'emerald' | 'gold' | 'slate'; highlight?: boolean }) {
  const bar = tone === 'gold' ? 'bg-gold-500' : tone === 'slate' ? 'bg-slate-500' : 'bg-emerald-500';
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs">
        <span className={highlight ? 'font-semibold text-white' : 'text-slate-300'}>{label}</span>
        <span className="font-mono text-slate-200">{pct(value, 1)}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-white/5">
        <div className={`bar-grow h-full rounded-full ${bar}`} style={{ width: `${Math.max(1, value * 100)}%` }} />
      </div>
    </div>
  );
}

export function Modal({ open, onClose, title, children, wide = false }: { open: boolean; onClose: () => void; title: string; children?: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const f = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', f);
    return () => window.removeEventListener('keydown', f);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-4" onClick={onClose}>
      <div className={`animate-pop max-h-[92vh] w-full overflow-y-auto rounded-t-3xl border border-line bg-ink-900 p-5 sm:rounded-3xl ${wide ? 'sm:max-w-2xl' : 'sm:max-w-lg'}`} onClick={(e: { stopPropagation(): void }) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label={title}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-display text-lg font-bold text-white">{title}</h3>
          <button onClick={onClose} className="cursor-pointer rounded-lg p-1.5 text-slate-400 hover:bg-white/10" aria-label="Fermer"><Icon name="x" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

const inputCls = 'w-full rounded-xl border border-line bg-ink-950/80 px-3 py-2.5 text-sm text-white outline-none transition placeholder:text-slate-600 focus:border-emerald-500/60 focus:ring-2 focus:ring-emerald-500/20';

export function Field({ label, children, hint }: { label: string; children?: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-slate-500">{hint}</span>}
    </label>
  );
}
export function TextInput(props: { value: string; onChange: (v: string) => void; type?: string; placeholder?: string; autoFocus?: boolean; step?: string; min?: string }) {
  return <input className={inputCls} type={props.type ?? 'text'} value={props.value} placeholder={props.placeholder} autoFocus={props.autoFocus} step={props.step} min={props.min} onChange={(e: { target: { value: string } }) => props.onChange(e.target.value)} />;
}
export function TextArea(props: { value: string; onChange: (v: string) => void; rows?: number; placeholder?: string; autoFocus?: boolean }) {
  return <textarea className={inputCls} rows={props.rows ?? 4} value={props.value} placeholder={props.placeholder} autoFocus={props.autoFocus} onChange={(e: { target: { value: string } }) => props.onChange(e.target.value)} />;
}
export function Select(props: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[] }) {
  return (
    <select className={inputCls} value={props.value} onChange={(e: { target: { value: string } }) => props.onChange(e.target.value)}>
      {props.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

export function DemoBanner({ compact = false }: { compact?: boolean }) {
  if (LIVE) return null;
  return (
    <div className="flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/[0.07] px-4 py-3 text-amber-200">
      <span className="mt-0.5 shrink-0 text-amber-400"><Icon name="alert" className="size-4" /></span>
      <p className="text-xs leading-relaxed">
        <strong className="tracking-wide">MODE DÉMONSTRATION</strong>
        {compact ? ' — données fictives.' : ' — équipes, scores, statistiques et probabilités sont fictifs. Aucune connexion à API-Football ni à Supabase n\'est active : rien ici ne provient du monde réel.'}
      </p>
    </div>
  );
}

export function Toasts({ toasts }: { toasts: { id: number; text: string; kind: 'ok' | 'err' | 'info' }[] }) {
  const cls = { ok: 'border-emerald-500/40 text-emerald-200', err: 'border-red-500/40 text-red-200', info: 'border-sky-500/40 text-sky-200' };
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[60] flex flex-col items-center gap-2 px-4" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`animate-pop pointer-events-auto max-w-md rounded-xl border bg-ink-800/95 px-4 py-3 text-sm shadow-2xl backdrop-blur ${cls[t.kind]}`}>{t.text}</div>
      ))}
    </div>
  );
}
