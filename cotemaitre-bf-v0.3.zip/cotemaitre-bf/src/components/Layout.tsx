import { useState, type ReactNode } from 'react';
import { Icon, Logo, Toasts, type IconName, Badge } from './ui';
import { Link, navigate } from '../lib/router';
import { useApp } from '../store/AppStore';
import { fmtDayLong } from '../lib/format';
import { LIVE } from '../lib/mode';

const NAV: { to: string; label: string; icon: IconName }[] = [
  { to: '/', label: 'Tableau de bord', icon: 'home' },
  { to: '/matchs', label: 'Matchs', icon: 'calendar' },
  { to: '/bot', label: 'AI Football Bot', icon: 'bot' },
  { to: '/pronostics', label: 'Pronostics', icon: 'target' },
  { to: '/historique', label: 'Historique & performances', icon: 'history' },
  { to: '/admin', label: 'Espace administrateur', icon: 'shield' },
  { to: '/donnees', label: 'Données sportives', icon: 'chart' },
];

export function Layout({ path, children }: { path: string; children?: ReactNode }) {
  const [open, setOpen] = useState(false);
  const app = useApp();
  const active = (to: string) => (to === '/' ? path === '/' : path.startsWith(to));

  const nav = (
    <nav className="flex flex-col gap-1">
      {NAV.map((n) => (
        <Link key={n.to} to={n.to} onClick={() => setOpen(false)}
          className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${active(n.to) ? 'bg-emerald-500/15 text-emerald-300 ring-1 ring-inset ring-emerald-500/30' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}>
          <Icon name={n.icon} className="size-[18px]" />
          {n.label}
          {(n.to === '/admin' || n.to === '/donnees') && !app.isAdmin && <Icon name="lock" className="ml-auto size-3.5 text-slate-600" />}
        </Link>
      ))}
    </nav>
  );

  const account = app.session ? (
    <div className="rounded-xl border border-line bg-ink-800/60 p-3">
      <div className="flex items-center gap-2 text-xs text-slate-300">
        <Icon name="user" className="size-4 text-emerald-400" />
        <span className="truncate">{app.session.email}</span>
      </div>
      <button onClick={() => { app.logout(); setOpen(false); navigate('/'); }}
        className="mt-2 flex w-full cursor-pointer items-center justify-center gap-2 rounded-lg py-1.5 text-xs font-semibold text-slate-400 hover:bg-white/5 hover:text-white">
        <Icon name="logout" className="size-4" /> Se déconnecter
      </button>
    </div>
  ) : (
    <Link to="/connexion" onClick={() => setOpen(false)}
      className="flex items-center justify-center gap-2 rounded-xl border border-line bg-ink-800/60 py-2.5 text-sm font-semibold text-slate-200 hover:border-emerald-500/40">
      <Icon name="lock" className="size-4" /> Connexion admin
    </Link>
  );

  return (
    <div className="min-h-screen lg:pl-72">
      {/* Barre latérale (desktop) */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-72 flex-col border-r border-line bg-ink-950/90 p-5 backdrop-blur lg:flex">
        <Link to="/"><Logo /></Link>
        <div className="mt-8 flex-1">{nav}</div>
        <div className="space-y-3">
          {!LIVE && <Badge tone="amber" className="w-full justify-center py-1.5">MODE DÉMONSTRATION</Badge>}
          {account}
        </div>
      </aside>

      {/* Barre supérieure (mobile / tablette) */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-line bg-ink-950/90 px-4 py-3 backdrop-blur lg:hidden" style={{ paddingTop: 'max(0.75rem, env(safe-area-inset-top))' }}>
        <Link to="/"><Logo compact /></Link>
        <button onClick={() => setOpen(!open)} aria-label="Menu" aria-expanded={open}
          className="cursor-pointer rounded-xl border border-line p-2 text-slate-200">
          <Icon name={open ? 'x' : 'menu'} />
        </button>
      </header>
      {open && (
        <div className="animate-pop fixed inset-x-0 top-[57px] z-20 max-h-[calc(100vh-57px)] overflow-y-auto border-b border-line bg-ink-950/98 p-4 backdrop-blur lg:hidden">
          {nav}
          <div className="mt-4 space-y-3">
            {!LIVE && <Badge tone="amber" className="w-full justify-center py-1.5">MODE DÉMONSTRATION</Badge>}
            {account}
          </div>
        </div>
      )}

      <main className="mx-auto max-w-6xl px-4 pb-24 pt-6 sm:px-6 lg:px-8 lg:pt-8">
        <div className="mb-5 hidden items-center justify-between text-xs text-slate-500 lg:flex">
          <span>{fmtDayLong(new Date())}</span>
          <span>Version 0.1 — première version testable</span>
        </div>
        <div key={path} className="animate-fade-up">{children}</div>
        <footer className="mt-12 border-t border-line pt-5 text-center text-[11px] leading-relaxed text-slate-600">
          COTEMAÎTRE BF — L'INTELLIGENCE AU SERVICE DU FOOTBALL. Les pronostics sont des analyses statistiques, jamais une garantie de gain. Jouez de façon responsable.
        </footer>
      </main>
      <Toasts toasts={app.toasts} />
    </div>
  );
}
