import { fmtShort, num } from '../lib/format';

/** Courbe de profit cumulé en unités de mise (SVG pur, sans dépendance). */
export function ProfitChart({ points }: { points: { at: string; value: number }[] }) {
  if (points.length < 2) {
    return <div className="grid h-40 place-items-center text-sm text-slate-500">Pas assez de pronostics soldés avec cote et mise.</div>;
  }
  const W = 600, H = 180, P = 28;
  const vals = [0, ...points.map((p) => p.value)];
  const min = Math.min(...vals), max = Math.max(...vals);
  const span = max - min || 1;
  const x = (i: number) => P + (i / (points.length - 1)) * (W - P * 2);
  const y = (v: number) => H - P - ((v - min) / span) * (H - P * 2);
  const line = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
  const area = `${line} L${x(points.length - 1).toFixed(1)},${y(0).toFixed(1)} L${x(0).toFixed(1)},${y(0).toFixed(1)} Z`;
  const last = points[points.length - 1].value;
  const col = last >= 0 ? '#10b981' : '#f87171';
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} className="h-44 w-full" role="img" aria-label="Courbe du profit cumulé en unités">
        <defs>
          <linearGradient id="pf" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={col} stopOpacity="0.35" />
            <stop offset="1" stopColor={col} stopOpacity="0" />
          </linearGradient>
        </defs>
        <line x1={P} x2={W - P} y1={y(0)} y2={y(0)} stroke="#2a3d35" strokeDasharray="4 4" />
        <path d={area} fill="url(#pf)" />
        <path d={line} fill="none" stroke={col} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" />
        <circle cx={x(points.length - 1)} cy={y(last)} r="4" fill={col} />
        <text x={P} y={H - 6} fill="#64748b" fontSize="11">{fmtShort(points[0].at)}</text>
        <text x={W - P} y={H - 6} fill="#64748b" fontSize="11" textAnchor="end">{fmtShort(points[points.length - 1].at)}</text>
        <text x={W - P} y={y(last) - 10} fill={col} fontSize="12" fontWeight="700" textAnchor="end">{last > 0 ? '+' : ''}{num(last, 1)} u</text>
      </svg>
    </div>
  );
}
