import type { Prediction } from '../types';
import { MARKET_LABEL } from '../types';
import { Badge, DemoBadge, Icon, ResultBadge } from './ui';
import { fmtDateTime, num, pct } from '../lib/format';

export function PredictionCard({ p, deep = false }: { p: Prediction; deep?: boolean }) {
  const vip = p.tier === 'vip';
  const fair = p.probability ? 1 / p.probability : undefined;
  const edge = p.odds && p.probability ? p.odds * p.probability - 1 : undefined;
  return (
    <article className={`animate-fade-up rounded-2xl border p-4 sm:p-5 ${vip ? 'border-gold-500/30 bg-gradient-to-br from-gold-500/[0.06] to-ink-900/80' : 'border-line bg-ink-900/70'}`}>
      <div className="flex flex-wrap items-center gap-2 text-[11px]">
        {vip ? <Badge tone="gold"><Icon name="crown" className="size-3" /> VIP</Badge> : <Badge tone="emerald">Gratuit</Badge>}
        <span className="text-slate-500">{p.league}</span>
        <span className="text-slate-600">·</span>
        <span className="text-slate-500">{fmtDateTime(p.kickoff)}</span>
        {p.demo && <DemoBadge />}
        <span className="ml-auto"><ResultBadge r={p.result} /></span>
      </div>
      <h3 className="mt-3 font-display text-base font-bold text-white sm:text-lg">{p.home} <span className="text-slate-500">vs</span> {p.away}</h3>
      <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2">
        <div>
          <div className="text-[10px] uppercase tracking-wider text-slate-500">{MARKET_LABEL[p.market]}</div>
          <div className={`font-semibold ${vip ? 'text-gold-300' : 'text-emerald-300'}`}>{p.pick}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-slate-500">Cote</div>
          <div className="font-mono font-semibold text-white">{p.odds ? num(p.odds) : <span className="text-slate-500">Non renseignée</span>}</div>
        </div>
        {p.probability !== undefined && (
          <div>
            <div className="text-[10px] uppercase tracking-wider text-slate-500">Probabilité estimée</div>
            <div className="font-mono font-semibold text-white">{pct(p.probability, 0)}</div>
          </div>
        )}
      </div>
      {p.justification && <p className="mt-3 text-sm leading-relaxed text-slate-400">{p.justification}</p>}
      {deep && (
        <div className="mt-4 grid grid-cols-2 gap-2 rounded-xl border border-gold-500/20 bg-black/20 p-3 text-xs sm:grid-cols-4">
          <Metric label="Cote équitable" value={fair ? num(fair) : '—'} />
          <Metric label="Avantage (value)" value={edge !== undefined ? `${edge > 0 ? '+' : ''}${pct(edge, 1)}` : '—'} />
          <Metric label="Mise suggérée" value={p.stake ? `${p.stake} u` : '—'} />
          <Metric label="Marché" value={p.market} />
        </div>
      )}
    </article>
  );
}

const Metric = ({ label, value }: { label: string; value: string }) => (
  <div>
    <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
    <div className="font-mono font-semibold text-gold-300">{value}</div>
  </div>
);
