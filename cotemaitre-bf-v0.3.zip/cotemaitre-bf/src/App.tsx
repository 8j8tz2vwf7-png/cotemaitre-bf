import { Layout } from './components/Layout';
import { DataProvider, useData } from './store/DataContext';
import { AppProvider } from './store/AppStore';
import { useRoute } from './lib/router';
import { Dashboard } from './pages/Dashboard';
import { Matches } from './pages/Matches';
import { Analysis } from './pages/Analysis';
import { Bot } from './pages/Bot';
import { Predictions } from './pages/Predictions';
import { History } from './pages/History';
import { Login } from './pages/Login';
import { Admin } from './pages/Admin';
import { SportsData } from './pages/SportsData';
import { Button, Empty } from './components/ui';
import { navigate } from './lib/router';

function Routes() {
  const path = useRoute();
  const d = useData();
  let page;
  if (d.loading) page = <div className="py-24 text-center text-slate-500">Chargement…</div>;
  else if (d.error) page = <Empty icon="alert" title="Données indisponibles" text={d.error} />;
  else if (path === '/') page = <Dashboard />;
  else if (path === '/matchs') page = <Matches />;
  else if (path.startsWith('/analyse/')) page = <Analysis matchId={decodeURIComponent(path.slice('/analyse/'.length))} />;
  else if (path === '/bot') page = <Bot />;
  else if (path === '/pronostics') page = <Predictions />;
  else if (path === '/historique') page = <History />;
  else if (path === '/connexion') page = <Login />;
  else if (path === '/admin') page = <Admin />;
  else if (path === '/donnees') page = <SportsData />;
  else page = <Empty icon="alert" title="Page introuvable" action={<Button onClick={() => navigate('/')}>Retour au tableau de bord</Button>} />;
  return <Layout path={path}>{page}</Layout>;
}

export default function App() {
  return (
    <DataProvider>
      <AppProvider>
        <Routes />
      </AppProvider>
    </DataProvider>
  );
}
