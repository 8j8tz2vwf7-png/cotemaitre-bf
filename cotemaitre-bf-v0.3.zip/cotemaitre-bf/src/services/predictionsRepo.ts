/**
 * Dépôt des pronostics sur Supabase (PostgREST). Branché au store (AppStore) en mode réel. Démonstration locale sinon.
 * Toutes les règles de sécurité (qui lit quoi, qui publie) sont appliquées par la base (RLS + triggers) :
 * ce module ne fait que traduire les lignes SQL en objets `Prediction`.
 */
import type { Market, Prediction, ScanRecord, PredictionSource, Result, ReviewStatus, Tier } from '../types';
import type { SupabaseLite } from '../lib/supabase/client';

interface FixtureEmbed { home_team: string; away_team: string; league_name: string; kickoff: string }
export interface PredictionRow {
  id: string;
  fixture_id: number | null;
  market: Market;
  pick: string;
  odds: number | null;
  stake: number | null;
  probability: number | null;
  justification: string;
  tier: Tier;
  review: ReviewStatus;
  published: boolean;
  result: Result;
  source: string;
  created_at: string;
  updated_at: string;
  published_at?: string | null;
  fixtures?: FixtureEmbed | null;
}

const SELECT = '*,fixtures(home_team,away_team,league_name,kickoff)';

const sourceFromDb = (s: string): PredictionSource => (s === 'admin' ? 'admin' : 'bot-live');

export function rowToPrediction(r: PredictionRow): Prediction {
  return {
    id: r.id,
    matchId: r.fixture_id === null ? undefined : String(r.fixture_id),
    home: r.fixtures?.home_team ?? '',
    away: r.fixtures?.away_team ?? '',
    league: r.fixtures?.league_name ?? '',
    kickoff: r.fixtures?.kickoff ?? r.created_at,
    market: r.market,
    pick: r.pick,
    odds: r.odds ?? undefined,
    stake: r.stake ?? undefined,
    probability: r.probability ?? undefined,
    justification: r.justification,
    tier: r.tier,
    review: r.review,
    published: r.published,
    result: r.result,
    source: sourceFromDb(r.source),
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    publishedAt: r.published_at ?? undefined,
    demo: false,
  };
}

export function createPredictionsRepo(db: SupabaseLite) {
  return {
    /** Ce que la base autorise pour l'utilisateur courant : visiteur → gratuits publiés ; VIP → + VIP ; admin → tout. */
    async list(): Promise<Prediction[]> {
      // PostgREST plafonne à 1000 lignes par requête : on lit par pages.
      const out: PredictionRow[] = [];
      for (let offset = 0; ; offset += 1000) {
        const rows = await db.get<PredictionRow[]>('predictions', { select: SELECT, order: 'created_at.desc,id.asc', limit: 1000, offset });
        out.push(...rows);
        if (rows.length < 1000) break;
      }
      return out.map(rowToPrediction);
    },
    async get(id: string): Promise<Prediction> {
      const rows = await db.get<PredictionRow[]>('predictions', { select: SELECT, id: `eq.${id}` });
      if (!rows[0]) throw new Error('Pronostic introuvable ou accès refusé.');
      return rowToPrediction(rows[0]);
    },
    /** Journal des scans (lisible par l'admin seulement : un visiteur obtient simplement une liste vide). */
    async listScans(): Promise<ScanRecord[]> {
      const rows = await db.get<{ id: string; started_at: string; mode: string; detected: number | null; analyzed: number | null; discarded: number | null; proposals: number | null; details: ScanRecord['details'] | null }[]>(
        'scan_runs', { select: '*', order: 'started_at.desc', limit: 50 });
      return rows.map((r) => ({ id: r.id, at: r.started_at, mode: r.mode === 'DEMO' ? 'DEMO' : 'LIVE', detected: r.detected ?? 0, analyzed: r.analyzed ?? 0, discarded: r.discarded ?? 0, proposals: r.proposals ?? 0, details: r.details ?? [] }));
    },
    /** Matchs ayant une analyse enregistrée (visible selon l'abonnement). */
    async analyzedFixtureIds(): Promise<string[]> {
      const rows = await db.get<{ fixture_id: number }[]>('analyses', { select: 'fixture_id' });
      return rows.map((r) => String(r.fixture_id));
    },
    /** Création (admin) : la base impose « proposé, non publié, non soldé » quoi qu'on envoie. */
    async create(p: Pick<Prediction, 'market' | 'pick' | 'justification' | 'tier'> & { matchId?: string; odds?: number; stake?: number; probability?: number }): Promise<Prediction> {
      const rows = await db.post<PredictionRow[]>('predictions', {
        fixture_id: p.matchId === undefined ? null : Number(p.matchId),
        market: p.market, pick: p.pick, justification: p.justification, tier: p.tier,
        odds: p.odds ?? null, stake: p.stake ?? null, probability: p.probability ?? null,
        source: 'admin',
      }, { select: SELECT });
      return rowToPrediction(rows[0]);
    },
    /** Modification (admin). Valider, publier, solder… passent par ce même appel : la base contrôle chaque transition. */
    async update(id: string, patch: Partial<Pick<Prediction, 'market' | 'pick' | 'odds' | 'stake' | 'justification' | 'tier' | 'review' | 'published' | 'result'>>): Promise<Prediction> {
      const body: Record<string, unknown> = { ...patch };
      if ('odds' in patch) body.odds = patch.odds ?? null;
      if ('stake' in patch) body.stake = patch.stake ?? null;
      const rows = await db.patch<PredictionRow[]>('predictions', body, { id: `eq.${id}`, select: SELECT });
      if (!rows[0]) throw new Error('Pronostic introuvable ou accès refusé.');
      return rowToPrediction(rows[0]);
    },
    /** Règlement automatique d'après le score du match (RPC contrôlée côté base : admin uniquement). */
    settleFromScore: (id: string) => db.rpc<Result>('admin_settle_prediction', { p_id: id }),
  };
}
