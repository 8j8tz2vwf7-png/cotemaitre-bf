/**
 * Couche d'accès aux données football — même interface en démonstration et en mode réel.
 *  - DemoProvider     : données fictives locales (Supabase non configuré).
 *  - SupabaseProvider : lit championnats, équipes et matchs dans la base (saisie admin aujourd'hui,
 *                       synchronisation API-Football plus tard : voir sportsSource.ts). Aucune donnée inventée.
 */
import type { League, Match, MatchAnalysis, Team } from '../types';
import { buildAnalysis, getDemoMatches, LEAGUES, TEAMS } from '../data/demo';
import { supabaseClient } from './auth';
import { createSportsRepo, leagueFromRow, matchFromRow, teamFromRow } from './sportsRepo';

export interface FootballProvider {
  readonly name: string;
  readonly mode: 'demo' | 'live';
  /** Charge tout d'un coup (cohérent : une seule lecture par table). */
  load(): Promise<{ leagues: League[]; teams: Team[]; matches: Match[]; sources: string[] }>;
  getAnalysis(matchId: string): Promise<MatchAnalysis | null>;
}

class DemoProvider implements FootballProvider {
  readonly name = 'Données de démonstration (fictives)';
  readonly mode = 'demo' as const;
  private matches = getDemoMatches();
  load = () => Promise.resolve({ leagues: LEAGUES, teams: TEAMS, matches: this.matches, sources: [] });
  getAnalysis = (id: string) => {
    const m = this.matches.find((x) => x.id === id);
    return Promise.resolve(m ? buildAnalysis(m) : null);
  };
}

class SupabaseProvider implements FootballProvider {
  readonly name = 'Base de données Supabase';
  readonly mode = 'live' as const;
  private repo = createSportsRepo(supabaseClient!);
  async load() {
    const [l, t, f] = await Promise.all([this.repo.listLeagues(), this.repo.listTeams(), this.repo.listFixtures()]);
    // Les équipes n'ont pas de championnat propre : on le déduit de leurs matchs (le plus récent).
    const leagueOf = new Map<number, number>();
    for (const x of f) for (const id of [x.home_team_id, x.away_team_id]) if (id !== null && !leagueOf.has(id)) leagueOf.set(id, x.league_id);
    return {
      leagues: l.map(leagueFromRow),
      teams: t.map((r) => teamFromRow(r, String(leagueOf.get(r.id) ?? ''))),
      matches: f.map(matchFromRow),
      sources: f.map((x) => x.source),
    };
  }
  /** Le moteur d'analyse n'est pas activé : aucune analyse n'est fabriquée. */
  getAnalysis = () => Promise.resolve(null);
}

export const getProvider = (): FootballProvider => (supabaseClient ? new SupabaseProvider() : new DemoProvider());
