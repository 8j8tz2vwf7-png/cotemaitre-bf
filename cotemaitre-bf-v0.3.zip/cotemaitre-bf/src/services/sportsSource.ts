/**
 * Source des données sportives (C3 — préparation, SANS appel réseau).
 *
 * Aujourd'hui : « manuel » — l'administrateur saisit championnats, équipes, matchs et résultats (page Données sportives).
 * Demain      : « api-football » — une Edge Function serveur (clé APIFOOTBALL_KEY côté serveur uniquement) écrira
 *               les mêmes tables avec source = 'api-football'. L'interface lit toujours la base : rien à changer ici.
 *
 * Ce module ne simule JAMAIS une API : tant qu'aucune synchronisation réelle n'a eu lieu, le statut est « manuel ».
 */
export type SportsSourceKind = 'manual' | 'api-football';

export interface SportsSourceStatus {
  kind: SportsSourceKind;
  label: string;
  detail: string;
  /** true seulement si au moins une ligne de la base provient réellement de l'API. */
  apiConnected: boolean;
}

/** Détermine l'état d'après les données réellement présentes (colonne `source` des matchs). */
export function sportsSourceStatus(fixtureSources: string[]): SportsSourceStatus {
  const api = fixtureSources.filter((s) => s === 'api-football').length;
  if (api > 0) {
    return { kind: 'api-football', apiConnected: true, label: 'API-Football', detail: `${api} match(s) synchronisé(s) depuis l'API (+ saisies manuelles éventuelles).` };
  }
  return {
    kind: 'manual', apiConnected: false, label: 'MODE MANUEL',
    detail: 'Aucune API sportive connectée : les données sont saisies par l\'administrateur (page « Données sportives »).',
  };
}
