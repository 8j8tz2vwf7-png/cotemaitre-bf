/**
 * Moteur de sélection — VERSION DÉMO LOCALE.
 * Réutilise le modèle de Poisson sur les données fictives. Ce n'est PAS le
 * futur moteur statistique : en production il tournera côté serveur
 * (Edge Function / worker) sur des données API-Football réelles.
 */
import type { Market, Match, MatchAnalysis, Prediction, Probabilities, ScanDetail, ScanRecord } from '../types';
import { fmtShort, num, pct, uid } from '../lib/format';

export interface Candidate {
  market: Market;
  pick: string;
  probability: number;
  margin: number;
}

export function bestCandidate(p: Probabilities): Candidate | null {
  const c: Candidate[] = [];
  const add = (market: Market, pick: string, prob: number, thr: number) => {
    if (prob >= thr) c.push({ market, pick, probability: prob, margin: prob - thr });
  };
  add('1X2', 'Victoire domicile', p.home, 0.5);
  add('1X2', 'Victoire extérieure', p.away, 0.5);
  add('DC', '1X', p.dc1X, 0.8);
  add('DC', 'X2', p.dcX2, 0.8);
  add('OU', 'Plus de 2,5 buts', p.over['2.5'], 0.56);
  add('OU', 'Moins de 2,5 buts', 1 - p.over['2.5'], 0.6);
  add('OU', 'Plus de 1,5 buts', p.over['1.5'], 0.82);
  add('BTTS', 'Les deux équipes marquent : Oui', p.btts, 0.58);
  add('BTTS', 'Les deux équipes marquent : Non', 1 - p.btts, 0.62);
  c.sort((a, b) => b.margin - a.margin);
  return c[0] ?? null;
}

const formStr = (a: MatchAnalysis['home']) => {
  const f = a.last10.slice(0, 5);
  const c = (r: string) => f.filter((x) => x.res === r).length;
  return `${a.team.name} ${c('W')}V-${c('D')}N-${c('L')}D (5 derniers)`;
};

export function buildJustification(a: MatchAnalysis, cand: Candidate): string {
  const p = a.probabilities;
  return (
    `Modèle de Poisson sur données DÉMO : buts attendus ${num(p.lambdaHome)} (dom.) / ${num(p.lambdaAway)} (ext.). ` +
    `Probabilité estimée de « ${cand.pick} » : ${pct(cand.probability, 1)} (cote équitable théorique ≈ ${num(1 / cand.probability)}). ` +
    `Forme : ${formStr(a.home)} ; ${formStr(a.away)}. ` +
    `Proposition générée par le moteur local de démonstration — à relire et valider par un humain.`
  );
}

export interface ScanOutput {
  record: ScanRecord;
  newPredictions: Prediction[];
  analyzedIds: string[];
}

export async function runDemoScan(
  matches: Match[],
  getAnalysis: (id: string) => Promise<MatchAnalysis | null>,
  nameOf: (m: Match) => { home: string; away: string; league: string },
  existing: Prediction[],
  maxProposals = 6,
): Promise<ScanOutput> {
  const scheduled = matches.filter((m) => m.status === 'scheduled');
  const analyses = await Promise.all(scheduled.map(async (m) => ({ m, a: await getAnalysis(m.id) })));
  const scored = analyses
    .filter((x): x is { m: Match; a: MatchAnalysis } => x.a !== null)
    .map((x) => ({ ...x, cand: bestCandidate(x.a.probabilities) }));

  const details: ScanDetail[] = [];
  const newPredictions: Prediction[] = [];
  const now = new Date().toISOString();
  const ranked = [...scored].filter((s) => s.cand).sort((a, b) => b.cand!.margin - a.cand!.margin);
  const keep = new Set(ranked.slice(0, maxProposals).map((s) => s.m.id));

  for (const s of scored) {
    const n = nameOf(s.m);
    const label = `${n.home} – ${n.away} (${fmtShort(s.m.kickoff)})`;
    if (!s.cand) {
      details.push({ matchId: s.m.id, label, outcome: 'discarded', note: 'Aucun marché au-dessus des seuils de confiance.' });
      continue;
    }
    if (!keep.has(s.m.id)) {
      details.push({ matchId: s.m.id, label, outcome: 'discarded', note: `Écarté : hors des ${maxProposals} meilleures sélections.` });
      continue;
    }
    const dup = existing.some((p) => p.matchId === s.m.id && p.market === s.cand!.market && p.pick === s.cand!.pick);
    if (dup) {
      details.push({ matchId: s.m.id, label, outcome: 'existing', note: `Proposition « ${s.cand.pick} » déjà présente.` });
      continue;
    }
    newPredictions.push({
      id: uid('prop'),
      matchId: s.m.id,
      home: n.home, away: n.away, league: n.league, kickoff: s.m.kickoff,
      market: s.cand.market, pick: s.cand.pick,
      probability: s.cand.probability,
      justification: buildJustification(s.a, s.cand),
      tier: 'free', review: 'proposed', published: false, result: 'pending',
      source: 'demo-scan', createdAt: now, updatedAt: now, demo: true,
    });
    details.push({ matchId: s.m.id, label, outcome: 'proposed', note: `« ${s.cand.pick} » — ${pct(s.cand.probability, 1)}` });
  }

  const record: ScanRecord = {
    id: uid('scan'),
    at: now,
    mode: 'DEMO',
    detected: scheduled.length,
    analyzed: scored.length,
    discarded: details.filter((d) => d.outcome === 'discarded').length,
    proposals: newPredictions.length,
    details,
  };
  return { record, newPredictions, analyzedIds: scored.map((s) => s.m.id) };
}
