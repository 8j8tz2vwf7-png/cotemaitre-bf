/**
 * Authentification — deux implémentations derrière la même interface :
 *
 *  • demoAuth      : identifiants écrits dans le code (visibles de tous). Sert UNIQUEMENT à tester l'interface.
 *                    Actif tant que Supabase n'est pas configuré.
 *  • supabaseAuth  : vraie authentification Supabase (e-mail + mot de passe). Actif dès que
 *                    VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY sont valides. Le mode démo est alors DÉSACTIVÉ :
 *                    les identifiants de démonstration ne donnent plus aucun accès.
 *
 * Le rôle (admin / user) provient de la table `profiles`, source de vérité protégée par RLS.
 * On ne lit JAMAIS le rôle dans le JWT ni dans user_metadata (modifiable par l'utilisateur).
 * Le contrôle réel des droits reste dans PostgreSQL : cette couche ne fait qu'adapter l'interface.
 */
import type { Session } from '../types';
import { supabaseEnv, supabaseHost } from '../lib/supabase/env';
import { AuthError, createSupabaseLite, type SupabaseLite } from '../lib/supabase/client';

export interface AuthService {
  readonly kind: 'demo' | 'supabase';
  /** Restaure une session existante (rechargement de page). */
  init(): Promise<Session | null>;
  signIn(email: string, password: string): Promise<Session>;
  signOut(): Promise<void>;
  /** Notifie les changements de session venant de l'extérieur (autre onglet, jeton expiré…). */
  subscribe(cb: (s: Session | null) => void): () => void;
}

// ───────────────────────── Démonstration ─────────────────────────

export const DEMO_ADMIN = { email: 'admin@demo.local', password: 'demo-admin-2026' };
const DEMO_SESSION_KEY = 'cotemaitre-bf-demo-session';

export const demoAuth: AuthService = {
  kind: 'demo',
  async init() {
    try {
      const raw = window.localStorage.getItem(DEMO_SESSION_KEY);
      if (!raw) return null;
      const s = JSON.parse(raw) as Session;
      return s && s.email === DEMO_ADMIN.email && s.role === 'admin' ? s : null;
    } catch { return null; }
  },
  async signIn(email, password) {
    await new Promise((r) => setTimeout(r, 350));
    if (email.trim().toLowerCase() === DEMO_ADMIN.email && password === DEMO_ADMIN.password) {
      const s: Session = { email: DEMO_ADMIN.email, role: 'admin' };
      try { window.localStorage.setItem(DEMO_SESSION_KEY, JSON.stringify(s)); } catch { /* ignoré */ }
      return s;
    }
    throw new Error('Identifiants incorrects.');
  },
  async signOut() {
    try { window.localStorage.removeItem(DEMO_SESSION_KEY); } catch { /* ignoré */ }
  },
  subscribe: () => () => {},
};

// ───────────────────────── Supabase ─────────────────────────

interface ProfileRow { role: string; display_name: string | null }

export function createSupabaseAuth(client: SupabaseLite): AuthService {
  /** Rôle lu en base. En cas d'échec (réseau, RLS), on ÉCHOUE FERMÉ : rôle « user ». */
  async function toSession(user: { id: string; email: string }): Promise<Session> {
    let role: Session['role'] = 'user';
    let displayName: string | undefined;
    try {
      const rows = await client.get<ProfileRow[]>('profiles', { select: 'role,display_name', id: `eq.${user.id}`, limit: 1 });
      if (rows[0]?.role === 'admin') role = 'admin';
      displayName = rows[0]?.display_name ?? undefined;
    } catch { /* fail closed */ }
    return { email: user.email, role, userId: user.id, displayName };
  }

  return {
    kind: 'supabase',
    async init() {
      const s = await client.auth.getSession();
      return s ? toSession(s.user) : null;
    },
    async signIn(email, password) {
      if (!email.trim() || !password) throw new Error('Saisissez votre e-mail et votre mot de passe.');
      try {
        const s = await client.auth.signInWithPassword(email, password);
        return await toSession(s.user);
      } catch (e) {
        if (e instanceof AuthError) throw new Error(e.message);
        throw e;
      }
    },
    signOut: () => client.auth.signOut(),
    subscribe(cb) {
      return client.auth.onAuthStateChange((event, s) => {
        if (event === 'TOKEN_REFRESHED') return;           // même utilisateur : pas de rechargement du rôle
        if (!s) { cb(null); return; }
        // Le rôle se charge en asynchrone : on vérifie ensuite que la session est toujours active (pas de session fantôme).
        void toSession(s.user).then(async (sess) => {
          const cur = await client.auth.getSession();
          cb(cur && cur.user.id === s.user.id ? sess : null);
        });
      });
    },
  };
}

// ───────────────────────── Sélection du mode ─────────────────────────

export const supabaseClient: SupabaseLite | null =
  supabaseEnv.state === 'configured' ? createSupabaseLite(supabaseEnv.url, supabaseEnv.anonKey) : null;

export const auth: AuthService = supabaseClient ? createSupabaseAuth(supabaseClient) : demoAuth;

/** Informations d'état affichables (jamais de clé). */
export const authInfo = {
  kind: auth.kind,
  envState: supabaseEnv.state,
  reason: supabaseEnv.state === 'configured' ? '' : supabaseEnv.reason,
  host: supabaseHost,
};
