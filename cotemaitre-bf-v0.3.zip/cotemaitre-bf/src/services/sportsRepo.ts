/**
 * Données sportives sur Supabase : championnats, équipes, matchs, statistiques d'équipes.
 * La base applique les règles (admin seulement pour écrire, lignes manuelles seulement, contraintes) ;
 * ce module traduit les lignes SQL en objets de l'interface et les erreurs SQL en messages français.
 */
import type { League, Match, MatchStatus, Team } from '../types';
import { RestError, type SupabaseLite } from '../lib/supabase/client';

export interface LeagueRow { id: number; name: string; country: string | null; logo_url: string | null; source: string }
export interface TeamRow { id: number; name: string; short_name: string | null; country: string | null; logo_url: string | null; source: string }
export interface FixtureRow {
  id: number; league_id: number; league_name: string; home_team: string; away_team: string;
  home_team_id: number | null; away_team_id: number | null; kickoff: string; status: MatchStatus;
  home_goals: number | null; away_goals: number | null; round: string | null; venue: string | null; season: number | null; source: string;
}
export interface TeamStatsRow { team_id: number; league_id: number; season: number; stats: TeamStats; updated_at: string }

/** Contrat des statistiques (voir docs/DATA_CONTRACT.md) : tout champ absent = « non renseigné ». */
export interface SplitRow { played: number; wins: number; draws: number; losses: number; gf: number; ga: number }
export interface TeamStats {
  form?: string;
  home?: SplitRow; away?: SplitRow;
  shots_per_game?: number; shots_on_target_per_game?: number; possession_pct?: number;
  clean_sheet_pct?: number; failed_to_score_pct?: number;
  absences?: { player: string; reason: 'Blessure' | 'Suspension' | 'Incertain'; verified?: boolean }[];
}

const PAGE = 1000;

function hue(name: string): number {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  return h;
}

export const leagueFromRow = (r: LeagueRow): League => ({ id: String(r.id), name: r.name, country: r.country ?? '', logoUrl: r.logo_url ?? undefined });

export function teamFromRow(r: TeamRow, leagueId = ''): Team {
  return { id: String(r.id), name: r.name, short: (r.short_name || r.name.replace(/[^\p{L}\p{N}]/gu, '').slice(0, 3)).toUpperCase(), leagueId, hue: hue(r.name), logoUrl: r.logo_url ?? undefined };
}

export const matchFromRow = (r: FixtureRow): Match => ({
  id: String(r.id), leagueId: String(r.league_id), homeId: String(r.home_team_id ?? ''), awayId: String(r.away_team_id ?? ''),
  kickoff: r.kickoff, status: r.status,
  homeGoals: r.home_goals ?? undefined, awayGoals: r.away_goals ?? undefined, demo: false,
});

/** Traduit une erreur PostgREST/PostgreSQL en phrase compréhensible. */
export function explain(e: unknown): Error {
  if (!(e instanceof RestError)) return e instanceof Error ? e : new Error('Erreur inattendue.');
  const map: Record<string, string> = {
    '42501': 'Action refusée : droits insuffisants (administrateur requis, ou donnée issue d\'une API).',
    '23505': 'Cet élément existe déjà (doublon).',
    '23503': 'Suppression impossible : cet élément est utilisé ailleurs (matchs, statistiques ou pronostics).',
  };
  if (map[e.code]) return new Error(map[e.code]);
  if (e.code === '23514' || e.code === 'P0001') return new Error(e.message.replace(/violates check constraint.*/, 'valeur refusée par les règles de la base.'));
  return new Error(e.message);
}

async function all<T>(db: SupabaseLite, table: string, query: Record<string, string>): Promise<T[]> {
  const out: T[] = [];
  for (let offset = 0; ; offset += PAGE) {
    const rows = await db.get<T[]>(table, { ...query, limit: PAGE, offset });
    out.push(...rows);
    if (rows.length < PAGE) return out;
  }
}

const one = <T,>(rows: T[], msg: string): T => {
  if (!rows[0]) throw new Error(msg);
  return rows[0];
};

export function createSportsRepo(db: SupabaseLite) {
  const wrap = async <T,>(fn: () => Promise<T>): Promise<T> => { try { return await fn(); } catch (e) { throw explain(e); } };
  return {
    listLeagues: () => wrap(() => all<LeagueRow>(db, 'leagues', { select: '*', order: 'name.asc,id.asc' })),
    listTeams: () => wrap(() => all<TeamRow>(db, 'teams', { select: '*', order: 'name.asc,id.asc' })),
    listFixtures: () => wrap(() => all<FixtureRow>(db, 'fixtures', { select: '*', order: 'kickoff.desc,id.asc' })),
    listTeamStats: () => wrap(() => all<TeamStatsRow>(db, 'team_stats', { select: '*', order: 'season.desc,team_id.asc' })),

    createLeague: (v: { name: string; country?: string }) => wrap(async () =>
      one(await db.post<LeagueRow[]>('leagues', { name: v.name.trim(), country: v.country?.trim() || null, source: 'manual' }), 'Création refusée.')),
    updateLeague: (id: number, v: { name: string; country?: string }) => wrap(async () =>
      one(await db.patch<LeagueRow[]>('leagues', { name: v.name.trim(), country: v.country?.trim() || null }, { id: `eq.${id}` }), 'Modification refusée : championnat introuvable, ou issu d\'une API.')),
    deleteLeague: (id: number) => wrap(async () => { one(await db.delete<LeagueRow[]>('leagues', { id: `eq.${id}` }), 'Suppression refusée : championnat introuvable, ou issu d\'une API.'); }),

    createTeam: (v: { name: string; short?: string; country?: string }) => wrap(async () =>
      one(await db.post<TeamRow[]>('teams', { name: v.name.trim(), short_name: v.short?.trim() || null, country: v.country?.trim() || null, source: 'manual' }), 'Création refusée.')),
    updateTeam: (id: number, v: { name: string; short?: string; country?: string }) => wrap(async () =>
      one(await db.patch<TeamRow[]>('teams', { name: v.name.trim(), short_name: v.short?.trim() || null, country: v.country?.trim() || null }, { id: `eq.${id}` }), 'Modification refusée : équipe introuvable, ou issue d\'une API.')),
    deleteTeam: (id: number) => wrap(async () => { one(await db.delete<TeamRow[]>('teams', { id: `eq.${id}` }), 'Suppression refusée : équipe introuvable, ou issue d\'une API.'); }),

    createFixture: (v: { leagueId: number; homeId: number; awayId: number; kickoff: string; round?: string; venue?: string }) => wrap(async () =>
      one(await db.post<FixtureRow[]>('fixtures', {
        league_id: v.leagueId, home_team_id: v.homeId, away_team_id: v.awayId, kickoff: v.kickoff,
        round: v.round?.trim() || null, venue: v.venue?.trim() || null, source: 'manual',
        // Noms provisoires (NOT NULL) : le trigger fixtures_sync les remplace par les vrais noms.
        league_name: '', home_team: '', away_team: '',
      }), 'Création refusée.')),
    /** Corrige les informations du match (équipes, championnat, date…) — jamais le score (voir setScore). */
    updateFixture: (id: number, v: { leagueId: number; homeId: number; awayId: number; kickoff: string; round?: string; venue?: string; status?: MatchStatus }) => wrap(async () =>
      one(await db.patch<FixtureRow[]>('fixtures', {
        league_id: v.leagueId, home_team_id: v.homeId, away_team_id: v.awayId, kickoff: v.kickoff,
        round: v.round?.trim() || null, venue: v.venue?.trim() || null, ...(v.status ? { status: v.status } : {}),
      }, { id: `eq.${id}` }), 'Modification refusée : match introuvable, ou issu d\'une API.')),
    /** Statut + score cohérents : « terminé » exige un score ; « programmé/reporté/annulé » n'en a pas. */
    setScore: (id: number, v: { status: MatchStatus; home?: number; away?: number }) => wrap(async () => {
      const scored = v.status === 'live' || v.status === 'finished';
      if (v.status === 'finished' && (v.home === undefined || v.away === undefined)) throw new Error('Un match terminé exige les deux scores.');
      return one(await db.patch<FixtureRow[]>('fixtures', {
        status: v.status, home_goals: scored ? (v.home ?? null) : null, away_goals: scored ? (v.away ?? null) : null,
      }, { id: `eq.${id}` }), 'Modification refusée : match introuvable, ou issu d\'une API.');
    }),
    deleteFixture: (id: number) => wrap(async () => { one(await db.delete<FixtureRow[]>('fixtures', { id: `eq.${id}` }), 'Suppression refusée : match introuvable, ou issu d\'une API.'); }),

    saveTeamStats: (v: { teamId: number; leagueId: number; season: number; stats: TeamStats }) => wrap(async () => {
      const existing = await db.get<TeamStatsRow[]>('team_stats', { select: 'team_id', team_id: `eq.${v.teamId}`, league_id: `eq.${v.leagueId}`, season: `eq.${v.season}` });
      if (existing.length) {
        return one(await db.patch<TeamStatsRow[]>('team_stats', { stats: v.stats }, { team_id: `eq.${v.teamId}`, league_id: `eq.${v.leagueId}`, season: `eq.${v.season}` }), 'Modification refusée.');
      }
      return one(await db.post<TeamStatsRow[]>('team_stats', { team_id: v.teamId, league_id: v.leagueId, season: v.season, stats: v.stats }), 'Création refusée.');
    }),
    deleteTeamStats: (teamId: number, leagueId: number, season: number) => wrap(async () => {
      one(await db.delete<TeamStatsRow[]>('team_stats', { team_id: `eq.${teamId}`, league_id: `eq.${leagueId}`, season: `eq.${season}` }), 'Suppression refusée.');
    }),
  };
}
export type SportsRepo = ReturnType<typeof createSportsRepo>;
