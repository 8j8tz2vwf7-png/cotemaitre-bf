/**
 * DONNÉES DE DÉMONSTRATION — 100 % FICTIVES.
 * Équipes, championnats, scores et statistiques sont générés de façon
 * déterministe pour permettre de tester l'interface. Rien ici ne provient
 * d'une source réelle. Remplacé par API-Football via le backend (voir services/football.ts).
 */
import type {
  Absence, FormEntry, H2HEntry, League, Match, MatchAnalysis, MatchStatus, Prediction,
  SplitStats, StandingRow, Team, TeamProfile,
} from '../types';
import { computeProbabilities } from '../lib/poisson';

export function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const hash = (s: string) => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
};
const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x));
const poissonSample = (lambda: number, r: () => number) => {
  const L = Math.exp(-lambda);
  let k = 0, p = 1;
  do { k++; p *= r(); } while (p > L);
  return k - 1;
};

export const LEAGUES: League[] = [
  { id: 'L1', name: 'Ligue Démo Savane', country: 'Pays fictif' },
  { id: 'L2', name: 'Championnat Démo Sahel', country: 'Pays fictif' },
  { id: 'L3', name: 'Coupe Démo Inter-ligues', country: 'Pays fictif' },
];

export const TEAMS: Team[] = [
  { id: 't1', name: 'FC Harmattan', short: 'HAR', leagueId: 'L1', hue: 152 },
  { id: 't2', name: 'AS Baobab', short: 'BAO', leagueId: 'L1', hue: 38 },
  { id: 't3', name: 'Olympique Savane', short: 'SAV', leagueId: 'L1', hue: 210 },
  { id: 't4', name: 'Racing Latérite', short: 'LAT', leagueId: 'L1', hue: 14 },
  { id: 't5', name: 'US Karité', short: 'KAR', leagueId: 'L1', hue: 280 },
  { id: 't6', name: 'Dynamo Acacia', short: 'ACA', leagueId: 'L1', hue: 95 },
  { id: 't7', name: 'Union Sahélia', short: 'SAH', leagueId: 'L2', hue: 190 },
  { id: 't8', name: 'Stade Mil', short: 'MIL', leagueId: 'L2', hue: 50 },
  { id: 't9', name: 'Étoile Dune', short: 'DUN', leagueId: 'L2', hue: 330 },
  { id: 't10', name: 'Sporting Kora', short: 'KOR', leagueId: 'L2', hue: 240 },
  { id: 't11', name: 'FC Tamarin', short: 'TAM', leagueId: 'L2', hue: 120 },
  { id: 't12', name: 'AS Calebasse', short: 'CAL', leagueId: 'L2', hue: 0 },
];

const teamById = (id: string) => TEAMS.find((t) => t.id === id)!;

const at = (day: number, h: number, m = 0) => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + day);
  d.setHours(h, m);
  return d.toISOString();
};

type Fx = [string, string, string, string, number, number, number, MatchStatus, number?, number?];
const FIXTURES: Fx[] = [
  // Passés (terminés)
  ['m01', 'L1', 't1', 't2', -4, 17, 0, 'finished', 2, 1],
  ['m02', 'L2', 't7', 't8', -4, 16, 0, 'finished', 0, 0],
  ['m03', 'L1', 't3', 't4', -3, 18, 0, 'finished', 1, 3],
  ['m04', 'L2', 't9', 't10', -3, 15, 30, 'finished', 2, 2],
  ['m05', 'L1', 't5', 't6', -2, 17, 0, 'finished', 1, 0],
  ['m06', 'L2', 't11', 't12', -2, 19, 0, 'finished', 3, 1],
  ['m07', 'L3', 't1', 't7', -1, 20, 0, 'finished', 2, 0],
  ['m08', 'L1', 't6', 't3', -1, 16, 0, 'finished', 0, 2],
  // Aujourd'hui
  ['m09', 'L1', 't2', 't4', 0, 12, 0, 'finished', 2, 0],
  ['m10', 'L2', 't8', 't9', 0, 14, 0, 'finished', 1, 1],
  ['m11', 'L1', 't1', 't5', 0, 19, 0, 'scheduled'],
  ['m12', 'L1', 't3', 't6', 0, 20, 30, 'scheduled'],
  ['m13', 'L2', 't7', 't10', 0, 21, 0, 'scheduled'],
  ['m14', 'L3', 't4', 't12', 0, 18, 0, 'postponed'],
  // Demain
  ['m15', 'L1', 't6', 't1', 1, 16, 0, 'scheduled'],
  ['m16', 'L1', 't4', 't5', 1, 18, 0, 'scheduled'],
  ['m17', 'L1', 't2', 't3', 1, 20, 0, 'scheduled'],
  ['m18', 'L2', 't8', 't11', 1, 17, 0, 'scheduled'],
  ['m19', 'L2', 't9', 't12', 1, 19, 0, 'scheduled'],
  ['m20', 'L2', 't10', 't7', 1, 21, 0, 'scheduled'],
  // À venir
  ['m21', 'L1', 't1', 't3', 2, 18, 0, 'scheduled'],
  ['m22', 'L1', 't5', 't2', 2, 20, 0, 'scheduled'],
  ['m23', 'L2', 't12', 't7', 3, 17, 0, 'scheduled'],
  ['m24', 'L2', 't10', 't9', 3, 19, 30, 'scheduled'],
  ['m25', 'L3', 't3', 't11', 4, 20, 0, 'scheduled'],
  ['m26', 'L1', 't4', 't6', 5, 16, 0, 'scheduled'],
  ['m27', 'L2', 't11', 't8', 6, 18, 0, 'scheduled'],
  ['m28', 'L3', 't2', 't10', 7, 20, 0, 'scheduled'],
];

export function getDemoMatches(): Match[] {
  return FIXTURES.map(([id, leagueId, homeId, awayId, day, h, m, status, hg, ag]) => ({
    id, leagueId, homeId, awayId, kickoff: at(day, h, m), status, homeGoals: hg, awayGoals: ag, demo: true,
  }));
}

// ───────────────────────── Profils et analyses ─────────────────────────

const ABSENCE_POOL: Absence[] = [
  { role: 'Attaquant titulaire (démo)', reason: 'Blessure' },
  { role: 'Milieu récupérateur (démo)', reason: 'Suspension' },
  { role: 'Défenseur central (démo)', reason: 'Incertain' },
  { role: 'Gardien remplaçant (démo)', reason: 'Blessure' },
  { role: 'Latéral droit (démo)', reason: 'Incertain' },
];

function core(t: Team) {
  const r = mulberry32(hash(t.id));
  return { attack: 0.95 + r() * 1.0, defense: 0.7 + r() * 0.9, r };
}

function makeSplit(r: () => number, played: number, gfAvg: number, gaAvg: number): SplitStats {
  const edge = gfAvg - gaAvg;
  let wins = Math.round(played * clamp(0.38 + edge * 0.25, 0.1, 0.8));
  wins = Math.min(wins, played);
  const draws = Math.min(Math.round(played * (0.18 + r() * 0.15)), played - wins);
  return { played, wins, draws, losses: played - wins - draws, gf: Math.round(gfAvg * played), ga: Math.round(gaAvg * played) };
}

const profileCache = new Map<string, TeamProfile>();
function buildProfile(team: Team): TeamProfile {
  const hit = profileCache.get(team.id);
  if (hit) return hit;
  const { attack, defense, r } = core(team);
  const mates = TEAMS.filter((t) => t.leagueId === (team.leagueId === 'L3' ? 'L1' : team.leagueId) && t.id !== team.id);
  const last10: FormEntry[] = Array.from({ length: 10 }, (_, i) => {
    const venue = i % 2 === 0 ? 'H' : 'A';
    const gf = poissonSample(attack * (venue === 'H' ? 1.1 : 0.9), r);
    const ga = poissonSample(defense * (venue === 'H' ? 0.9 : 1.1), r);
    return {
      opponent: mates[Math.floor(r() * mates.length)].name,
      venue, gf, ga,
      res: gf > ga ? 'W' : gf === ga ? 'D' : 'L',
    } as FormEntry;
  });
  const shots = 9 + attack * 3.2;
  const absences = ABSENCE_POOL.filter(() => r() < 0.28).slice(0, 2);
  const p: TeamProfile = {
    team,
    last10,
    home: makeSplit(r, 6, attack * 1.12, defense * 0.88),
    away: makeSplit(r, 6, attack * 0.88, defense * 1.12),
    shotsPerGame: shots,
    shotsOnTargetPerGame: shots * 0.36,
    possession: 44 + r() * 14,
    cleanSheetPct: clamp(0.55 - defense * 0.25, 0.08, 0.5),
    failedToScorePct: clamp(0.45 - attack * 0.2, 0.06, 0.4),
    absences,
  };
  profileCache.set(team.id, p);
  return p;
}

function buildStandings(leagueId: string): StandingRow[] {
  const lid = leagueId === 'L3' ? 'L1' : leagueId;
  const rows = TEAMS.filter((t) => t.leagueId === lid).map((t) => {
    const p = buildProfile(t);
    const w = p.home.wins + p.away.wins, d = p.home.draws + p.away.draws, l = p.home.losses + p.away.losses;
    return { teamId: t.id, rank: 0, played: w + d + l, w, d, l, gf: p.home.gf + p.away.gf, ga: p.home.ga + p.away.ga, pts: w * 3 + d };
  });
  rows.sort((a, b) => b.pts - a.pts || b.gf - b.ga - (a.gf - a.ga));
  return rows.map((r, i) => ({ ...r, rank: i + 1 }));
}

const analysisCache = new Map<string, MatchAnalysis>();
export function buildAnalysis(match: Match): MatchAnalysis {
  const hit = analysisCache.get(match.id);
  if (hit) return hit;
  const home = buildProfile(teamById(match.homeId));
  const away = buildProfile(teamById(match.awayId));
  const avg = (s: SplitStats, k: 'gf' | 'ga') => s[k] / s.played;
  const lh = clamp((avg(home.home, 'gf') + avg(away.away, 'ga')) / 2, 0.4, 3.2);
  const la = clamp((avg(away.away, 'gf') + avg(home.home, 'ga')) / 2, 0.3, 3.0);
  const r = mulberry32(hash(match.homeId + match.awayId));
  const h2h: H2HEntry[] = Array.from({ length: 5 }, (_, i) => {
    const flip = r() < 0.5;
    const d = new Date();
    d.setMonth(d.getMonth() - (i + 1) * 7 - Math.floor(r() * 4));
    return {
      date: d.toISOString(),
      homeName: flip ? home.team.name : away.team.name,
      awayName: flip ? away.team.name : home.team.name,
      hg: poissonSample(1.3, r),
      ag: poissonSample(1.1, r),
    };
  });
  const a: MatchAnalysis = {
    matchId: match.id, home, away, h2h,
    standings: buildStandings(match.leagueId),
    probabilities: computeProbabilities(lh, la),
    source: 'demo',
  };
  analysisCache.set(match.id, a);
  return a;
}

// ───────────────────────── Pronostics de démonstration ─────────────────────────

export function seedPredictions(): Prediction[] {
  const out: Prediction[] = [];
  const r = mulberry32(20260901);
  const markets: { market: Prediction['market']; picks: string[] }[] = [
    { market: '1X2', picks: ['Victoire domicile', 'Victoire extérieure', 'Match nul'] },
    { market: 'DC', picks: ['1X', 'X2', '12'] },
    { market: 'OU', picks: ['Plus de 2,5 buts', 'Moins de 2,5 buts', 'Plus de 1,5 buts'] },
    { market: 'BTTS', picks: ['Les deux équipes marquent : Oui', 'Les deux équipes marquent : Non'] },
  ];
  // Historique soldé (fictif) : 36 pronostics sur ~40 jours
  for (let i = 0; i < 36; i++) {
    const lid = r() < 0.55 ? 'L1' : 'L2';
    const pool = TEAMS.filter((t) => t.leagueId === lid);
    const h = pool[Math.floor(r() * pool.length)];
    let a = pool[Math.floor(r() * pool.length)];
    if (a.id === h.id) a = pool[(pool.indexOf(h) + 1) % pool.length];
    const m = markets[Math.floor(r() * markets.length)];
    const pick = m.picks[Math.floor(r() * m.picks.length)];
    const odds = Math.round((1.35 + r() * 1.9) * 100) / 100;
    const roll = r();
    const result = roll < 0.55 ? 'won' : roll < 0.95 ? 'lost' : 'void';
    const d = new Date();
    d.setDate(d.getDate() - 5 - i);
    d.setHours(15 + Math.floor(r() * 5), 0, 0, 0);
    out.push({
      id: `hist_${i + 1}`,
      home: h.name, away: a.name,
      league: LEAGUES.find((l) => l.id === lid)!.name,
      kickoff: d.toISOString(),
      market: m.market, pick, odds, stake: 1 + Math.floor(r() * 3),
      probability: Math.round((0.52 + r() * 0.2) * 100) / 100,
      justification: 'Historique fictif de démonstration : sert uniquement à tester les statistiques.',
      tier: r() < 0.4 ? 'vip' : 'free',
      review: 'validated', published: true, result,
      source: 'demo-seed',
      createdAt: d.toISOString(), updatedAt: d.toISOString(), demo: true,
    });
  }
  const now = new Date().toISOString();
  const mk = (p: Partial<Prediction> & Pick<Prediction, 'id' | 'matchId' | 'market' | 'pick' | 'justification'>): Prediction => {
    const m = getDemoMatches().find((x) => x.id === p.matchId)!;
    return {
      home: teamById(m.homeId).name, away: teamById(m.awayId).name,
      league: LEAGUES.find((l) => l.id === m.leagueId)!.name, kickoff: m.kickoff,
      tier: 'free', review: 'proposed', published: false, result: 'pending',
      source: 'demo-seed', createdAt: now, updatedAt: now, demo: true, ...p,
    };
  };
  // Publiés (validés par un humain, en attente de résultat)
  out.push(
    mk({ id: 'seed_pub_1', matchId: 'm11', market: 'DC', pick: '1X', odds: 1.32, stake: 2, probability: 0.78, tier: 'free', review: 'validated', published: true,
      justification: 'Démo : FC Harmattan reste sur une bonne série à domicile (données fictives). Double chance 1X jugée solide.' }),
    mk({ id: 'seed_pub_2', matchId: 'm13', market: 'OU', pick: 'Plus de 1,5 buts', odds: 1.28, stake: 2, probability: 0.81, tier: 'free', review: 'validated', published: true,
      justification: 'Démo : les deux attaques dépassent 1,3 but par match en moyenne (données fictives).' }),
    mk({ id: 'seed_pub_3', matchId: 'm12', market: '1X2', pick: 'Victoire domicile', odds: 1.95, stake: 3, probability: 0.56, tier: 'vip', review: 'validated', published: true,
      justification: 'Démo VIP : avantage domicile marqué, défense extérieure adverse fragile, absence d\'un titulaire côté visiteur (données fictives).' }),
  );
  // Propositions en attente (exemples)
  out.push(
    mk({ id: 'seed_prop_1', matchId: 'm17', market: 'BTTS', pick: 'Les deux équipes marquent : Oui', probability: 0.61, tier: 'free',
      justification: 'Démo : deux équipes avec moins de 25 % de matchs sans marquer (données fictives).' }),
    mk({ id: 'seed_prop_2', matchId: 'm19', market: 'OU', pick: 'Moins de 2,5 buts', probability: 0.64, tier: 'vip',
      justification: '' }),
    mk({ id: 'seed_prop_3', matchId: 'm21', market: '1X2', pick: 'Victoire domicile', probability: 0.52, tier: 'free',
      justification: 'Démo : léger avantage statistique à domicile (données fictives).' }),
  );
  return out;
}
