import { useMemo, useState } from 'react';
import { Card, DemoBanner, Empty, PageHeader, SectionTitle, Tabs, TextInput, Badge } from '../components/ui';
import { MatchRow } from '../components/MatchRow';
import { useData } from '../store/DataContext';
import { useApp } from '../store/AppStore';
import { dayDiff, fmtDayMid } from '../lib/format';
import type { Match } from '../types';

type Tab = 'today' | 'tomorrow' | 'upcoming' | 'results';

export function Matches() {
  const d = useData();
  const app = useApp();
  const [tab, setTab] = useState<Tab>('today');
  const [league, setLeague] = useState<string>('all');
  const [q, setQ] = useState('');

  const inTab = (m: Match, t: Tab) => {
    const diff = dayDiff(m.kickoff);
    if (t === 'today') return diff === 0;
    if (t === 'tomorrow') return diff === 1;
    if (t === 'upcoming') return diff >= 2;
    return m.status === 'finished';
  };

  const counts = useMemo(() => ({
    today: d.matches.filter((m) => inTab(m, 'today')).length,
    tomorrow: d.matches.filter((m) => inTab(m, 'tomorrow')).length,
    upcoming: d.matches.filter((m) => inTab(m, 'upcoming')).length,
    results: d.matches.filter((m) => inTab(m, 'results')).length,
  }), [d.matches]);

  const list = d.matches
    .filter((m) => inTab(m, tab))
    .filter((m) => league === 'all' || m.leagueId === league)
    .filter((m) => {
      const s = q.trim().toLowerCase();
      return !s || d.team(m.homeId).name.toLowerCase().includes(s) || d.team(m.awayId).name.toLowerCase().includes(s);
    })
    .sort((a, b) => (tab === 'results' ? b.kickoff.localeCompare(a.kickoff) : a.kickoff.localeCompare(b.kickoff)));

  // Regroupement par jour (onglets multi-jours) puis par championnat
  const groups = new Map<string, Match[]>();
  for (const m of list) {
    const key = tab === 'today' || tab === 'tomorrow' ? d.league(m.leagueId).name : fmtDayMid(m.kickoff);
    groups.set(key, [...(groups.get(key) ?? []), m]);
  }
  const predCount = (id: string) => app.predictions.filter((p) => p.matchId === id && p.published).length;

  return (
    <div>
      <PageHeader title="Matchs" subtitle="Rencontres du jour, de demain et à venir, avec statut et résultats." right={<Badge tone="amber">{d.providerName}</Badge>} />
      <div className="mb-5"><DemoBanner compact /></div>

      <Tabs<Tab> value={tab} onChange={setTab} items={[
        { id: 'today', label: "Aujourd'hui", count: counts.today },
        { id: 'tomorrow', label: 'Demain', count: counts.tomorrow },
        { id: 'upcoming', label: 'À venir', count: counts.upcoming },
        { id: 'results', label: 'Résultats', count: counts.results },
      ]} />

      <div className="mb-5 grid gap-3 sm:grid-cols-[1fr_auto]">
        <TextInput value={q} onChange={setQ} placeholder="Rechercher une équipe…" />
        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1">
          {[{ id: 'all', name: 'Tous les championnats' }, ...d.leagues].map((l) => (
            <button key={l.id} onClick={() => setLeague(l.id)}
              className={`cursor-pointer whitespace-nowrap rounded-full px-3 py-2 text-xs font-semibold ring-1 ring-inset transition ${league === l.id ? 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/40' : 'text-slate-400 ring-line hover:bg-white/5'}`}>
              {l.name}
            </button>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <Empty icon="calendar" title="Aucun match" text="Aucune rencontre ne correspond à ces filtres." />
      ) : (
        <div className="space-y-6">
          {[...groups.entries()].map(([title, ms]) => (
            <section key={title}>
              <SectionTitle right={<span className="text-xs text-slate-500">{ms.length} match{ms.length > 1 ? 's' : ''}</span>}>{title}</SectionTitle>
              <div className="space-y-2">
                {ms.map((m) => <MatchRow key={m.id} m={m} showLeague={tab !== 'today' && tab !== 'tomorrow'} predCount={predCount(m.id)} />)}
              </div>
            </section>
          ))}
        </div>
      )}

      <Card className="mt-8">
        <SectionTitle>Championnats disponibles</SectionTitle>
        <div className="grid gap-2 sm:grid-cols-3">
          {d.leagues.map((l) => (
            <button key={l.id} onClick={() => setLeague(l.id)} className="cursor-pointer rounded-xl border border-line bg-ink-800/50 p-3 text-left transition hover:border-emerald-500/40">
              <div className="text-sm font-semibold text-white">{l.name}</div>
              <div className="text-xs text-slate-500">{l.country} · {d.matches.filter((m) => m.leagueId === l.id).length} matchs</div>
            </button>
          ))}
        </div>
        <p className="mt-3 text-xs text-slate-500">Avec API-Football, cette liste affichera tous les championnats couverts par votre abonnement, avec leurs logos officiels.</p>
      </Card>
    </div>
  );
}
