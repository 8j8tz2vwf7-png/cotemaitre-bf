import { useState } from 'react';
import { Badge, Button, Card, Field, Icon, Logo, TextInput } from '../components/ui';
import { navigate } from '../lib/router';
import { useApp } from '../store/AppStore';
import { DEMO_ADMIN, authInfo } from '../services/auth';

export function Login() {
  const app = useApp();
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: string, p: string) => {
    setBusy(true);
    const ok = await app.login(e, p);
    setBusy(false);
    if (ok) navigate('/admin');
  };

  if (app.isAdmin) {
    return <Card className="mx-auto mt-10 max-w-md text-center"><p className="text-slate-300">Vous êtes connecté en administrateur.</p><Button className="mt-4" onClick={() => navigate('/admin')}>Ouvrir l'espace admin</Button></Card>;
  }

  return (
    <div className="mx-auto mt-4 max-w-md sm:mt-12">
      <div className="mb-6 flex justify-center"><Logo /></div>
      <Card>
        <h1 className="font-display text-xl font-bold text-white">Connexion administrateur</h1>
        <p className="mt-1 text-sm text-slate-400">Accès réservé à l'équipe COTEMAÎTRE BF.</p>
        <form className="mt-5 space-y-4" onSubmit={(ev: { preventDefault(): void }) => { ev.preventDefault(); submit(email, pw); }}>
          <Field label="Adresse e-mail"><TextInput type="email" value={email} onChange={setEmail} placeholder="admin@exemple.com" autoFocus /></Field>
          <Field label="Mot de passe"><TextInput type="password" value={pw} onChange={setPw} placeholder="••••••••" /></Field>
          <Button type="submit" className="w-full" disabled={busy}>{busy ? 'Connexion…' : 'Se connecter'}</Button>
        </form>
      </Card>

      {authInfo.kind === 'supabase' ? (
        <Card className="mt-4">
          <div className="flex flex-wrap items-center gap-2"><Badge tone="emerald">Authentification Supabase active</Badge></div>
          <p className="mt-2 text-xs leading-relaxed text-slate-400">
            Connexion réelle via Supabase Auth. Les identifiants de démonstration sont désactivés. Seuls les comptes dont le rôle « admin » est inscrit en base accèdent à l'espace administrateur. Les matchs et pronostics affichés restent des données de démonstration jusqu'à la prochaine étape.
          </p>
        </Card>
      ) : (
        <Card gold className="mt-4">
          <div className="flex flex-wrap items-center gap-2"><Badge tone="amber">MODE DÉMONSTRATION</Badge>
            <Badge tone={authInfo.envState === 'invalid' ? 'red' : 'slate'}>{authInfo.envState === 'invalid' ? 'Configuration Supabase refusée' : 'Supabase non configuré'}</Badge></div>
          <p className="mt-2 text-xs leading-relaxed text-slate-400">
            Authentification simulée localement pour tester l'interface. Ces identifiants sont visibles dans le code du navigateur : ils ne protègent rien. Dès que Supabase est configuré (voir le README), cette connexion est remplacée par la vraie authentification.
          </p>
          {authInfo.envState === 'invalid' && <p className="mt-2 rounded-lg bg-red-500/10 p-2.5 text-xs text-red-200">{authInfo.reason}</p>}
          <div className="mt-3 rounded-lg bg-black/30 p-3 font-mono text-xs text-slate-300">
            <div>{DEMO_ADMIN.email}</div><div>{DEMO_ADMIN.password}</div>
          </div>
          <Button variant="outline" size="sm" className="mt-3 w-full" disabled={busy} onClick={() => submit(DEMO_ADMIN.email, DEMO_ADMIN.password)}>
            <Icon name="shield" className="size-4" /> Connexion démo en un clic
          </Button>
        </Card>
      )}
    </div>
  );
}
