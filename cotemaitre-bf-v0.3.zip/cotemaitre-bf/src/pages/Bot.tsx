import { Badge, Button, Card, DemoBanner, Empty, Icon, PageHeader, SectionTitle, DemoBadge } from '../components/ui';
import { CONFIG } from '../config';
import { authInfo } from '../services/auth';
import { navigate } from '../lib/router';
import { useApp } from '../store/AppStore';
import { useData } from '../store/DataContext';
import { fmtDateTime } from '../lib/format';
import { LIVE } from '../lib/mode';
import { sportsSourceStatus } from '../services/sportsSource';

const SERVICES = [
  { name: 'API-Football', detail: 'Données sportives réelles', env: 'APIFOOTBALL_KEY (serveur uniquement)' },
  { name: 'Supabase', detail: 'Base de données & authentification', env: 'SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY (serveur)' },
  { name: 'Planificateur', detail: `Scan toutes les ${CONFIG.scanIntervalMinutes} minutes`, env: 'Cron Supabase / worker' },
  { name: 'Moteur statistique', detail: 'Modèle de prédiction sur données réelles', env: 'Edge Function / worker' },
];

export function Bot() {
  const app = useApp();
  const d = useData();
  const last = app.scans[0];
  const src = sportsSourceStatus(d.sources);
  const pending = app.predictions.filter((p) => p.review === 'proposed').length;
  const tile = (label: string, value: string | number, hint?: string) => (
    <div className="rounded-xl border border-line bg-ink-900/70 p-4">
      <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">{label}</div>
      <div className="mt-1.5 font-display text-xl font-bold text-white sm:text-2xl">{value}</div>
      {hint && <div className="mt-0.5 text-xs text-slate-500">{hint}</div>}
    </div>
  );

  return (
    <div>
      <PageHeader title="AI FOOTBALL BOT" subtitle="Scanner, analyser et proposer des sélections. Chaque proposition attend une validation humaine : rien n'est publié automatiquement." />

      <Card gold className="mb-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative grid size-14 place-items-center rounded-2xl bg-amber-500/10 ring-1 ring-amber-500/30">
              <Icon name="bot" className="size-7 text-amber-300" />
              <span className="absolute -right-1 -top-1 size-3 animate-pulse-soft rounded-full bg-amber-400" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-display text-lg font-bold text-white">État du bot</span>
                {LIVE ? <Badge tone={src.apiConnected ? 'emerald' : 'amber'}>{src.label}</Badge> : <Badge tone="amber">MODE DÉMONSTRATION</Badge>}
              </div>
              {LIVE
                ? <p className="mt-1 max-w-xl text-sm text-slate-400">{src.detail} Le scan automatique n'est <strong className="text-slate-200">pas actif</strong> : aucune API n'est connectée et aucun scan n'est simulé. Les propositions se créent à la main (page d'un match).</p>
                : <p className="mt-1 max-w-xl text-sm text-slate-400">Hors ligne : aucune connexion à API-Football. Le bouton ci-dessous lance un <strong className="text-slate-200">scan local sur données fictives</strong> pour tester le circuit de validation.</p>}
            </div>
          </div>
          <Button size="lg" variant="gold" disabled={app.scanning} onClick={app.isAdmin ? app.runScan : () => { app.notify('Connectez-vous en administrateur pour scanner.', 'info'); navigate('/connexion'); }}>
            <Icon name="refresh" className={`size-4 ${app.scanning ? 'animate-spin-slow' : ''}`} />
            {app.scanning ? 'Analyse en cours…' : 'SCANNER MAINTENANT'}
          </Button>
        </div>
        {!app.isAdmin && <p className="mt-3 text-xs text-slate-500"><Icon name="lock" className="mr-1 inline size-3" />Le scan est réservé à l'administrateur.</p>}
      </Card>

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tile('Dernier scan', last ? fmtDateTime(last.at) : 'Jamais', last ? (last.mode === 'DEMO' ? 'Mode démo' : 'Scan réel') : 'Aucun scan lancé')}
        {tile('Prochain scan', 'Non programmé', `Prévu : toutes les ${CONFIG.scanIntervalMinutes} min après intégration`)}
        {tile('Matchs détectés', last ? last.detected : 0, last ? 'Dernier scan' : undefined)}
        {tile('Matchs analysés', last ? last.analyzed : 0, last ? 'Dernier scan' : undefined)}
        {tile('Matchs écartés', last ? last.discarded : 0, last ? 'Sous les seuils' : undefined)}
        {tile('En attente de validation', pending, 'Propositions à relire')}
        {tile('Scans effectués', app.scans.length)}
        {tile('Source de données', d.mode === 'demo' ? 'Démo' : src.apiConnected ? 'API-Football' : 'Manuel', d.mode === 'demo' ? d.providerName : src.detail)}
      </div>

      <div className="mb-6 flex flex-wrap gap-2">
        <Button variant="outline" onClick={() => navigate('/admin')}><Icon name="shield" className="size-4" /> Examiner les propositions ({pending})</Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <section className="lg:col-span-3">
          <SectionTitle right={<DemoBadge />}>Historique des scans</SectionTitle>
          {app.scans.length === 0 ? (
            <Empty icon="history" title="Aucun scan pour le moment" text="Lancez un scan démo pour voir apparaître l'historique et des propositions en attente." />
          ) : (
            <div className="space-y-2">
              {app.scans.map((s) => (
                <details key={s.id} className="group rounded-xl border border-line bg-ink-900/70 p-4">
                  <summary className="flex cursor-pointer flex-wrap items-center gap-x-4 gap-y-1 text-sm">
                    <span className="font-semibold text-white">{fmtDateTime(s.at)}</span>
                    <Badge tone="amber">{s.mode}</Badge>
                    <span className="text-slate-400">{s.detected} détectés · {s.analyzed} analysés · {s.discarded} écartés</span>
                    <Badge tone={s.proposals ? 'emerald' : 'slate'}>{s.proposals} nouvelle(s) proposition(s)</Badge>
                  </summary>
                  <ul className="mt-3 space-y-1.5 border-t border-line pt-3 text-xs">
                    {s.details.map((x, i) => (
                      <li key={i} className="flex flex-wrap items-center gap-2 text-slate-400">
                        <Badge tone={x.outcome === 'proposed' ? 'emerald' : x.outcome === 'existing' ? 'blue' : 'slate'}>{x.outcome === 'proposed' ? 'Proposé' : x.outcome === 'existing' ? 'Déjà présent' : 'Écarté'}</Badge>
                        <span className="text-slate-200">{x.label}</span><span>— {x.note}</span>
                      </li>
                    ))}
                  </ul>
                </details>
              ))}
            </div>
          )}
        </section>

        <section className="lg:col-span-2">
          <SectionTitle>Connexions techniques</SectionTitle>
          <Card className="divide-y divide-line !p-0">
            {SERVICES.map((s) => (
              <div key={s.name} className="p-4">
                <div className="flex items-center justify-between gap-2"><span className="font-semibold text-white">{s.name}</span>
                  {s.name === 'Supabase' && LIVE
                    ? (d.error ? <Badge tone="red">Lecture en erreur</Badge> : <Badge tone="emerald">Connectée · données lues en base</Badge>)
                    : s.name === 'API-Football' && LIVE ? <Badge tone={src.apiConnected ? 'emerald' : 'amber'}>{src.apiConnected ? 'Données synchronisées' : 'Non connecté · mode manuel'}</Badge>
                    : s.name === 'Supabase' && authInfo.envState === 'configured'
                    ? <Badge tone="amber">Auth configurée · données non branchées</Badge>
                    : <Badge tone="red">{s.name === 'Supabase' && authInfo.envState === 'invalid' ? 'Configuration refusée' : 'Non connecté'}</Badge>}</div>
                <div className="mt-0.5 text-xs text-slate-400">{s.detail}</div>
                <div className="mt-1 font-mono text-[11px] text-slate-600">{s.env}</div>
              </div>
            ))}
          </Card>
          <div className="mt-4"><DemoBanner compact /></div>
        </section>
      </div>
    </div>
  );
}
