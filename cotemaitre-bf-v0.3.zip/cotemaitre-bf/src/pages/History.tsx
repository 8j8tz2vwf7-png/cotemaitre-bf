import { useState } from 'react';
import { Badge, Button, Card, DemoBanner, Icon, PageHeader, ResultBadge, SectionTitle, StatCard, Tabs } from '../components/ui';
import { ProfitChart } from '../components/Charts';
import { useApp } from '../store/AppStore';
import { byLeague, byMarket, computePerf, isSettled, profitCurve } from '../lib/stats';
import { fmtDateTime, fmtShort, num, pct, signed } from '../lib/format';
import { navigate } from '../lib/router';
import { MARKET_LABEL } from '../types';

type Filter = 'all' | 'free' | 'vip';

function PerfTable({ rows, title }: { rows: ReturnType<typeof byLeague>; title: string }) {
  return (
    <Card className="overflow-x-auto !p-0">
      <div className="border-b border-line px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-400">{title}</div>
      <table className="w-full min-w-[420px] text-sm">
        <thead><tr className="text-left text-xs text-slate-500"><th className="px-4 py-2 font-medium">Catégorie</th><th className="py-2 text-right font-medium">G</th><th className="py-2 text-right font-medium">P</th><th className="py-2 text-right font-medium">Réussite</th><th className="px-4 py-2 text-right font-medium">ROI</th></tr></thead>
        <tbody>
          {rows.length === 0 && <tr><td colSpan={5} className="px-4 py-4 text-slate-500">Aucune donnée.</td></tr>}
          {rows.map((r) => (
            <tr key={r.name} className="border-t border-line/60">
              <td className="px-4 py-2.5 text-slate-200">{r.name}</td>
              <td className="py-2.5 text-right font-mono text-emerald-300">{r.won}</td>
              <td className="py-2.5 text-right font-mono text-red-300">{r.lost}</td>
              <td className="py-2.5 text-right">
                <div className="ml-auto flex w-24 items-center justify-end gap-2"><span className="font-mono text-slate-200">{r.winRate === null ? '—' : pct(r.winRate, 0)}</span></div>
                <div className="ml-auto mt-1 h-1 w-24 overflow-hidden rounded-full bg-white/5"><div className="bar-grow h-full bg-emerald-500" style={{ width: `${(r.winRate ?? 0) * 100}%` }} /></div>
              </td>
              <td className={`px-4 py-2.5 text-right font-mono ${r.roi === null ? 'text-slate-500' : r.roi >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>{r.roi === null ? '—' : `${r.roi > 0 ? '+' : ''}${pct(r.roi, 1)}`}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  );
}

export function History() {
  const app = useApp();
  const [f, setF] = useState<Filter>('all');
  // Seul le publié + validé compte dans l'historique ; le VIP n'est visible que pour un accès VIP (la base le garantit aussi).
  const visible = app.predictions.filter((p) => p.published && p.review === 'validated' && (p.tier === 'free' || app.hasVip));
  const locked = f === 'vip' && !app.hasVip;
  const list = locked ? [] : visible.filter((p) => f === 'all' || p.tier === f);
  const perf = computePerf(list);
  const settled = list.filter(isSettled).sort((a, b) => b.kickoff.localeCompare(a.kickoff));

  return (
    <div>
      <PageHeader title="Historique & performances" subtitle="Calculé uniquement à partir des pronostics publiés dont le résultat est enregistré." />
      <div className="mb-5"><DemoBanner /></div>
      <Tabs<Filter> value={f} onChange={setF} items={[{ id: 'all', label: app.hasVip ? 'Tous' : 'Gratuits + aperçu' }, { id: 'free', label: 'Gratuit' }, { id: 'vip', label: 'VIP', gold: true }]} />

      {locked ? (
        <Card gold className="mb-6 text-center">
          <Icon name="lock" className="mx-auto mb-2 size-6 text-amber-300" />
          <div className="font-display text-lg font-bold text-white">Historique VIP réservé aux abonnés</div>
          <p className="mx-auto mt-1 max-w-md text-sm text-slate-400">Les pronostics, résultats et statistiques VIP ne sont accessibles qu'avec un abonnement VIP actif. L'historique gratuit reste public et vérifiable.</p>
          <div className="mt-4"><Button variant="outline" onClick={() => setF('free')}>Voir l'historique gratuit</Button>{!app.isAdmin && <Button className="ml-2" variant="ghost" onClick={() => navigate('/connexion')}>Connexion</Button>}</div>
        </Card>
      ) : (<>

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Gagnés" value={perf.won} icon="check" />
        <StatCard label="Perdus" value={perf.lost} icon="x" />
        <StatCard label="Annulés" value={perf.void} icon="alert" />
        <StatCard label="Taux de réussite" value={perf.winRate === null ? '—' : pct(perf.winRate, 1)} icon="trophy" tone="gold" hint="Gagnés ÷ (gagnés + perdus)" />
        <StatCard label="ROI théorique" value={perf.roi === null ? '—' : `${perf.roi > 0 ? '+' : ''}${pct(perf.roi, 1)}`} icon="chart" tone="gold" hint={perf.roi === null ? 'Cotes et mises non renseignées' : `Sur ${perf.withOdds} pari(s) avec cote et mise`} />
        <StatCard label="Mises totales" value={`${perf.staked} u`} icon="target" />
        <StatCard label="Profit" value={`${signed(perf.profit, 1)} u`} icon="chart" />
        <StatCard label="Soldés" value={perf.settled} icon="history" />
      </div>

      <section className="mb-6">
        <SectionTitle>Profit cumulé</SectionTitle>
        <Card><ProfitChart points={profitCurve(list)} /></Card>
      </section>

      <div className="mb-6 grid gap-4 lg:grid-cols-2">
        <PerfTable rows={byLeague(list)} title="Par championnat" />
        <PerfTable rows={byMarket(list)} title="Par type de pari" />
      </div>

      <section>
        <SectionTitle right={<Badge tone="slate">{settled.length} résultats</Badge>}>Derniers résultats soldés</SectionTitle>
        <Card className="divide-y divide-line !p-0">
          {settled.slice(0, 15).map((p) => (
            <div key={p.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-4 py-3 text-sm">
              <span className="w-14 text-xs text-slate-500">{fmtShort(p.kickoff)}</span>
              <span className="min-w-0 flex-1 truncate text-slate-200">{p.home} – {p.away}</span>
              <span className="text-xs text-slate-500">{MARKET_LABEL[p.market]}</span>
              <span className="text-emerald-300">{p.pick}</span>
              <span className="font-mono text-slate-400">{p.odds ? num(p.odds) : '—'}</span>
              {p.publishedAt && <span className="text-[11px] text-slate-500">publié le {fmtDateTime(p.publishedAt)}</span>}
              <Badge tone={p.tier === 'vip' ? 'gold' : 'emerald'}>{p.tier === 'vip' ? 'VIP' : 'Gratuit'}</Badge>
              <ResultBadge r={p.result} />
            </div>
          ))}
        </Card>
      </section>
      </>)}
    </div>
  );
}
