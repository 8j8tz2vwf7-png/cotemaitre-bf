import { useState } from 'react';
import { LIVE } from '../lib/mode';
import { Badge, Button, Card, DemoBanner, Empty, Field, FormChips, Icon, Modal, ProbBar, Select, SectionTitle, TeamCrest, TextArea, TextInput, DemoBadge } from '../components/ui';
import { StatusBadge } from '../components/MatchRow';
import { Link, navigate } from '../lib/router';
import { useAnalysis, useData } from '../store/DataContext';
import { useApp } from '../store/AppStore';
import { fmtDateTime, fmtYear, num, pct, uid } from '../lib/format';
import { MARKET_LABEL, PICKS, type Market, type SplitStats, type TeamProfile } from '../types';

const avg = (s: SplitStats, k: 'gf' | 'ga') => num(s[k] / s.played);

function TeamColumn({ p, side }: { p: TeamProfile; side: 'home' | 'away' }) {
  const wins = p.last10.filter((x) => x.res === 'W').length;
  const draws = p.last10.filter((x) => x.res === 'D').length;
  const losses = p.last10.filter((x) => x.res === 'L').length;
  return (
    <Card>
      <div className="mb-4 flex items-center gap-3">
        <TeamCrest team={p.team} size={44} />
        <div>
          <div className="font-display font-bold text-white">{p.team.name}</div>
          <div className="text-[11px] uppercase tracking-wider text-slate-500">{side === 'home' ? 'Domicile' : 'Extérieur'}</div>
        </div>
      </div>
      <div className="text-[11px] uppercase tracking-wider text-slate-500">Forme — 10 derniers matchs</div>
      <div className="mt-1.5"><FormChips results={p.last10.map((x) => x.res)} /></div>
      <div className="mt-1 text-xs text-slate-500">{wins}V · {draws}N · {losses}D</div>
      <table className="mt-4 w-full text-xs">
        <thead><tr className="text-left text-slate-500"><th className="pb-1.5 font-medium"></th><th className="pb-1.5 text-right font-medium">J</th><th className="pb-1.5 text-right font-medium">V-N-D</th><th className="pb-1.5 text-right font-medium">BM/m</th><th className="pb-1.5 text-right font-medium">BE/m</th></tr></thead>
        <tbody className="font-mono text-slate-200">
          {([['Domicile', p.home], ['Extérieur', p.away]] as const).map(([lab, s]) => (
            <tr key={lab} className={`border-t border-line ${(lab === 'Domicile') === (side === 'home') ? 'text-emerald-300' : ''}`}>
              <td className="py-1.5 font-sans font-medium">{lab}</td>
              <td className="text-right">{s.played}</td>
              <td className="text-right">{s.wins}-{s.draws}-{s.losses}</td>
              <td className="text-right">{avg(s, 'gf')}</td>
              <td className="text-right">{avg(s, 'ga')}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
        <Stat label="Tirs / match" value={num(p.shotsPerGame, 1)} />
        <Stat label="Tirs cadrés / match" value={num(p.shotsOnTargetPerGame, 1)} />
        <Stat label="Possession moy." value={pct(p.possession / 100, 0)} />
        <Stat label="Matchs sans encaisser" value={pct(p.cleanSheetPct, 0)} />
        <Stat label="Matchs sans marquer" value={pct(p.failedToScorePct, 0)} />
      </div>
      <div className="mt-4">
        <div className="text-[11px] uppercase tracking-wider text-slate-500">Absences</div>
        {p.absences.length === 0
          ? <div className="mt-1 text-xs text-slate-500">Aucune absence signalée (démo).</div>
          : <ul className="mt-1 space-y-1">{p.absences.map((a, i) => <li key={i} className="flex items-center justify-between text-xs text-slate-300"><span>{a.role}</span><Badge tone={a.reason === 'Incertain' ? 'amber' : 'red'}>{a.reason}</Badge></li>)}</ul>}
      </div>
      <details className="mt-4 text-xs">
        <summary className="cursor-pointer font-semibold text-emerald-400">Détail des 10 derniers matchs</summary>
        <ul className="mt-2 space-y-1">
          {p.last10.map((x, i) => (
            <li key={i} className="flex justify-between text-slate-400"><span>{x.venue === 'H' ? 'vs' : '@'} {x.opponent}</span><span className="font-mono text-slate-200">{x.gf}–{x.ga}</span></li>
          ))}
        </ul>
      </details>
    </Card>
  );
}
const Stat = ({ label, value }: { label: string; value: string }) => (
  <div className="rounded-lg bg-white/[0.03] px-2.5 py-2"><div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div><div className="font-mono font-semibold text-white">{value}</div></div>
);

export function Analysis({ matchId }: { matchId: string }) {
  const d = useData();
  const app = useApp();
  const m = d.match(matchId);
  const { data: a, loading } = useAnalysis(matchId);
  const [open, setOpen] = useState(false);
  const [market, setMarket] = useState<Market>('1X2');
  const [pick, setPick] = useState(PICKS['1X2'][0]);
  const [odds, setOdds] = useState('');
  const [just, setJust] = useState('');

  if (!m) return <Empty icon="alert" title="Match introuvable" action={<Button onClick={() => navigate('/matchs')}>Retour aux matchs</Button>} />;
  if (loading) return <div className="py-20 text-center text-slate-500">Chargement de l'analyse…</div>;
  if (!a && !LIVE) return <Empty icon="alert" title="Analyse indisponible" action={<Button onClick={() => navigate('/matchs')}>Retour aux matchs</Button>} />;

  // En mode réel, aucune analyse statistique n'est calculée (moteur non activé) : on n'affiche JAMAIS d'analyse inventée.
  const h = d.team(m.homeId), aw = d.team(m.awayId);
  const p = a?.probabilities;
  const maxHome = p ? Math.max(p.home, p.draw, p.away) : 0;
  const related = app.predictions.filter((x) => x.matchId === m.id && x.published && x.review === 'validated' && (x.tier === 'free' || app.hasVip));

  const create = () => {
    app.addManual({
      id: uid('man'), matchId: m.id, home: h.name, away: aw.name, league: d.league(m.leagueId).name, kickoff: m.kickoff,
      market, pick, odds: odds ? Number(odds.replace(',', '.')) : undefined, justification: just,
      probability: p && market === '1X2' ? (pick === PICKS['1X2'][0] ? p.home : pick === PICKS['1X2'][1] ? p.draw : p.away) : undefined,
      tier: 'free', review: 'proposed', published: false, result: 'pending', source: 'admin',
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), demo: !LIVE,
    });
    setOpen(false);
  };

  return (
    <div className="space-y-6">
      <Link to="/matchs" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white">← Retour aux matchs</Link>

      <Card className="!p-0 overflow-hidden">
        <div className="bg-gradient-to-r from-emerald-500/10 via-transparent to-gold-500/10 p-5 sm:p-7">
          <div className="mb-4 flex flex-wrap items-center gap-2 text-xs text-slate-400">
            <span>{d.league(m.leagueId).name}</span><span>·</span><span>{fmtDateTime(m.kickoff)}</span><StatusBadge m={m} />{!LIVE && <DemoBadge label="ANALYSE DÉMO" />}
          </div>
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
            <div className="flex flex-col items-center gap-2 text-center sm:flex-row sm:justify-end sm:text-right"><span className="order-2 font-display text-base font-bold text-white sm:order-1 sm:text-2xl">{h.name}</span><span className="order-1 sm:order-2"><TeamCrest team={h} size={56} /></span></div>
            <div className="text-center">{m.status === 'finished' ? <div className="font-display text-3xl font-extrabold text-white sm:text-5xl">{m.homeGoals} – {m.awayGoals}</div> : <div className="text-sm font-bold text-slate-500">VS</div>}</div>
            <div className="flex flex-col items-center gap-2 text-center sm:flex-row sm:text-left"><TeamCrest team={aw} size={56} /><span className="font-display text-base font-bold text-white sm:text-2xl">{aw.name}</span></div>
          </div>
        </div>
      </Card>
      {!LIVE && <DemoBanner compact />}

      {a && p ? (<>
      <div className="grid gap-4 md:grid-cols-2">
        <TeamColumn p={a.home} side="home" />
        <TeamColumn p={a.away} side="away" />
      </div>

      <section>
        <SectionTitle right={<Badge tone="amber">Poisson · données fictives</Badge>}>Probabilités estimées</SectionTitle>
        <div className="grid gap-4 lg:grid-cols-3">
          <Card>
            <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">Résultat 1N2</div>
            <div className="space-y-3">
              <ProbBar label={`Victoire ${h.name}`} value={p.home} highlight={p.home === maxHome} />
              <ProbBar label="Match nul" value={p.draw} tone="slate" highlight={p.draw === maxHome} />
              <ProbBar label={`Victoire ${aw.name}`} value={p.away} highlight={p.away === maxHome} />
            </div>
            <div className="mb-3 mt-5 text-xs font-semibold uppercase tracking-wider text-slate-400">Double chance</div>
            <div className="space-y-3">
              <ProbBar label="1X" value={p.dc1X} /><ProbBar label="X2" value={p.dcX2} /><ProbBar label="12" value={p.dc12} />
            </div>
          </Card>
          <Card>
            <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">Over / Under</div>
            <div className="space-y-3">
              {(['1.5', '2.5', '3.5'] as const).map((k) => <ProbBar key={k} label={`Plus de ${k.replace('.', ',')} buts`} value={p.over[k]} tone="gold" />)}
            </div>
            <div className="mb-3 mt-5 text-xs font-semibold uppercase tracking-wider text-slate-400">Les deux équipes marquent</div>
            <div className="space-y-3"><ProbBar label="BTTS — Oui" value={p.btts} tone="gold" /><ProbBar label="BTTS — Non" value={1 - p.btts} tone="slate" /></div>
          </Card>
          <Card>
            <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">Scores exacts les plus probables</div>
            <ul className="space-y-2">
              {p.scores.map((s, i) => (
                <li key={s.score} className="flex items-center justify-between rounded-lg bg-white/[0.03] px-3 py-2 text-sm">
                  <span className="font-mono font-bold text-white">{s.score.replace('-', ' – ')}</span>
                  <span className={`font-mono ${i === 0 ? 'text-emerald-300' : 'text-slate-300'}`}>{pct(s.p, 1)}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-[11px] leading-relaxed text-slate-500">Buts attendus : {num(p.lambdaHome)} (dom.) / {num(p.lambdaAway)} (ext.). Ce calcul est une estimation, pas une prédiction garantie.</p>
          </Card>
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section>
          <SectionTitle>Confrontations directes</SectionTitle>
          <Card className="divide-y divide-line !p-0">
            {a.h2h.map((e, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-3 text-sm">
                <span className="w-20 shrink-0 text-xs text-slate-500">{fmtYear(e.date)}</span>
                <span className="min-w-0 flex-1 truncate text-right text-slate-200">{e.homeName}</span>
                <span className="rounded-md bg-white/5 px-2 py-0.5 font-mono font-bold text-white">{e.hg} – {e.ag}</span>
                <span className="min-w-0 flex-1 truncate text-slate-200">{e.awayName}</span>
              </div>
            ))}
          </Card>
        </section>
        <section>
          <SectionTitle>Classement</SectionTitle>
          <Card className="overflow-x-auto !p-0">
            <table className="w-full text-xs">
              <thead><tr className="border-b border-line text-left text-slate-500"><th className="px-3 py-2 font-medium">#</th><th className="py-2 font-medium">Équipe</th><th className="py-2 text-right font-medium">J</th><th className="py-2 text-right font-medium">V</th><th className="py-2 text-right font-medium">N</th><th className="py-2 text-right font-medium">D</th><th className="py-2 text-right font-medium">Diff</th><th className="px-3 py-2 text-right font-medium">Pts</th></tr></thead>
              <tbody className="font-mono">
                {a.standings.map((r) => {
                  const mine = r.teamId === h.id || r.teamId === aw.id;
                  return (
                    <tr key={r.teamId} className={`border-b border-line/60 ${mine ? 'bg-emerald-500/[0.07] text-emerald-200' : 'text-slate-300'}`}>
                      <td className="px-3 py-2">{r.rank}</td>
                      <td className="py-2 font-sans font-medium">{d.team(r.teamId).name}</td>
                      <td className="py-2 text-right">{r.played}</td><td className="py-2 text-right">{r.w}</td><td className="py-2 text-right">{r.d}</td><td className="py-2 text-right">{r.l}</td>
                      <td className="py-2 text-right">{r.gf - r.ga > 0 ? '+' : ''}{r.gf - r.ga}</td>
                      <td className="px-3 py-2 text-right font-bold">{r.pts}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>
        </section>
      </div>

      </>) : (
        <Card><p className="text-sm text-slate-400"><span className="font-semibold text-white">Analyse statistique non disponible.</span> Le moteur d'analyse n'est pas encore activé : aucune probabilité n'est affichée plutôt que d'en inventer. Vous pouvez néanmoins proposer un pronostic manuel (validation humaine obligatoire).</p></Card>
      )}

      <section>
        <SectionTitle>Pronostics publiés sur ce match</SectionTitle>
        {related.length === 0
          ? <Card><p className="text-sm text-slate-500">Aucun pronostic publié pour cette rencontre. Un pronostic n'apparaît ici qu'après validation et publication par un administrateur.</p></Card>
          : <div className="space-y-2">{related.map((x) => <Card key={x.id}><div className="flex items-center justify-between gap-3 text-sm"><span><Badge tone={x.tier === 'vip' ? 'gold' : 'emerald'}>{x.tier === 'vip' ? 'VIP' : 'Gratuit'}</Badge> <span className="ml-2 font-semibold text-white">{x.pick}</span> <span className="text-slate-500">· {MARKET_LABEL[x.market]}</span></span><span className="font-mono text-slate-300">{x.odds ? num(x.odds) : '—'}</span></div></Card>)}</div>}
      </section>

      {app.isAdmin && m.status !== 'finished' && (
        <div className="flex justify-end">
          <Button variant="gold" onClick={() => setOpen(true)}><Icon name="plus" className="size-4" /> Proposer un pronostic sur ce match</Button>
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Nouvelle proposition (manuelle)">
        <div className="space-y-4">
          <Field label="Marché"><Select value={market} onChange={(v) => { setMarket(v as Market); setPick(PICKS[v as Market][0]); }} options={(Object.keys(PICKS) as Market[]).map((k) => ({ value: k, label: MARKET_LABEL[k] }))} /></Field>
          <Field label="Sélection"><Select value={pick} onChange={setPick} options={PICKS[market].map((x) => ({ value: x, label: x }))} /></Field>
          <Field label="Cote (optionnel)" hint="Saisie manuelle tant qu'API-Football n'est pas connecté."><TextInput value={odds} onChange={setOdds} placeholder="ex. 1,85" /></Field>
          <Field label="Justification"><TextArea value={just} onChange={setJust} placeholder="Pourquoi cette sélection ?" /></Field>
          <div className="flex justify-end gap-2"><Button variant="ghost" onClick={() => setOpen(false)}>Annuler</Button><Button onClick={create}>Créer la proposition</Button></div>
        </div>
      </Modal>
    </div>
  );
}
