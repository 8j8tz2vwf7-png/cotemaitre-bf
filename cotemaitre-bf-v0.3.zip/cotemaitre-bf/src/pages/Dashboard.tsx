import { LIVE } from '../lib/mode';
import { Badge, Button, Card, DemoBadge, DemoBanner, Icon, LogoMark, SectionTitle, StatCard, TeamCrest } from '../components/ui';
import { PredictionCard } from '../components/PredictionCard';
import { ProfitChart } from '../components/Charts';
import { Link, navigate } from '../lib/router';
import { useApp } from '../store/AppStore';
import { useData } from '../store/DataContext';
import { computePerf, profitCurve } from '../lib/stats';
import { fmtDateTime, fmtDayLong, fmtTime, pct } from '../lib/format';

export function Dashboard() {
  const app = useApp();
  const d = useData();
  const preds = app.predictions;
  const perf = computePerf(preds);
  const analyzed = new Set([...app.analyzedIds, ...preds.filter((p) => p.matchId).map((p) => p.matchId!)]).size;
  const published = preds.filter((p) => p.published && p.review === 'validated').sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, 4);
  const results = d.matches.filter((m) => m.status === 'finished').sort((a, b) => b.kickoff.localeCompare(a.kickoff)).slice(0, 5);
  const pending = preds.filter((p) => p.review === 'proposed').length;

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-br from-ink-800 via-ink-900 to-ink-950 p-6 sm:p-8">
        <div className="pointer-events-none absolute -right-16 -top-16 size-64 rounded-full bg-emerald-500/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 left-1/3 size-56 rounded-full bg-gold-500/10 blur-3xl" />
        <div className="relative flex flex-wrap items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-4">
              <LogoMark size={56} />
              <div>
                <h1 className="font-display text-2xl font-extrabold tracking-[0.12em] text-white sm:text-4xl">COTEMAÎTRE <span className="gold-text">BF</span></h1>
                <p className="mt-1 text-[11px] font-medium tracking-[0.2em] text-emerald-400 sm:text-xs">L'INTELLIGENCE AU SERVICE DU FOOTBALL.</p>
              </div>
            </div>
            <p className="mt-4 flex items-center gap-2 text-sm text-slate-400"><Icon name="calendar" className="size-4 text-emerald-400" />{fmtDayLong(new Date())}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => navigate('/matchs')}><Icon name="calendar" className="size-4" /> Voir les matchs</Button>
            <Button variant="gold" onClick={() => navigate('/pronostics')}><Icon name="crown" className="size-4" /> Pronostics</Button>
          </div>
        </div>
      </div>

      <DemoBanner />

      <section>
        <SectionTitle right={<DemoBadge label="DONNÉES DÉMO" />}>Vue d'ensemble</SectionTitle>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="Matchs disponibles" value={d.matches.length} icon="calendar" hint="Toutes compétitions" />
          <StatCard label="Matchs analysés" value={analyzed} icon="chart" hint={LIVE ? 'Analyses enregistrées' : 'Par le moteur démo'} />
          <StatCard label="Pronostics proposés" value={preds.length} icon="bot" hint={`${pending} en attente`} />
          <StatCard label="Pronostics validés" value={preds.filter((p) => p.review === 'validated').length} icon="check" hint="Validation humaine" />
          <StatCard label="Taux de réussite" value={perf.winRate === null ? '—' : pct(perf.winRate, 0)} icon="trophy" tone="gold" hint={`${perf.won} gagnés / ${perf.lost} perdus`} />
          <StatCard label="Publiés" value={preds.filter((p) => p.published).length} icon="eye" hint="Visibles du public" />
          <StatCard label="Matchs aujourd'hui" value={d.matches.filter((m) => new Date(m.kickoff).toDateString() === new Date().toDateString()).length} icon="clock" />
          <StatCard label="Scans effectués" value={app.scans.length} icon="refresh" hint={LIVE ? 'Scans réels' : 'Mode démo'} />
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-5">
        <section className="lg:col-span-3">
          <SectionTitle right={<Link to="/pronostics" className="text-xs font-semibold text-emerald-400 hover:underline">Tout voir →</Link>}>Derniers pronostics publiés</SectionTitle>
          <div className="space-y-3">
            {published.length === 0 && <Card><p className="text-sm text-slate-500">Aucun pronostic publié. Les publications se font depuis l'espace administrateur, après validation humaine.</p></Card>}
            {published.map((p) => <PredictionCard key={p.id} p={p} />)}
          </div>
        </section>

        <section className="space-y-6 lg:col-span-2">
          <div>
            <SectionTitle>Derniers résultats</SectionTitle>
            <Card className="divide-y divide-line !p-0">
              {results.map((m) => (
                <Link key={m.id} to={`/analyse/${m.id}`} className="flex items-center gap-3 px-4 py-3 transition hover:bg-white/[0.03]">
                  <TeamCrest team={d.team(m.homeId)} size={26} />
                  <span className="min-w-0 flex-1 truncate text-sm text-slate-200">{d.team(m.homeId).name}</span>
                  <span className="rounded-md bg-white/5 px-2 py-0.5 font-mono text-sm font-bold text-white">{m.homeGoals} – {m.awayGoals}</span>
                  <span className="min-w-0 flex-1 truncate text-right text-sm text-slate-200">{d.team(m.awayId).name}</span>
                  <TeamCrest team={d.team(m.awayId)} size={26} />
                </Link>
              ))}
            </Card>
          </div>
          <div>
            <SectionTitle>Rendement (unités)</SectionTitle>
            <Card><ProfitChart points={profitCurve(preds)} /></Card>
          </div>
          <Card gold>
            <div className="flex items-start gap-3">
              <Icon name="bot" className="mt-0.5 size-5 text-gold-400" />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 font-semibold text-white">AI Football Bot <Badge tone="amber">{LIVE ? 'Mode manuel' : 'Démo'}</Badge></div>
                <p className="mt-1 text-xs leading-relaxed text-slate-400">
                  {app.scans[0] ? `Dernier scan : ${fmtDateTime(app.scans[0].at)} à ${fmtTime(app.scans[0].at)}.` : 'Aucun scan lancé.'} {LIVE ? 'Aucune API sportive connectée : données saisies manuellement.' : 'Le scan automatique toutes les 15 minutes sera actif après l\'intégration du backend.'}
                </p>
                <Button variant="outline" size="sm" className="mt-3" onClick={() => navigate('/bot')}>Ouvrir le bot</Button>
              </div>
            </div>
          </Card>
        </section>
      </div>
    </div>
  );
}
