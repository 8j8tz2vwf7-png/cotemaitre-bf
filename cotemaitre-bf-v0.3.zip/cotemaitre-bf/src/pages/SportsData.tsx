import { useCallback, useEffect, useMemo, useState } from 'react';
import { Badge, Button, Card, Empty, Field, Icon, Modal, PageHeader, Select, Tabs, TextInput } from '../components/ui';
import { useApp } from '../store/AppStore';
import { useData } from '../store/DataContext';
import { navigate } from '../lib/router';
import { LIVE } from '../lib/mode';
import { supabaseClient } from '../services/auth';
import { createSportsRepo, type FixtureRow, type LeagueRow, type TeamRow, type TeamStats, type TeamStatsRow } from '../services/sportsRepo';
import { sportsSourceStatus } from '../services/sportsSource';
import { fmtDateTime } from '../lib/format';
import type { MatchStatus } from '../types';

type Tab = 'leagues' | 'teams' | 'fixtures' | 'stats';
const STATUS_LABEL: Record<MatchStatus, string> = { scheduled: 'Programmé', live: 'En cours', finished: 'Terminé', postponed: 'Reporté', cancelled: 'Annulé' };
const repo = supabaseClient ? createSportsRepo(supabaseClient) : null;
const toLocalInput = (iso: string) => { const d = new Date(iso); const p = (n: number) => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`; };
const num = (v: string): number | undefined => (v.trim() === '' ? undefined : Number(v.replace(',', '.')));
const manual = (s: string) => s === 'manual';

export function SportsData() {
  const app = useApp();
  const d = useData();
  const [tab, setTab] = useState<Tab>('fixtures');
  const [leagues, setLeagues] = useState<LeagueRow[]>([]);
  const [teams, setTeams] = useState<TeamRow[]>([]);
  const [fixtures, setFixtures] = useState<FixtureRow[]>([]);
  const [stats, setStats] = useState<TeamStatsRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState<null | { kind: Tab | 'score'; id?: number }>(null);
  const [f, setF] = useState<Record<string, string>>({});
  const set = (k: string) => (v: string) => setF((x) => ({ ...x, [k]: v }));

  const refresh = useCallback(async () => {
    if (!repo) return;
    const [l, t, x, s] = await Promise.all([repo.listLeagues(), repo.listTeams(), repo.listFixtures(), repo.listTeamStats()]);
    setLeagues(l); setTeams(t); setFixtures(x); setStats(s);
    await d.reload();
  }, [d.reload]);
  useEffect(() => { refresh().catch((e) => app.notify((e as Error).message, 'err')); }, [refresh]);

  const src = sportsSourceStatus(fixtures.map((x) => x.source));
  const lname = useMemo(() => new Map(leagues.map((l) => [l.id, l.name])), [leagues]);
  const tname = useMemo(() => new Map(teams.map((t) => [t.id, t.name])), [teams]);

  if (!LIVE) return <Empty icon="alert" title="Base non connectée" text="La saisie de données sportives n'est disponible que lorsque Supabase est configuré (voir README). En mode démonstration, les données sont fictives et non modifiables." />;
  if (!app.isAdmin) return <Empty icon="lock" title="Espace réservé" text="Connectez-vous en administrateur." action={<Button onClick={() => navigate('/connexion')}>Connexion</Button>} />;

  const act = async (fn: () => Promise<unknown>, ok: string) => {
    setBusy(true);
    try { await fn(); await refresh(); app.notify(ok); setForm(null); } catch (e) { app.notify((e as Error).message, 'err'); } finally { setBusy(false); }
  };
  const open = (kind: Tab | 'score', init: Record<string, string> = {}, id?: number) => { setF(init); setForm({ kind, id }); };
  const confirmDel = (what: string, fn: () => Promise<unknown>) => { if (window.confirm(`Supprimer ${what} ? Cette action est définitive.`)) void act(fn, 'Supprimé.'); };
  const badge = (s: string) => manual(s) ? <Badge tone="emerald">Manuel</Badge> : <Badge tone="blue">API (lecture seule)</Badge>;

  const submit = () => {
    if (!repo || !form) return;
    const id = form.id;
    if (form.kind === 'leagues') return act(() => (id ? repo.updateLeague(id, { name: f.name ?? '', country: f.country }) : repo.createLeague({ name: f.name ?? '', country: f.country })), 'Championnat enregistré.');
    if (form.kind === 'teams') return act(() => (id ? repo.updateTeam(id, { name: f.name ?? '', short: f.short, country: f.country }) : repo.createTeam({ name: f.name ?? '', short: f.short, country: f.country })), 'Équipe enregistrée.');
    if (form.kind === 'fixtures') {
      const v = { leagueId: Number(f.league), homeId: Number(f.home), awayId: Number(f.away), kickoff: new Date(f.kickoff).toISOString(), round: f.round, venue: f.venue };
      if (!v.leagueId || !v.homeId || !v.awayId || !f.kickoff) { app.notify('Championnat, deux équipes et date sont obligatoires.', 'err'); return; }
      return act(() => (id ? repo.updateFixture(id, v) : repo.createFixture(v)), 'Match enregistré.');
    }
    if (form.kind === 'score' && id) {
      const status = (f.status || 'scheduled') as MatchStatus;
      return act(() => repo.setScore(id, { status, home: num(f.hg ?? ''), away: num(f.ag ?? '') }), 'Score et statut enregistrés.');
    }
    if (form.kind === 'stats') {
      const side = (p: 'h' | 'a') => (f[p + 'p'] === undefined || f[p + 'p'] === '' ? undefined : { played: Number(f[p + 'p']), wins: Number(f[p + 'w'] || 0), draws: Number(f[p + 'd'] || 0), losses: Number(f[p + 'l'] || 0), gf: Number(f[p + 'gf'] || 0), ga: Number(f[p + 'ga'] || 0) });
      const s: TeamStats = {};
      if (f.form) s.form = f.form.toUpperCase();
      const h = side('h'), a = side('a');
      if (h) s.home = h; if (a) s.away = a;
      for (const [k, key] of [['shots', 'shots_per_game'], ['sot', 'shots_on_target_per_game'], ['poss', 'possession_pct'], ['cs', 'clean_sheet_pct'], ['fts', 'failed_to_score_pct']] as const) { const n = num(f[k] ?? ''); if (n !== undefined) s[key] = n; }
      if (f.abs?.trim()) s.absences = f.abs.split('\n').filter(Boolean).map((l) => { const [player, reason] = l.split(';').map((x) => x.trim()); return { player, reason: (reason || 'Incertain') as 'Blessure' | 'Suspension' | 'Incertain', verified: false }; });
      if (!f.team || !f.league || !f.season) { app.notify('Équipe, championnat et saison obligatoires.', 'err'); return; }
      return act(() => repo.saveTeamStats({ teamId: Number(f.team), leagueId: Number(f.league), season: Number(f.season), stats: s }), 'Statistiques enregistrées.');
    }
  };

  const leagueOpts = [{ value: '', label: '— choisir —' }, ...leagues.map((l) => ({ value: String(l.id), label: l.name }))];
  const teamOpts = [{ value: '', label: '— choisir —' }, ...teams.map((t) => ({ value: String(t.id), label: t.name }))];
  const rowCls = 'flex flex-wrap items-center gap-x-4 gap-y-1 px-4 py-3 text-sm';
  const acts = (src: string, edit: () => void, del: () => void) => manual(src) ? (
    <span className="ml-auto flex gap-1"><Button size="sm" variant="ghost" onClick={edit}>Modifier</Button><Button size="sm" variant="ghost" onClick={del}>Supprimer</Button></span>
  ) : null;

  return (
    <div>
      <PageHeader title="Données sportives" subtitle="Saisie et correction des championnats, équipes, matchs, scores et statistiques. Tout est enregistré dans la base ; seul un administrateur peut écrire." />
      <Card className="mb-5"><div className="flex flex-wrap items-center gap-3 text-sm"><Badge tone={src.apiConnected ? 'emerald' : 'amber'}>{src.label}</Badge><span className="text-slate-400">{src.detail}</span></div></Card>
      <Tabs<Tab> value={tab} onChange={setTab} items={[{ id: 'fixtures', label: 'Matchs', count: fixtures.length }, { id: 'leagues', label: 'Championnats', count: leagues.length }, { id: 'teams', label: 'Équipes', count: teams.length }, { id: 'stats', label: 'Statistiques', count: stats.length }]} />

      {tab === 'leagues' && (<section><div className="mb-3 flex justify-end"><Button onClick={() => open('leagues')}><Icon name="plus" className="size-4" /> Nouveau championnat</Button></div>
        <Card className="divide-y divide-line !p-0">{leagues.length === 0 && <div className="p-4 text-sm text-slate-500">Aucun championnat. Commencez par en créer un.</div>}
          {leagues.map((l) => <div key={l.id} className={rowCls}><span className="font-semibold text-white">{l.name}</span><span className="text-slate-400">{l.country ?? ''}</span>{badge(l.source)}{acts(l.source, () => open('leagues', { name: l.name, country: l.country ?? '' }, l.id), () => confirmDel(`le championnat « ${l.name} »`, () => repo!.deleteLeague(l.id)))}</div>)}</Card></section>)}

      {tab === 'teams' && (<section><div className="mb-3 flex justify-end"><Button onClick={() => open('teams')}><Icon name="plus" className="size-4" /> Nouvelle équipe</Button></div>
        <Card className="divide-y divide-line !p-0">{teams.length === 0 && <div className="p-4 text-sm text-slate-500">Aucune équipe.</div>}
          {teams.map((t) => <div key={t.id} className={rowCls}><span className="font-semibold text-white">{t.name}</span><span className="text-slate-400">{t.short_name ?? ''} {t.country ? `· ${t.country}` : ''}</span>{badge(t.source)}{acts(t.source, () => open('teams', { name: t.name, short: t.short_name ?? '', country: t.country ?? '' }, t.id), () => confirmDel(`l'équipe « ${t.name} »`, () => repo!.deleteTeam(t.id)))}</div>)}</Card></section>)}

      {tab === 'fixtures' && (<section><div className="mb-3 flex justify-end"><Button onClick={() => open('fixtures', { kickoff: toLocalInput(new Date(Date.now() + 86400000).toISOString()) })}><Icon name="plus" className="size-4" /> Programmer un match</Button></div>
        <Card className="divide-y divide-line !p-0">{fixtures.length === 0 && <div className="p-4 text-sm text-slate-500">Aucun match. Créez d'abord un championnat et deux équipes.</div>}
          {fixtures.map((x) => <div key={x.id} className={rowCls}>
            <span className="w-36 text-xs text-slate-500">{fmtDateTime(x.kickoff)}</span>
            <span className="min-w-0 flex-1 text-slate-200">{x.home_team} {x.status === 'finished' || x.status === 'live' ? <b className="mx-1 font-mono text-white">{x.home_goals}–{x.away_goals}</b> : '–'} {x.away_team}<span className="ml-2 text-xs text-slate-500">{x.league_name}</span></span>
            <Badge tone={x.status === 'finished' ? 'slate' : x.status === 'scheduled' ? 'emerald' : 'amber'}>{STATUS_LABEL[x.status]}</Badge>{badge(x.source)}
            {manual(x.source) && <span className="ml-auto flex gap-1"><Button size="sm" variant="gold" onClick={() => open('score', { status: x.status, hg: x.home_goals?.toString() ?? '', ag: x.away_goals?.toString() ?? '' }, x.id)}>Score / statut</Button>
              <Button size="sm" variant="ghost" onClick={() => open('fixtures', { league: String(x.league_id), home: String(x.home_team_id ?? ''), away: String(x.away_team_id ?? ''), kickoff: toLocalInput(x.kickoff), round: x.round ?? '', venue: x.venue ?? '' }, x.id)}>Corriger</Button>
              <Button size="sm" variant="ghost" onClick={() => confirmDel(`le match ${x.home_team} – ${x.away_team}`, () => repo!.deleteFixture(x.id))}>Supprimer</Button></span>}
          </div>)}</Card></section>)}

      {tab === 'stats' && (<section><div className="mb-3 flex justify-end"><Button onClick={() => open('stats', { season: String(new Date().getFullYear()) })}><Icon name="plus" className="size-4" /> Ajouter des statistiques</Button></div>
        <Card className="divide-y divide-line !p-0">{stats.length === 0 && <div className="p-4 text-sm text-slate-500">Aucune statistique. Un champ laissé vide reste « non renseigné » : rien n'est inventé.</div>}
          {stats.map((s) => <div key={`${s.team_id}-${s.league_id}-${s.season}`} className={rowCls}><span className="font-semibold text-white">{tname.get(s.team_id) ?? s.team_id}</span><span className="text-slate-400">{lname.get(s.league_id) ?? s.league_id} · {s.season}</span>{s.stats.form && <span className="font-mono text-emerald-300">{s.stats.form}</span>}
            <span className="ml-auto"><Button size="sm" variant="ghost" onClick={() => confirmDel('ces statistiques', () => repo!.deleteTeamStats(s.team_id, s.league_id, s.season))}>Supprimer</Button></span></div>)}</Card></section>)}

      <Modal open={!!form} onClose={() => setForm(null)} title={form?.kind === 'score' ? 'Score et statut' : form?.id ? 'Modifier' : 'Ajouter'} wide={form?.kind === 'stats'}>
        <div className="space-y-4">
          {(form?.kind === 'leagues' || form?.kind === 'teams') && (<>
            <Field label="Nom"><TextInput value={f.name ?? ''} onChange={set('name')} autoFocus /></Field>
            {form.kind === 'teams' && <Field label="Nom court (3 lettres)"><TextInput value={f.short ?? ''} onChange={set('short')} /></Field>}
            <Field label="Pays"><TextInput value={f.country ?? ''} onChange={set('country')} /></Field></>)}
          {form?.kind === 'fixtures' && (<>
            <Field label="Championnat"><Select value={f.league ?? ''} onChange={set('league')} options={leagueOpts} /></Field>
            <Field label="Domicile"><Select value={f.home ?? ''} onChange={set('home')} options={teamOpts} /></Field>
            <Field label="Extérieur"><Select value={f.away ?? ''} onChange={set('away')} options={teamOpts} /></Field>
            <Field label="Coup d'envoi" hint="Un pronostic ne peut être enregistré et publié qu'AVANT cette heure."><TextInput type="datetime-local" value={f.kickoff ?? ''} onChange={set('kickoff')} /></Field>
            <Field label="Journée (optionnel)"><TextInput value={f.round ?? ''} onChange={set('round')} /></Field>
            <Field label="Stade (optionnel)"><TextInput value={f.venue ?? ''} onChange={set('venue')} /></Field></>)}
          {form?.kind === 'score' && (<>
            <Field label="Statut" hint="« Terminé » exige les deux scores. Source officielle à vérifier avant saisie."><Select value={f.status ?? 'scheduled'} onChange={set('status')} options={(Object.keys(STATUS_LABEL) as MatchStatus[]).map((k) => ({ value: k, label: STATUS_LABEL[k] }))} /></Field>
            <div className="grid grid-cols-2 gap-3"><Field label="Buts domicile"><TextInput type="number" min="0" value={f.hg ?? ''} onChange={set('hg')} /></Field><Field label="Buts extérieur"><TextInput type="number" min="0" value={f.ag ?? ''} onChange={set('ag')} /></Field></div></>)}
          {form?.kind === 'stats' && (<>
            <div className="grid grid-cols-3 gap-3"><Field label="Équipe"><Select value={f.team ?? ''} onChange={set('team')} options={teamOpts} /></Field><Field label="Championnat"><Select value={f.league ?? ''} onChange={set('league')} options={leagueOpts} /></Field><Field label="Saison"><TextInput type="number" value={f.season ?? ''} onChange={set('season')} /></Field></div>
            <Field label="Forme (W=victoire D=nul L=défaite, ex. WWDLW)"><TextInput value={f.form ?? ''} onChange={set('form')} /></Field>
            {(['h', 'a'] as const).map((p) => <div key={p}><div className="mb-1 text-xs text-slate-400">{p === 'h' ? 'Domicile' : 'Extérieur'} (laisser « joués » vide = non renseigné)</div>
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">{([['p', 'Joués'], ['w', 'V'], ['d', 'N'], ['l', 'D'], ['gf', 'BM'], ['ga', 'BE']] as const).map(([k, lab]) => <Field key={k} label={lab}><TextInput type="number" min="0" value={f[p + k] ?? ''} onChange={set(p + k)} /></Field>)}</div></div>)}
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">{([['shots', 'Tirs/match'], ['sot', 'Cadrés/match'], ['poss', 'Possession %'], ['cs', 'Sans encaisser %'], ['fts', 'Sans marquer %']] as const).map(([k, lab]) => <Field key={k} label={lab}><TextInput type="number" step="0.1" min="0" value={f[k] ?? ''} onChange={set(k)} /></Field>)}</div>
            <Field label="Absences (une par ligne : Joueur;Blessure|Suspension|Incertain)"><textarea className="w-full rounded-xl border border-line bg-ink-900 p-2 text-sm text-white" rows={3} value={f.abs ?? ''} onChange={(e: { target: { value: string } }) => set('abs')(e.target.value)} /></Field></>)}
          <div className="flex justify-end gap-2"><Button variant="ghost" onClick={() => setForm(null)}>Annuler</Button><Button disabled={busy} onClick={() => void submit()}>{busy ? 'Enregistrement…' : 'Enregistrer'}</Button></div>
        </div>
      </Modal>
    </div>
  );
}
