import { useState } from 'react';
import { Badge, Button, Card, DemoBanner, Empty, Icon, PageHeader, SectionTitle, Tabs, ResultBadge } from '../components/ui';
import { PredictionCard } from '../components/PredictionCard';
import { useApp } from '../store/AppStore';
import { isSettled } from '../lib/stats';
import { fmtShort, num } from '../lib/format';
import { LIVE } from '../lib/mode';

type Tab = 'free' | 'vip';

export function Predictions() {
  const app = useApp();
  const [tab, setTab] = useState<Tab>('free');
  const pub = app.predictions.filter((p) => p.published && p.review === 'validated');
  const byDate = (a: { kickoff: string }, b: { kickoff: string }) => b.kickoff.localeCompare(a.kickoff);
  const free = pub.filter((p) => p.tier === 'free').sort(byDate);
  const vip = pub.filter((p) => p.tier === 'vip').sort(byDate);
  const open = (l: typeof free) => l.filter((p) => p.result === 'pending');
  const done = (l: typeof free) => l.filter(isSettled);

  return (
    <div>
      <PageHeader title="Pronostics" subtitle="Chaque pronostic affiché a été relu et publié par un humain. Aucun n'est publié automatiquement." />
      <Tabs<Tab> value={tab} onChange={setTab} items={[
        { id: 'free', label: 'Pronostics gratuits', count: free.length },
        { id: 'vip', label: 'Pronostics VIP', count: LIVE && !app.hasVip ? undefined : vip.length, gold: true },
      ]} />
      <div className="mb-5"><DemoBanner compact /></div>

      {tab === 'free' && (
        <div className="space-y-6">
          <section>
            <SectionTitle>À venir</SectionTitle>
            {open(free).length === 0 ? <Empty icon="target" title="Aucun pronostic gratuit en cours" text="Revenez plus tard : les publications dépendent de la validation de l'administrateur." /> : <div className="grid gap-3 lg:grid-cols-2">{open(free).map((p) => <PredictionCard key={p.id} p={p} />)}</div>}
          </section>
          <section>
            <SectionTitle>Résultats récents</SectionTitle>
            <div className="grid gap-3 lg:grid-cols-2">{done(free).slice(0, 6).map((p) => <PredictionCard key={p.id} p={p} />)}</div>
          </section>
        </div>
      )}

      {tab === 'vip' && !app.hasVip && (
        <div className="space-y-6">
          <Card gold className="text-center">
            <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-gold-500/10 ring-1 ring-gold-500/40"><Icon name="crown" className="size-7 text-gold-400" /></div>
            <h2 className="mt-4 font-display text-2xl font-bold"><span className="gold-text">Espace VIP</span></h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-slate-400">Analyses approfondies, sélections Premium, justifications statistiques détaillées et historique complet des résultats.</p>
            <div className="mx-auto mt-5 grid max-w-sm gap-2 text-left text-sm text-slate-300">
              {['Analyses statistiques approfondies', 'Cote équitable et avantage estimé', 'Historique VIP complet', 'Sélections Premium relues par un humain'].map((t) => <div key={t} className="flex items-center gap-2"><Icon name="check" className="size-4 text-gold-400" />{t}</div>)}
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {LIVE
                ? <Badge tone="gold">Abonnements VIP : bientôt disponibles</Badge>
                : <Button variant="gold" size="lg" onClick={app.toggleVip}><Icon name="crown" className="size-4" /> Activer l'aperçu VIP (démo)</Button>}
            </div>
            <p className="mt-4 text-xs text-slate-500">{LIVE ? 'Les sélections VIP ne sont lisibles que par les abonnés (contrôle appliqué par la base de données). Aucun paiement n\'est actif.' : 'Aperçu gratuit pour tester l\'interface. Les abonnements réels (paiement, comptes utilisateurs) seront branchés lors d\'une prochaine étape.'}</p>
          </Card>
          {!LIVE && <section>
            <SectionTitle right={<Badge tone="gold">{vip.length} sélection(s) VIP</Badge>}>Aperçu verrouillé</SectionTitle>
            <div className="grid gap-3 lg:grid-cols-2">
              {vip.slice(0, 2).map((p) => (
                <Card key={p.id} gold className="relative overflow-hidden">
                  <div className="select-none blur-[5px]" aria-hidden="true"><div className="font-display font-bold text-white">{p.home} vs {p.away}</div><div className="mt-2 text-gold-300">{p.pick}</div><div className="mt-2 text-sm text-slate-400">Justification statistique approfondie…</div></div>
                  <div className="absolute inset-0 grid place-items-center bg-ink-950/50"><Icon name="lock" className="size-8 text-gold-400" /></div>
                </Card>
              ))}
            </div>
          </section>}
        </div>
      )}

      {tab === 'vip' && app.hasVip && (
        <div className="space-y-6">
          {app.vipPreview && !app.isAdmin && (
            <div className="flex items-center justify-between gap-3 rounded-xl border border-gold-500/30 bg-gold-500/[0.07] px-4 py-3 text-sm text-gold-200">
              <span>Aperçu VIP (démo) actif — aucun paiement réel.</span>
              <Button size="sm" variant="ghost" onClick={app.toggleVip}>Désactiver</Button>
            </div>
          )}
          <section>
            <SectionTitle>Sélections Premium en cours</SectionTitle>
            {open(vip).length === 0 ? <Empty icon="crown" title="Aucune sélection VIP en cours" /> : <div className="grid gap-3 lg:grid-cols-2">{open(vip).map((p) => <PredictionCard key={p.id} p={p} deep />)}</div>}
          </section>
          <section>
            <SectionTitle>Historique des résultats VIP</SectionTitle>
            <Card className="divide-y divide-line !p-0">
              {done(vip).length === 0 && <div className="p-4 text-sm text-slate-500">Aucun résultat VIP.</div>}
              {done(vip).map((p) => (
                <div key={p.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-4 py-3 text-sm">
                  <span className="w-14 text-xs text-slate-500">{fmtShort(p.kickoff)}</span>
                  <span className="min-w-0 flex-1 truncate text-slate-200">{p.home} – {p.away}</span>
                  <span className="text-gold-300">{p.pick}</span>
                  <span className="font-mono text-slate-400">{p.odds ? num(p.odds) : '—'}</span>
                  <ResultBadge r={p.result} />
                </div>
              ))}
            </Card>
          </section>
        </div>
      )}
    </div>
  );
}
