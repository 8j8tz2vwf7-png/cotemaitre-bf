import { useEffect, useState } from 'react';
import { LIVE } from '../lib/mode';
import { Badge, Button, Card, DemoBanner, Empty, Field, Icon, Modal, PageHeader, ProbBar, ResultBadge, SectionTitle, Select, StatCard, Tabs, TextArea, TextInput } from '../components/ui';
import { Link, navigate } from '../lib/router';
import { useAnalysis, useData } from '../store/DataContext';
import { useApp } from '../store/AppStore';
import { computePerf } from '../lib/stats';
import { authInfo, supabaseClient } from '../services/auth';
import { fmtDateTime, num, pct, uid } from '../lib/format';
import { MARKET_LABEL, PICKS, type Market, type Prediction } from '../types';

type Tab = 'queue' | 'published' | 'analyzed' | 'bot' | 'tech';
type QFilter = 'proposed' | 'validated' | 'refused' | 'all';

function EditModal({ p, focus, onClose }: { p: Prediction | null; focus: 'justification' | null; onClose: () => void }) {
  const app = useApp();
  const [market, setMarket] = useState<Market>('1X2');
  const [pick, setPick] = useState('');
  const [odds, setOdds] = useState('');
  const [stake, setStake] = useState('');
  const [just, setJust] = useState('');
  const [tier, setTier] = useState<'free' | 'vip'>('free');

  useEffect(() => {
    if (!p) return;
    setMarket(p.market); setPick(p.pick); setOdds(p.odds ? String(p.odds).replace('.', ',') : '');
    setStake(p.stake ? String(p.stake) : ''); setJust(p.justification); setTier(p.tier);
  }, [p?.id]);

  if (!p) return null;
  const save = () => {
    const o = odds.trim() ? Number(odds.replace(',', '.')) : undefined;
    const s = stake.trim() ? Number(stake.replace(',', '.')) : undefined;
    if ((o !== undefined && (!isFinite(o) || o < 1.01)) || (s !== undefined && (!isFinite(s) || s <= 0))) {
      app.notify('Cote (≥ 1,01) ou mise invalide.', 'err');
      return;
    }
    app.edit(p.id, { market, pick, odds: o, stake: s, justification: just.trim(), tier });
    onClose();
  };
  return (
    <Modal open onClose={onClose} title={`Modifier — ${p.home} vs ${p.away}`} wide>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Marché"><Select value={market} onChange={(v) => { setMarket(v as Market); setPick(PICKS[v as Market][0]); }} options={(Object.keys(PICKS) as Market[]).map((k) => ({ value: k, label: MARKET_LABEL[k] }))} /></Field>
        <Field label="Sélection"><Select value={pick} onChange={setPick} options={PICKS[market].map((x) => ({ value: x, label: x }))} /></Field>
        <Field label="Cote" hint="Nécessaire pour le calcul du ROI."><TextInput value={odds} onChange={setOdds} placeholder="ex. 1,85" /></Field>
        <Field label="Mise (unités)"><TextInput value={stake} onChange={setStake} placeholder="ex. 2" /></Field>
        <div className="sm:col-span-2"><Field label="Catégorie"><Select value={tier} onChange={(v) => setTier(v as 'free' | 'vip')} options={[{ value: 'free', label: 'Gratuit' }, { value: 'vip', label: 'VIP (Premium)' }]} /></Field></div>
        <div className="sm:col-span-2"><Field label="Justification" hint="Obligatoire pour valider."><TextArea value={just} onChange={setJust} rows={5} autoFocus={focus === 'justification'} placeholder="Analyse et arguments statistiques…" /></Field></div>
      </div>
      {p.published && <p className="mt-3 rounded-lg bg-amber-500/10 p-2.5 text-xs text-amber-200">Ce pronostic est publié : l'enregistrer le dépubliera et il devra être revalidé.</p>}
      <div className="mt-5 flex justify-end gap-2"><Button variant="ghost" onClick={onClose}>Annuler</Button><Button onClick={save}>Enregistrer</Button></div>
    </Modal>
  );
}

function ProbMini({ p }: { p: Prediction }) {
  const { data: a } = useAnalysis(p.matchId);
  if (!a) return null;
  const pr = a.probabilities;
  return (
    <div className="mt-3 grid gap-2 rounded-xl bg-black/25 p-3 sm:grid-cols-3">
      <ProbBar label="Domicile" value={pr.home} /><ProbBar label="Nul" value={pr.draw} tone="slate" /><ProbBar label="Extérieur" value={pr.away} />
      <ProbBar label="Plus de 2,5 buts" value={pr.over['2.5']} tone="gold" /><ProbBar label="BTTS Oui" value={pr.btts} tone="gold" /><ProbBar label="Double chance 1X" value={pr.dc1X} />
    </div>
  );
}

function ReviewBadge({ p }: { p: Prediction }) {
  if (p.published) return <Badge tone="emerald"><Icon name="eye" className="size-3" /> Publié</Badge>;
  if (p.review === 'validated') return <Badge tone="blue">Validé · non publié</Badge>;
  if (p.review === 'refused') return <Badge tone="red">Refusé</Badge>;
  return <Badge tone="amber">En attente</Badge>;
}

export function Admin() {
  const app = useApp();
  const d = useData();
  const [tab, setTab] = useState<Tab>('queue');
  const [qf, setQf] = useState<QFilter>('proposed');
  const [editing, setEditing] = useState<{ p: Prediction; focus: 'justification' | null } | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [openManual, setOpenManual] = useState(false);
  const [mMatch, setMMatch] = useState('');
  const [mMarket, setMMarket] = useState<Market>('1X2');
  const [mPick, setMPick] = useState(PICKS['1X2'][0]);
  const [ping, setPing] = useState<{ ok: boolean; text: string } | null>(null);
  const [pinging, setPinging] = useState(false);
  const db = supabaseClient;   // constante locale : le rétrécissement de type survit dans les fonctions asynchrones

  if (!app.authReady) return <div className="py-24 text-center text-slate-500">Vérification de la session…</div>;

  if (!app.isAdmin) {
    return (
      <div className="mx-auto mt-10 max-w-md">
        <Empty icon="lock" title="Espace réservé" text="Connectez-vous avec un compte administrateur pour examiner, valider et publier les pronostics."
          action={<Button onClick={() => navigate('/connexion')}>Se connecter</Button>} />
      </div>
    );
  }

  const preds = app.predictions;
  const real = preds.filter((p) => p.source !== 'demo-seed' || p.id.startsWith('seed_'));
  const queue = preds.filter((p) => !p.id.startsWith('hist_')).filter((p) => qf === 'all' || p.review === qf);
  const publishedList = preds.filter((p) => p.review === 'validated' && !p.id.startsWith('hist_'));
  const botPreds = preds.filter((p) => p.source === 'demo-scan' || p.id.startsWith('seed_'));
  const analyzedMatches = d.matches.filter((m) => app.analyzedIds.includes(m.id));
  const scheduled = d.matches.filter((m) => m.status === 'scheduled');
  const counts = { proposed: preds.filter((p) => p.review === 'proposed').length, validated: preds.filter((p) => p.review === 'validated' && !p.id.startsWith('hist_')).length, refused: preds.filter((p) => p.review === 'refused').length };

  const manualCreate = () => {
    const m = d.match(mMatch);
    if (!m) { app.notify('Choisissez un match.', 'err'); return; }
    const now = new Date().toISOString();
    app.addManual({ id: uid('man'), matchId: m.id, home: d.team(m.homeId).name, away: d.team(m.awayId).name, league: d.league(m.leagueId).name, kickoff: m.kickoff, market: mMarket, pick: mPick, justification: '', tier: 'free', review: 'proposed', published: false, result: 'pending', source: 'admin', createdAt: now, updatedAt: now, demo: true });
    setOpenManual(false);
    setQf('proposed'); setTab('queue');
  };

  const card = (p: Prediction) => {
    const m = p.matchId ? d.match(p.matchId) : undefined;
    return (
      <article key={p.id} className="animate-fade-up rounded-2xl border border-line bg-ink-900/70 p-4 sm:p-5">
        <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
          <ReviewBadge p={p} />
          <Badge tone={p.tier === 'vip' ? 'gold' : 'emerald'}>{p.tier === 'vip' ? 'VIP' : 'Gratuit'}</Badge>
          <Badge tone="slate">{p.source === 'demo-scan' ? 'Bot (démo)' : p.source === 'admin' ? 'Manuel' : 'Exemple démo'}</Badge>
          <span>{p.league}</span><span>·</span><span>{fmtDateTime(p.kickoff)}</span>
          <span className="ml-auto"><ResultBadge r={p.result} /></span>
        </div>
        <h3 className="mt-2 font-display font-bold text-white">{p.home} <span className="text-slate-500">vs</span> {p.away}</h3>
        <div className="mt-2 flex flex-wrap items-center gap-x-5 gap-y-1 text-sm">
          <span className="text-slate-500">{MARKET_LABEL[p.market]} :</span>
          <span className="font-semibold text-emerald-300">{p.pick}</span>
          <span className="font-mono text-slate-300">Cote {p.odds ? num(p.odds) : '—'}</span>
          {p.probability !== undefined && <span className="font-mono text-slate-300">Proba. {pct(p.probability, 0)}</span>}
          {p.stake && <span className="font-mono text-slate-300">Mise {p.stake} u</span>}
        </div>
        <p className={`mt-2 text-sm leading-relaxed ${p.justification ? 'text-slate-400' : 'italic text-amber-300/80'}`}>{p.justification || 'Aucune justification — à ajouter avant validation.'}</p>
        {tab === 'queue' && p.review === 'proposed' && p.matchId && <ProbMini p={p} />}

        <div className="mt-4 flex flex-wrap items-center gap-2">
          {p.review === 'proposed' && (<>
            <Button size="sm" onClick={() => app.validate(p.id)}><Icon name="check" className="size-4" /> Valider</Button>
            <Button size="sm" variant="danger" onClick={() => app.refuse(p.id)}><Icon name="x" className="size-4" /> Refuser</Button>
          </>)}
          {p.review === 'validated' && !p.published && <Button size="sm" variant="gold" onClick={() => app.publish(p.id)}><Icon name="eye" className="size-4" /> Publier</Button>}
          {p.published && <Button size="sm" variant="outline" onClick={() => app.unpublish(p.id)}><Icon name="eyeoff" className="size-4" /> Dépublier</Button>}
          {p.review === 'refused' && <Button size="sm" variant="outline" onClick={() => app.reopen(p.id)}>Remettre en attente</Button>}
          <Button size="sm" variant="ghost" onClick={() => setEditing({ p, focus: null })}><Icon name="edit" className="size-4" /> Modifier</Button>
          <Button size="sm" variant="ghost" onClick={() => setEditing({ p, focus: 'justification' })}>Justifier</Button>
          <div className="ml-auto w-32"><Select value={p.tier} onChange={(v) => app.setTier(p.id, v as 'free' | 'vip')} options={[{ value: 'free', label: 'Gratuit' }, { value: 'vip', label: 'VIP' }]} /></div>
        </div>

        {tab === 'published' && p.published && (
          <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-line pt-3 text-xs">
            <span className="text-slate-500">Résultat :</span>
            <Button size="sm" variant="outline" onClick={() => app.setResult(p.id, 'won')}>Gagné</Button>
            <Button size="sm" variant="danger" onClick={() => app.setResult(p.id, 'lost')}>Perdu</Button>
            <Button size="sm" variant="ghost" onClick={() => app.setResult(p.id, 'void')}>Annulé</Button>
            <Button size="sm" variant="ghost" onClick={() => app.setResult(p.id, 'pending')}>En attente</Button>
            {m?.status === 'finished' && <Button size="sm" variant="gold" onClick={() => app.settleFromScore(p.id)}>Régler d'après le score ({m.homeGoals}–{m.awayGoals})</Button>}
          </div>
        )}
      </article>
    );
  };

  const botPerf = computePerf(botPreds);
  return (
    <div>
      <PageHeader title="Espace administrateur" subtitle="Examinez les propositions du bot, validez, modifiez et publiez. Rien n'est publié sans votre action."
        right={<Button variant="gold" onClick={() => { setMMatch(scheduled[0]?.id ?? ''); setOpenManual(true); }}><Icon name="plus" className="size-4" /> Proposition manuelle</Button>} />

      {app.authKind === 'supabase' && (
        <div className="mb-5 flex items-start gap-3 rounded-xl border border-emerald-500/30 bg-emerald-500/[0.06] px-4 py-3 text-xs leading-relaxed text-emerald-100">
          <Icon name="shield" className="mt-0.5 size-4 shrink-0 text-emerald-400" />
          <p><strong>Authentification Supabase active</strong> ({authInfo.host}). Vous êtes connecté avec un vrai compte administrateur. Les pronostics et matchs ci-dessous restent des <strong>données de démonstration locales</strong> : la synchronisation avec la base est prévue à l'étape suivante.</p>
        </div>
      )}

      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="En attente" value={counts.proposed} icon="clock" hint="À valider ou refuser" />
        <StatCard label="Validés" value={counts.validated} icon="check" />
        <StatCard label="Publiés" value={preds.filter((p) => p.published && !p.id.startsWith('hist_')).length} icon="eye" tone="gold" />
        <StatCard label="Refusés" value={counts.refused} icon="x" />
      </div>

      <Tabs<Tab> value={tab} onChange={setTab} items={[
        { id: 'queue', label: 'Propositions', count: counts.proposed },
        { id: 'published', label: 'Publications & résultats' },
        { id: 'analyzed', label: 'Matchs analysés', count: analyzedMatches.length },
        { id: 'bot', label: 'Performances du bot' },
        { id: 'tech', label: 'Intégrations' },
      ]} />

      {tab === 'queue' && (
        <div>
          <div className="mb-4 flex flex-wrap gap-1.5">
            {([['proposed', 'En attente'], ['validated', 'Validés'], ['refused', 'Refusés'], ['all', 'Tous']] as const).map(([id, label]) => (
              <button key={id} onClick={() => setQf(id)} className={`cursor-pointer rounded-full px-3 py-1.5 text-xs font-semibold ring-1 ring-inset ${qf === id ? 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/40' : 'text-slate-400 ring-line hover:bg-white/5'}`}>{label}</button>
            ))}
          </div>
          {queue.length === 0 ? <Empty icon="bot" title="Rien à examiner" text={LIVE ? 'Créez une proposition depuis la page d\'un match (Matchs → Analyse → Proposer un pronostic).' : 'Lancez un scan démo depuis la page AI Football Bot pour générer des propositions.'} action={<Button variant="outline" onClick={() => navigate('/bot')}>Ouvrir le bot</Button>} /> : <div className="space-y-3">{queue.map(card)}</div>}
        </div>
      )}

      {tab === 'published' && (
        <div className="space-y-3">
          {publishedList.length === 0 ? <Empty icon="eye" title="Aucun pronostic validé" /> : publishedList.map(card)}
        </div>
      )}

      {tab === 'analyzed' && (
        <Card className="overflow-x-auto !p-0">
          <table className="w-full min-w-[520px] text-sm">
            <thead><tr className="border-b border-line text-left text-xs text-slate-500"><th className="px-4 py-2.5 font-medium">Match</th><th className="py-2.5 font-medium">Date</th><th className="py-2.5 font-medium">Pronostics</th><th className="px-4 py-2.5 text-right font-medium">Fiche</th></tr></thead>
            <tbody>
              {analyzedMatches.map((m) => (
                <tr key={m.id} className="border-b border-line/60">
                  <td className="px-4 py-3 text-slate-200">{d.team(m.homeId).name} – {d.team(m.awayId).name}</td>
                  <td className="py-3 text-slate-400">{fmtDateTime(m.kickoff)}</td>
                  <td className="py-3 font-mono text-slate-300">{preds.filter((p) => p.matchId === m.id).length}</td>
                  <td className="px-4 py-3 text-right"><Link to={`/analyse/${m.id}`} className="font-semibold text-emerald-400 hover:underline">Ouvrir →</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {tab === 'bot' && (
        <div className="space-y-4">
          <DemoBanner compact />
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <StatCard label="Propositions du bot" value={botPreds.length} icon="bot" hint="Scans + exemples démo" />
            <StatCard label="Taux de validation" value={botPreds.length ? pct(botPreds.filter((p) => p.review === 'validated').length / botPreds.length, 0) : '—'} icon="check" />
            <StatCard label="Taux de refus" value={botPreds.length ? pct(botPreds.filter((p) => p.review === 'refused').length / botPreds.length, 0) : '—'} icon="x" />
            <StatCard label="Réussite (soldés)" value={botPerf.winRate === null ? '—' : pct(botPerf.winRate, 0)} icon="trophy" tone="gold" hint={`${botPerf.settled} soldé(s)`} />
          </div>
          <Card>
            <SectionTitle>Scans récents</SectionTitle>
            {app.scans.length === 0 ? <p className="text-sm text-slate-500">Aucun scan lancé.</p> : app.scans.slice(0, 5).map((s) => (
              <div key={s.id} className="flex flex-wrap items-center gap-3 border-t border-line py-2 text-sm first:border-0"><span className="text-slate-200">{fmtDateTime(s.at)}</span><Badge tone="amber">{s.mode}</Badge><span className="text-slate-400">{s.analyzed} analysés · {s.proposals} propositions · {s.discarded} écartés</span></div>
            ))}
          </Card>
          <p className="text-xs text-slate-500">Les performances réelles du bot ne seront mesurables qu'après connexion aux données réelles et publication de résultats vérifiés.</p>
        </div>
      )}

      {tab === 'tech' && (
        <div className="space-y-4">
          <Card>
            <SectionTitle>Supabase</SectionTitle>
            <div className="space-y-2 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-slate-400">Configuration :</span>
                {authInfo.envState === 'configured' && <Badge tone="emerald">Configurée ({authInfo.host})</Badge>}
                {authInfo.envState === 'unconfigured' && <Badge tone="slate">Non configurée (mode démonstration)</Badge>}
                {authInfo.envState === 'invalid' && <Badge tone="red">Refusée</Badge>}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-slate-400">Authentification :</span>
                <Badge tone={authInfo.kind === 'supabase' ? 'emerald' : 'amber'}>{authInfo.kind === 'supabase' ? 'Supabase Auth (réelle)' : 'Simulée (démo)'}</Badge>
              </div>
              {authInfo.reason && <p className="text-xs text-slate-500">{authInfo.reason}</p>}
              {db ? (
                <div className="pt-1">
                  <Button size="sm" variant="outline" disabled={pinging} onClick={async () => {
                    setPinging(true);
                    const r = await db.ping();
                    setPing(r.ok ? { ok: true, text: 'Base joignable et schéma installé.' } : { ok: false, text: r.message });
                    setPinging(false);
                  }}><Icon name="refresh" className={`size-4 ${pinging ? 'animate-spin-slow' : ''}`} /> Tester la connexion</Button>
                  {ping && <p className={`mt-2 text-xs ${ping.ok ? 'text-emerald-300' : 'text-red-300'}`}>{ping.text}</p>}
                </div>
              ) : <p className="text-xs text-slate-500">Voir le README (section « Connecter Supabase ») pour activer la connexion.</p>}
            </div>
          </Card>
          <Card>
            <SectionTitle>Checklist d'intégration</SectionTitle>
            <ul className="space-y-2.5 text-sm">
              {[
                ['Backend sécurisé (Edge Functions / API)', 'Proxy API-Football, clés côté serveur uniquement. Voir backend/.'],
                ['Supabase : migrations SQL', 'Prêtes dans supabase/migrations (testées sur PostgreSQL) ; à exécuter sur VOTRE projet.'],
                ['Supabase Auth + premier administrateur', 'Code prêt (src/services/auth.ts) ; créer le compte admin (README).'],
                ['Synchroniser pronostics et matchs avec la base', LIVE ? 'Fait : pronostics et données sportives sont lus et écrits dans la base.' : 'Disponible dès que Supabase est configuré.'],
                ['Scanner automatique (15 min)', 'Cron + fonction scan-matches (squelette fourni).'],
                ['Moteur statistique réel', 'Remplace src/services/engine.ts par un service serveur.'],
                ['Abonnements VIP', 'Paiement + table subscriptions + contrôle d\'accès serveur.'],
              ].map(([t, s]) => <li key={t} className="flex gap-3"><Badge tone="red" className="h-fit">À faire</Badge><div><div className="font-semibold text-slate-200">{t}</div><div className="text-xs text-slate-500">{s}</div></div></li>)}
            </ul>
          </Card>
          {!LIVE && <Card>
            <SectionTitle>Données de démonstration</SectionTitle>
            <p className="text-sm text-slate-400">Remet à zéro les pronostics, scans et statuts de validation (stockés dans ce navigateur).</p>
            <Button variant="danger" className="mt-3" onClick={() => setConfirmReset(true)}><Icon name="refresh" className="size-4" /> Réinitialiser la démo</Button>
          </Card>}
        </div>
      )}

      <EditModal p={editing?.p ?? null} focus={editing?.focus ?? null} onClose={() => setEditing(null)} />

      <Modal open={confirmReset} onClose={() => setConfirmReset(false)} title="Réinitialiser la démo ?">
        <p className="text-sm text-slate-400">Toutes les modifications locales seront perdues.</p>
        <div className="mt-5 flex justify-end gap-2"><Button variant="ghost" onClick={() => setConfirmReset(false)}>Annuler</Button><Button variant="danger" onClick={() => { app.resetDemo(); setConfirmReset(false); }}>Réinitialiser</Button></div>
      </Modal>

      <Modal open={openManual} onClose={() => setOpenManual(false)} title="Proposition manuelle">
        <div className="space-y-4">
          <Field label="Match à venir"><Select value={mMatch} onChange={setMMatch} options={scheduled.map((m) => ({ value: m.id, label: `${d.team(m.homeId).name} – ${d.team(m.awayId).name} (${fmtDateTime(m.kickoff)})` }))} /></Field>
          <Field label="Marché"><Select value={mMarket} onChange={(v) => { setMMarket(v as Market); setMPick(PICKS[v as Market][0]); }} options={(Object.keys(PICKS) as Market[]).map((k) => ({ value: k, label: MARKET_LABEL[k] }))} /></Field>
          <Field label="Sélection"><Select value={mPick} onChange={setMPick} options={PICKS[mMarket].map((x) => ({ value: x, label: x }))} /></Field>
          <p className="text-xs text-slate-500">La proposition sera créée « en attente » : ajoutez justification et cote via « Modifier ».</p>
          <div className="flex justify-end gap-2"><Button variant="ghost" onClick={() => setOpenManual(false)}>Annuler</Button><Button onClick={manualCreate}>Créer</Button></div>
        </div>
      </Modal>
    </div>
  );
}
