import { createContext, useCallback, useContext, useEffect, useReducer, useState, type ReactNode } from 'react';
import type { Prediction, Result, ScanRecord, Session, Tier } from '../types';
import { CONFIG } from '../config';
import { seedPredictions } from '../data/demo';
import { auth, authInfo, supabaseClient } from '../services/auth';
import { createPredictionsRepo } from '../services/predictionsRepo';
import { explain } from '../services/sportsRepo';
import { LIVE } from '../lib/mode';
import { runDemoScan } from '../services/engine';
import { evaluatePick } from '../lib/stats';
import { useData } from './DataContext';

const repo = supabaseClient ? createPredictionsRepo(supabaseClient) : null;

interface State {
  predictions: Prediction[];
  scans: ScanRecord[];
  analyzedIds: string[];
  session: Session | null;
  vipPreview: boolean;
}

type Action =
  | { type: 'scan'; record: ScanRecord; preds: Prediction[]; analyzedIds: string[] }
  | { type: 'patch'; id: string; patch: Partial<Prediction> }
  | { type: 'add'; pred: Prediction }
  | { type: 'set'; preds: Prediction[]; scans: ScanRecord[]; analyzedIds: string[] }
  | { type: 'put'; pred: Prediction }
  | { type: 'login'; session: Session }
  | { type: 'logout' }
  | { type: 'vip'; on: boolean }
  | { type: 'reset' };

const fresh = (): State => ({
  // Mode réel : AUCUNE donnée de démonstration ; tout vient de la base.
  predictions: LIVE ? [] : seedPredictions(),
  scans: [],
  analyzedIds: LIVE ? [] : ['m11', 'm12', 'm13', 'm17', 'm19', 'm21'],
  session: null,
  vipPreview: false,
});

function load(): State {
  if (LIVE) return fresh();   // jamais de données réelles dans localStorage
  try {
    const raw = localStorage.getItem(CONFIG.storageKey);
    if (raw) {
      const s = JSON.parse(raw) as State;
      // La session n'est JAMAIS lue depuis ce stockage (modifiable par l'utilisateur) : elle vient du service d'authentification.
      if (Array.isArray(s.predictions)) return { ...fresh(), ...s, session: null };
    }
  } catch { /* stockage indisponible : on repart d'un état neuf */ }
  return fresh();
}

function reducer(s: State, a: Action): State {
  const touch = (p: Prediction, patch: Partial<Prediction>): Prediction => ({ ...p, ...patch, updatedAt: new Date().toISOString() });
  switch (a.type) {
    case 'scan':
      return {
        ...s,
        scans: [a.record, ...s.scans].slice(0, 50),
        predictions: [...a.preds, ...s.predictions],
        analyzedIds: Array.from(new Set([...s.analyzedIds, ...a.analyzedIds])),
      };
    case 'patch':
      return { ...s, predictions: s.predictions.map((p) => (p.id === a.id ? touch(p, a.patch) : p)) };
    case 'add':
      return { ...s, predictions: [a.pred, ...s.predictions] };
    case 'set':
      return { ...s, predictions: a.preds, scans: a.scans, analyzedIds: a.analyzedIds };
    case 'put':
      return { ...s, predictions: s.predictions.some((p) => p.id === a.pred.id) ? s.predictions.map((p) => (p.id === a.pred.id ? a.pred : p)) : [a.pred, ...s.predictions] };
    case 'login':
      return { ...s, session: a.session };
    case 'logout':
      return { ...s, session: null };
    case 'vip':
      return { ...s, vipPreview: a.on };
    case 'reset':
      return { ...fresh(), session: s.session };
  }
}

interface Toast { id: number; text: string; kind: 'ok' | 'err' | 'info' }

interface StoreValue extends State {
  /** Mode d'authentification actif : 'demo' (identifiants fictifs) ou 'supabase' (vraie authentification). */
  authKind: 'demo' | 'supabase';
  /** false tant que la session existante n'a pas été restaurée au chargement. */
  authReady: boolean;
  isAdmin: boolean;
  hasVip: boolean;
  scanning: boolean;
  toasts: Toast[];
  notify: (text: string, kind?: Toast['kind']) => void;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  toggleVip: () => void;
  runScan: () => Promise<void>;
  validate: (id: string) => void;
  refuse: (id: string) => void;
  reopen: (id: string) => void;
  edit: (id: string, patch: Partial<Prediction>) => void;
  setTier: (id: string, tier: Tier) => void;
  publish: (id: string) => void;
  unpublish: (id: string) => void;
  setResult: (id: string, r: Result) => void;
  settleFromScore: (id: string) => void;
  addManual: (p: Prediction) => void;
  resetDemo: () => void;
}

const Ctx = createContext<StoreValue | null>(null);

export function AppProvider({ children }: { children?: ReactNode }) {
  const data = useData();
  const [state, dispatch] = useReducer(reducer, null, load);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [scanning, setScanning] = useState(false);
  const [authReady, setAuthReady] = useState(false);

  useEffect(() => {
    if (LIVE) return;
    try {
      const { session: _session, ...persisted } = state;   // la session n'est pas persistée ici
      localStorage.setItem(CONFIG.storageKey, JSON.stringify(persisted));
    } catch { /* ignoré */ }
  }, [state]);

  // Restauration de la session au chargement + écoute des changements (autre onglet, jeton expiré).
  useEffect(() => {
    let alive = true;
    auth.init()
      .then((s) => { if (alive) dispatch(s ? { type: 'login', session: s } : { type: 'logout' }); })
      .catch(() => { if (alive) dispatch({ type: 'logout' }); })
      .finally(() => { if (alive) setAuthReady(true); });
    const unsub = auth.subscribe((s) => { if (alive) dispatch(s ? { type: 'login', session: s } : { type: 'logout' }); });
    return () => { alive = false; unsub(); };
  }, []);

  // Mode réel : (re)lecture depuis la base à chaque changement de session — la base décide de ce que chacun voit.
  const sessionKey = state.session?.userId ?? 'anon';
  useEffect(() => {
    if (!LIVE || !repo || !authReady) return;
    let alive = true;
    (async () => {
      try {
        // Les pronostics sont indispensables ; scans (admin) et analyses sont facultatifs : leur échec ne doit pas vider l'écran.
        const [preds, scans, analyzed] = await Promise.all([
          repo.list(),
          state.session?.role === 'admin' ? repo.listScans().catch(() => []) : Promise.resolve([]),
          repo.analyzedFixtureIds().catch(() => []),
        ]);
        if (alive) dispatch({ type: 'set', preds, scans, analyzedIds: analyzed });
      } catch (e) {
        if (alive) notify(`Lecture des pronostics impossible : ${(e as Error).message}`, 'err');
      }
    })();
    return () => { alive = false; };
  }, [authReady, sessionKey]);

  const notify = useCallback((text: string, kind: Toast['kind'] = 'ok') => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, text, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800);
  }, []);

  const isAdmin = state.session?.role === 'admin';
  // Garde-fou : toute action sensible est refusée sans session admin.
  // (En production ce contrôle est refait côté serveur + RLS Supabase.)
  const guard = (fn: () => void) => {
    if (!isAdmin) { notify('Action réservée à l\'administrateur.', 'err'); return; }
    fn();
  };
  const find = (id: string) => state.predictions.find((p) => p.id === id);
  // Écriture réelle : c'est la BASE qui accepte ou refuse (RLS + triggers) ; l'écran n'affiche que ce qu'elle a enregistré.
  const run = (fn: () => Promise<string>) => {
    fn().then((msg) => notify(msg), (e) => notify(explain(e).message, 'err'));
  };
  const liveUpdate = (id: string, patch: Parameters<NonNullable<typeof repo>['update']>[1], msg: string) => {
    if (!repo) return;
    run(async () => { dispatch({ type: 'put', pred: await repo.update(id, patch) }); return msg; });
  };

  const value: StoreValue = {
    ...state,
    authKind: authInfo.kind,
    authReady,
    isAdmin,
    hasVip: isAdmin || (!LIVE && state.vipPreview),
    scanning,
    toasts,
    notify,
    login: async (email, password) => {
      try {
        const session = await auth.signIn(email, password);
        if (session.role !== 'admin') {
          // Cette page de connexion est réservée à l'administration : on ferme aussitôt la session.
          await auth.signOut();
          dispatch({ type: 'logout' });
          notify('Ce compte n\'a pas les droits d\'administrateur.', 'err');
          return false;
        }
        dispatch({ type: 'login', session });
        notify('Connexion réussie.');
        return true;
      } catch (e) {
        notify((e as Error).message, 'err');
        return false;
      }
    },
    logout: () => { auth.signOut(); dispatch({ type: 'logout' }); notify('Déconnecté.', 'info'); },
    toggleVip: () => {
      if (LIVE) { notify('L\'accès VIP réel dépend d\'un abonnement enregistré en base (pas encore proposé à l\'inscription).', 'info'); return; }
      dispatch({ type: 'vip', on: !state.vipPreview });
      notify(state.vipPreview ? 'Aperçu VIP désactivé.' : 'Aperçu VIP (démo) activé — aucun paiement réel.', 'info');
    },
    runScan: async () => {
      if (!isAdmin) { notify('Connectez-vous en administrateur pour lancer un scan.', 'err'); return; }
      if (LIVE) { notify('Scan indisponible : aucune API sportive n\'est connectée (mode manuel). Saisissez les matchs dans « Données sportives ».', 'info'); return; }
      if (scanning) return;
      setScanning(true);
      try {
        const out = await runDemoScan(
          data.matches,
          data.getAnalysis,
          (m) => ({ home: data.team(m.homeId).name, away: data.team(m.awayId).name, league: data.league(m.leagueId).name }),
          state.predictions,
        );
        await new Promise((r) => setTimeout(r, 900)); // simple retour visuel, pas une simulation de réseau
        dispatch({ type: 'scan', record: out.record, preds: out.newPredictions, analyzedIds: out.analyzedIds });
        notify(`Scan démo terminé : ${out.record.proposals} nouvelle(s) proposition(s) en attente de validation.`);
      } finally {
        setScanning(false);
      }
    },
    validate: (id) => guard(() => {
      if (LIVE) return liveUpdate(id, { review: 'validated' }, 'Pronostic validé. Il n\'est pas encore publié.');
      const p = find(id);
      if (!p) return;
      if (!p.justification.trim()) { notify('Ajoutez une justification avant de valider.', 'err'); return; }
      dispatch({ type: 'patch', id, patch: { review: 'validated' } });
      notify('Pronostic validé. Il n\'est pas encore publié.');
    }),
    refuse: (id) => guard(() => { if (LIVE) return liveUpdate(id, { review: 'refused' }, 'Pronostic refusé.'); dispatch({ type: 'patch', id, patch: { review: 'refused', published: false } }); notify('Pronostic refusé.', 'info'); }),
    reopen: (id) => guard(() => { if (LIVE) return liveUpdate(id, { review: 'proposed' }, 'Remis en attente de validation.'); dispatch({ type: 'patch', id, patch: { review: 'proposed', published: false } }); notify('Remis en attente de validation.', 'info'); }),
    edit: (id, patch) => guard(() => {
      if (LIVE) {
        const { market, pick, odds, stake, justification, tier } = patch;
        return liveUpdate(id, { ...(market && { market }), ...(pick && { pick }), ...('odds' in patch && { odds }), ...('stake' in patch && { stake }), ...(justification !== undefined && { justification }), ...(tier && { tier }) }, 'Modifications enregistrées (une validation éventuelle est retirée : à revalider).');
      }
      const p = find(id);
      if (!p) return;
      // Mêmes règles que le trigger SQL `predictions_workflow` (supabase/migrations/…0300) :
      const changed = (['market', 'pick', 'odds', 'stake', 'justification'] as const).some((k) => k in patch && patch[k] !== p[k]);
      if (changed && p.result !== 'pending') { notify('Pronostic soldé : contenu non modifiable.', 'err'); return; }
      // Modifier le contenu d'un pronostic validé retire la validation (et dépublie) : il faut le relire.
      const reset = changed && p.review === 'validated' ? { published: false, review: 'proposed' as const } : {};
      dispatch({ type: 'patch', id, patch: { ...patch, ...reset } });
      notify(changed && p.review === 'validated' ? 'Modifié : validation retirée (et dépublication), à revalider.' : 'Modifications enregistrées.');
    }),
    setTier: (id, tier) => guard(() => LIVE ? liveUpdate(id, { tier }, tier === 'vip' ? 'Réservé aux abonnés VIP.' : 'Accès gratuit.') : dispatch({ type: 'patch', id, patch: { tier } })),
    publish: (id) => guard(() => {
      if (LIVE) return liveUpdate(id, { published: true }, 'Publié.');
      const p = find(id);
      if (!p || p.review !== 'validated') { notify('Seul un pronostic validé peut être publié.', 'err'); return; }
      dispatch({ type: 'patch', id, patch: { published: true } });
      notify(`Publié en ${p.tier === 'vip' ? 'VIP' : 'Gratuit'}.`);
    }),
    unpublish: (id) => guard(() => { if (LIVE) return liveUpdate(id, { published: false }, 'Dépublié.'); dispatch({ type: 'patch', id, patch: { published: false } }); notify('Dépublié.', 'info'); }),
    setResult: (id, r) => guard(() => {
      if (LIVE) return liveUpdate(id, { result: r }, 'Résultat enregistré.');
      const p = find(id);
      if (r !== 'pending' && !p?.published) { notify('Seul un pronostic publié peut être soldé.', 'err'); return; }
      dispatch({ type: 'patch', id, patch: { result: r } });
      notify('Résultat enregistré.');
    }),
    settleFromScore: (id) => guard(() => {
      if (LIVE && repo) {
        run(async () => {
          const r = await repo.settleFromScore(id);
          dispatch({ type: 'put', pred: await repo.get(id) });
          return r === 'won' ? 'Réglé d\'après le score officiel saisi : gagné.' : r === 'lost' ? 'Réglé d\'après le score officiel saisi : perdu.' : 'Réglé : remboursé (void).';
        });
        return;
      }
      const p = find(id);
      const m = p?.matchId ? data.match(p.matchId) : undefined;
      if (p && !p.published) { notify('Seul un pronostic publié peut être soldé.', 'err'); return; }
      if (!p || !m || m.status !== 'finished' || m.homeGoals === undefined || m.awayGoals === undefined) {
        notify('Match non terminé ou score indisponible.', 'err');
        return;
      }
      const r = evaluatePick(p.market, p.pick, m.homeGoals, m.awayGoals);
      if (!r) { notify('Pari non évaluable automatiquement.', 'err'); return; }
      dispatch({ type: 'patch', id, patch: { result: r } });
      notify(r === 'won' ? 'Réglé : gagné.' : 'Réglé : perdu.');
    }),
    addManual: (p) => guard(() => {
      if (LIVE && repo) {
        run(async () => { dispatch({ type: 'put', pred: await repo.create(p) }); return 'Proposition créée (en attente de validation).'; });
        return;
      }
      dispatch({ type: 'add', pred: p }); notify('Proposition manuelle créée (en attente de validation).');
    }),
    resetDemo: () => guard(() => { if (LIVE) { notify('Réinitialisation indisponible en mode réel.', 'err'); return; } dispatch({ type: 'reset' }); notify('Données de démonstration réinitialisées.', 'info'); }),
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp hors AppProvider');
  return v;
}
