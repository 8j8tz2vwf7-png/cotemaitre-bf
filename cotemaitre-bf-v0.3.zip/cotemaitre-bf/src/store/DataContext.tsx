import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { League, Match, MatchAnalysis, Team } from '../types';
import { getProvider } from '../services/football';

const provider = getProvider();

interface DataValue {
  loading: boolean;
  error: string | null;
  mode: 'demo' | 'live';
  providerName: string;
  leagues: League[];
  teams: Team[];
  matches: Match[];
  team: (id: string) => Team;
  league: (id: string) => League;
  match: (id: string) => Match | undefined;
  getAnalysis: (id: string) => Promise<MatchAnalysis | null>;
  /** Colonne `source` de chaque match de la base (vide en démonstration). */
  sources: string[];
  /** Relit la base (après une saisie dans « Données sportives »). */
  reload: () => Promise<void>;
}

const Ctx = createContext<DataValue | null>(null);

export function DataProvider({ children }: { children?: ReactNode }) {
  const [leagues, setLeagues] = useState<League[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [sources, setSources] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    try {
      const r = await provider.load();
      setLeagues(r.leagues); setTeams(r.teams); setMatches(r.matches); setSources(r.sources); setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { void reload(); }, [reload]);

  const value = useMemo<DataValue>(() => {
    const unknownTeam: Team = { id: '?', name: 'Équipe inconnue', short: '???', leagueId: '', hue: 0 };
    const unknownLeague: League = { id: '?', name: 'Championnat inconnu', country: '' };
    return {
      loading, error, mode: provider.mode, providerName: provider.name,
      leagues, teams, matches,
      team: (id) => teams.find((t) => t.id === id) ?? unknownTeam,
      league: (id) => leagues.find((l) => l.id === id) ?? unknownLeague,
      match: (id) => matches.find((m) => m.id === id),
      getAnalysis: (id) => provider.getAnalysis(id),
      sources, reload,
    };
  }, [loading, error, leagues, teams, matches, sources, reload]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useData() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useData hors DataProvider');
  return v;
}

/** Charge l'analyse d'un match (asynchrone pour supporter un vrai backend). */
export function useAnalysis(matchId: string | undefined) {
  const { getAnalysis } = useData();
  const [state, setState] = useState<{ data: MatchAnalysis | null; loading: boolean }>({ data: null, loading: !!matchId });
  useEffect(() => {
    if (!matchId) { setState({ data: null, loading: false }); return; }
    let alive = true;
    setState((s) => ({ ...s, loading: true }));
    getAnalysis(matchId).then((d) => alive && setState({ data: d, loading: false }));
    return () => { alive = false; };
  }, [matchId]);
  return state;
}
