export type MatchStatus = 'scheduled' | 'live' | 'finished' | 'postponed' | 'cancelled';
export type Market = '1X2' | 'DC' | 'OU' | 'BTTS';
export type Tier = 'free' | 'vip';
export type ReviewStatus = 'proposed' | 'validated' | 'refused';
export type Result = 'pending' | 'won' | 'lost' | 'void';
export type PredictionSource = 'demo-seed' | 'demo-scan' | 'admin' | 'bot-live';

export const MARKET_LABEL: Record<Market, string> = {
  '1X2': 'Résultat 1N2',
  DC: 'Double chance',
  OU: 'Plus / Moins de buts',
  BTTS: 'Les deux équipes marquent',
};

export const PICKS: Record<Market, string[]> = {
  '1X2': ['Victoire domicile', 'Match nul', 'Victoire extérieure'],
  DC: ['1X', 'X2', '12'],
  OU: ['Plus de 1,5 buts', 'Moins de 1,5 buts', 'Plus de 2,5 buts', 'Moins de 2,5 buts', 'Plus de 3,5 buts', 'Moins de 3,5 buts'],
  BTTS: ['Les deux équipes marquent : Oui', 'Les deux équipes marquent : Non'],
};

export interface League {
  id: string;
  name: string;
  country: string;
  logoUrl?: string;
}

export interface Team {
  id: string;
  name: string;
  short: string;
  leagueId: string;
  hue: number;
  logoUrl?: string;
}

export interface Match {
  id: string;
  leagueId: string;
  homeId: string;
  awayId: string;
  kickoff: string; // ISO
  status: MatchStatus;
  homeGoals?: number;
  awayGoals?: number;
  demo: boolean;
}

export interface FormEntry {
  opponent: string;
  venue: 'H' | 'A';
  gf: number;
  ga: number;
  res: 'W' | 'D' | 'L';
}

export interface SplitStats {
  played: number;
  wins: number;
  draws: number;
  losses: number;
  gf: number;
  ga: number;
}

export interface Absence {
  role: string;
  reason: 'Blessure' | 'Suspension' | 'Incertain';
}

export interface TeamProfile {
  team: Team;
  last10: FormEntry[];
  home: SplitStats;
  away: SplitStats;
  shotsPerGame: number;
  shotsOnTargetPerGame: number;
  possession: number;
  cleanSheetPct: number;
  failedToScorePct: number;
  absences: Absence[];
}

export interface H2HEntry {
  date: string;
  homeName: string;
  awayName: string;
  hg: number;
  ag: number;
}

export interface StandingRow {
  teamId: string;
  rank: number;
  played: number;
  w: number;
  d: number;
  l: number;
  gf: number;
  ga: number;
  pts: number;
}

export interface Probabilities {
  home: number;
  draw: number;
  away: number;
  dc1X: number;
  dcX2: number;
  dc12: number;
  over: { '1.5': number; '2.5': number; '3.5': number };
  btts: number;
  scores: { score: string; p: number }[];
  lambdaHome: number;
  lambdaAway: number;
}

export interface MatchAnalysis {
  matchId: string;
  home: TeamProfile;
  away: TeamProfile;
  h2h: H2HEntry[];
  standings: StandingRow[];
  probabilities: Probabilities;
  source: 'demo' | 'api-football';
}

export interface Prediction {
  id: string;
  matchId?: string;
  home: string;
  away: string;
  league: string;
  kickoff: string;
  market: Market;
  pick: string;
  odds?: number;
  stake?: number;
  probability?: number;
  justification: string;
  tier: Tier;
  review: ReviewStatus;
  published: boolean;
  result: Result;
  source: PredictionSource;
  createdAt: string;
  updatedAt: string;
  /** Date de publication (preuve que le pronostic précède le match). */
  publishedAt?: string;
  demo: boolean;
}

export interface Session {
  email: string;
  /** 'admin' : accès à l'espace administrateur. 'user' : compte sans droits d'administration. */
  role: 'admin' | 'user';
  userId?: string;
  displayName?: string;
}

export interface ScanDetail {
  matchId: string;
  label: string;
  outcome: 'proposed' | 'existing' | 'discarded';
  note: string;
}

export interface ScanRecord {
  id: string;
  at: string;
  mode: 'DEMO' | 'LIVE';
  detected: number;
  analyzed: number;
  discarded: number;
  proposals: number;
  details: ScanDetail[];
}
