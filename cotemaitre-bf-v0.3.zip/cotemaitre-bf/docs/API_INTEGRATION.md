# Préparation de l'API sportive (C3) — rien n'est connecté aujourd'hui

**État réel : MODE MANUEL.** Aucune API n'est appelée, aucune n'est simulée. L'administrateur saisit les données dans **Données sportives**.

## Architecture prévue (étape ultérieure, après votre validation)
```
API-Football ──► Edge Function (serveur, clé APIFOOTBALL_KEY en secret) ──► tables leagues / teams / fixtures / team_stats
                                                                              (source = 'api-football')
Navigateur ──► lit UNIQUEMENT la base (clé publique + RLS). Il ne connaît jamais la clé de l'API.
```
- Les lignes venant d'une API ont `source = 'api-football'` : un administrateur **ne peut pas les modifier** depuis l'interface (RLS) ; seul le backend (clé `service_role`, côté serveur) les écrit.
- Les lignes manuelles ont `source = 'manual'` et un identifiant ≥ 9 000 000 000 000 : aucune collision possible avec les identifiants de l'API.
- L'interface passe d'elle-même de « MODE MANUEL » à « API-Football » dès qu'au moins un match de la base a `source = 'api-football'` (`src/services/sportsSource.ts`). Rien d'autre à changer côté écran.
- Squelette serveur : `supabase/functions/scan-matches/index.ts` (non déployé, non testé). Appelants autorisés : cron (secret) ou administrateur vérifié en base.
- Même avec la clé `service_role`, la base **refuse** de valider ou publier un pronostic : la validation humaine reste obligatoire.

## À faire plus tard (hors périmètre actuel)
1. Choisir le plan API-Football (quotas) — décision à vous.
2. Écrire la synchronisation (upsert par identifiant API) et la tester sur un projet de test.
3. Déployer la fonction **avec votre autorisation**.
