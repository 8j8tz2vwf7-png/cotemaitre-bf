# Contrat des statistiques d'équipe (`team_stats.stats`, JSON)
Contrôlé par la base (`team_stats_valid`, contrainte CHECK). **Tout champ absent = « non renseigné »** : rien n'est jamais inventé ni complété.

| Champ | Type / règle |
|---|---|
| `form` | texte de 0 à 10 lettres `W` (victoire) `D` (nul) `L` (défaite), ex. `WWDLW` |
| `home`, `away` | `{played, wins, draws, losses, gf, ga}` entiers 0–9999 ; `wins+draws+losses ≤ played` |
| `shots_per_game`, `shots_on_target_per_game`, `possession_pct`, `clean_sheet_pct`, `failed_to_score_pct` | nombre entre 0 et 100 |
| `absences` | liste de `{player, reason: Blessure\|Suspension\|Incertain, verified?: booléen}` |

Clé : une ligne par (équipe, championnat, saison). Saisie : page **Données sportives → Statistiques**.
