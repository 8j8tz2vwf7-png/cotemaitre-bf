// SQUELETTE — Edge Function Supabase (Deno). NON DÉPLOYÉE, NON TESTÉE (Deno absent de l'environnement de dev).
// Rôle futur : récupérer les matchs (API-Football), lancer le moteur statistique, enregistrer des PROPOSITIONS.
// Elle ne publie jamais : la base refuse de toute façon une publication sans validation par un admin connecté
// (triggers de la migration 0300), même avec la clé service_role.
//
// Appelants autorisés : le cron (CRON_SECRET) ou un administrateur connecté. Voir ../_shared/guard.ts.
// Déploiement :  supabase functions deploy scan-matches --no-verify-jwt
// Secrets (supabase secrets set …) — jamais dans le navigateur :
//   APIFOOTBALL_KEY, CRON_SECRET (≥ 16 caractères), ALLOWED_ORIGIN (optionnel)
//   SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont fournis automatiquement par Supabase aux fonctions.
//
// Planification (SQL, après déploiement) :
//   select cron.schedule('scan-15min', '*/15 * * * *',
//     $$ select net.http_post(url := 'https://<projet>.functions.supabase.co/scan-matches',
//        headers := jsonb_build_object('Authorization','Bearer <CRON_SECRET>')) $$);

import { authorize, corsHeaders, json, serviceClient } from '../_shared/guard.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders(req) });
  if (req.method !== 'POST') return json(req, 405, { error: 'Méthode non autorisée.' });

  const db = serviceClient();
  const who = await authorize(req, db);
  if (!who.ok) return json(req, who.status, { error: who.message });

  const key = Deno.env.get('APIFOOTBALL_KEY');
  if (!key) return json(req, 503, { error: 'APIFOOTBALL_KEY non configurée : le scan réel est indisponible.' });

  // 1. Récupérer les matchs du jour
  const today = new Date().toISOString().slice(0, 10);
  const res = await fetch(`https://v3.football.api-sports.io/fixtures?date=${today}`, { headers: { 'x-apisports-key': key } });
  if (!res.ok) return json(req, 502, { error: `API-Football a répondu ${res.status}.` });
  const { response: fixtures } = await res.json();

  // 2. TODO : upsert leagues / teams / fixtures ; collecter forme, H2H, classement, absences
  // 3. TODO : moteur statistique (équivalent serveur de src/services/engine.ts) → table analyses
  // 4. TODO : insérer des propositions { review: 'proposed', published: false, source: 'bot' }
  // 5. Journaliser le scan (mode 'LIVE' : ce n'est PAS une simulation)
  await db.from('scan_runs').insert({ mode: 'LIVE', detected: fixtures.length, analyzed: 0, discarded: 0, proposals: 0, details: [] });

  return json(req, 200, { detected: fixtures.length, note: 'squelette : analyse non implémentée', actor: who.actor === 'cron' ? 'cron' : 'admin' });
});
