// Garde d'autorisation partagée par les Edge Functions (Deno). NON EXÉCUTÉE ICI : Deno n'est pas installé dans
// l'environnement de développement, ce fichier est donc relu mais pas testé. Testez-le avec `supabase functions serve`.
//
// Deux appelants légitimes, rien d'autre :
//   1. le planificateur (cron) : en-tête  Authorization: Bearer <CRON_SECRET>
//   2. un administrateur connecté : en-tête  Authorization: Bearer <jeton de session Supabase>,
//      dont le rôle « admin » est relu dans la table `profiles` (jamais dans le jeton lui-même).
//
// À déployer avec :  supabase functions deploy <nom> --no-verify-jwt
// (le contrôle est fait ici ; la vérification JWT par défaut refuserait le secret du cron).
import { createClient, type SupabaseClient } from 'npm:@supabase/supabase-js@2';

export function serviceClient(): SupabaseClient {
  const url = Deno.env.get('SUPABASE_URL');
  const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');   // secret : uniquement dans les secrets de la fonction
  if (!url || !key) throw new Error('SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY manquants (supabase secrets set …).');
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

/** Comparaison en temps constant (évite de deviner le secret par mesure du temps de réponse). */
export function safeEqual(a: string, b: string): boolean {
  const enc = new TextEncoder();
  const x = enc.encode(a), y = enc.encode(b);
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) diff |= (x[i] ?? 0) ^ (y[i] ?? 0);
  return diff === 0;
}

export type AuthResult =
  | { ok: true; actor: 'cron' | { userId: string } }
  | { ok: false; status: 401 | 403; message: string };

export async function authorize(req: Request, db: SupabaseClient): Promise<AuthResult> {
  const bearer = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '').trim();
  if (!bearer) return { ok: false, status: 401, message: 'Authentification requise.' };

  const cron = Deno.env.get('CRON_SECRET') ?? '';
  if (cron.length >= 16 && safeEqual(bearer, cron)) return { ok: true, actor: 'cron' };

  const { data, error } = await db.auth.getUser(bearer);   // Supabase vérifie signature et expiration du jeton
  if (error || !data.user) return { ok: false, status: 401, message: 'Session invalide ou expirée.' };

  const { data: profile, error: pErr } = await db.from('profiles').select('role').eq('id', data.user.id).maybeSingle();
  if (pErr || profile?.role !== 'admin') return { ok: false, status: 403, message: 'Réservé aux administrateurs.' };
  return { ok: true, actor: { userId: data.user.id } };
}

/** Origine autorisée pour les appels depuis le navigateur (ex. https://app.votre-domaine.com). Vide = aucune. */
export function corsHeaders(req: Request): Record<string, string> {
  const allowed = Deno.env.get('ALLOWED_ORIGIN') ?? '';
  const origin = req.headers.get('Origin') ?? '';
  const h: Record<string, string> = { 'Vary': 'Origin' };
  if (allowed && origin === allowed) {
    h['Access-Control-Allow-Origin'] = allowed;
    h['Access-Control-Allow-Headers'] = 'authorization, content-type';
    h['Access-Control-Allow-Methods'] = 'POST, OPTIONS';
  }
  return h;
}

export function json(req: Request, status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...corsHeaders(req) } });
}
