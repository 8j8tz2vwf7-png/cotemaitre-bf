-- Promouvoir un compte en administrateur. À exécuter UNE FOIS dans Supabase → SQL Editor
-- (le rôle ne peut pas être modifié depuis l'application, par conception).
-- 1) Créez d'abord le compte : Authentication → Users → Add user (e-mail + mot de passe).
-- 2) Remplacez l'adresse ci-dessous, puis exécutez.
update public.profiles
   set role = 'admin'
 where id = (select id from auth.users where email = 'VOTRE_EMAIL@exemple.com');

-- Vérification : doit afficher exactement une ligne avec role = 'admin'.
select p.id, u.email, p.role from public.profiles p join auth.users u on u.id = p.id where p.role = 'admin';
