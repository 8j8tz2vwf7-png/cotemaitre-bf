-- MIGRATION 0600 — Données sportives administrables, cohérence, règle « avant le match », validation humaine stricte.
-- Corrige l'audit de l'étape 3 :
--   C1  l'administrateur ne pouvait écrire ni championnats, ni équipes, ni matchs, ni statistiques.
--   Faille : un `service_role` (le bot) pouvait valider PUIS publier. La validation et la publication exigent
--           désormais un administrateur connecté.
--   Intégrité : statuts, scores, doublons, noms dénormalisés, clés étrangères sans index.
--   Règle métier : un pronostic est enregistré et publié AVANT le coup d'envoi, puis figé.

-- ═════════ 1. Origine des données et identifiants sans collision avec une API ═════════
-- Les lignes saisies à la main reçoivent un identifiant ≥ 9 000 000 000 000 ; les identifiants des API
-- (API-Football : < 10 millions) ne peuvent donc jamais les écraser.
create sequence if not exists public.manual_id_seq start 9000000000000 minvalue 9000000000000;
grant usage on sequence public.manual_id_seq to authenticated;

alter table public.leagues  add column if not exists source text not null default 'manual' check (source in ('manual', 'api-football'));
alter table public.teams    add column if not exists source text not null default 'manual' check (source in ('manual', 'api-football'));
alter table public.fixtures add column if not exists source text not null default 'manual' check (source in ('manual', 'api-football'));

alter table public.leagues  alter column id set default nextval('public.manual_id_seq');
alter table public.teams    alter column id set default nextval('public.manual_id_seq');
alter table public.fixtures alter column id set default nextval('public.manual_id_seq');

-- ═════════ 2. Contraintes d'intégrité ═════════
alter table public.fixtures alter column status set default 'scheduled';
alter table public.fixtures alter column kickoff set not null;
alter table public.fixtures
  add constraint fixtures_status_check check (status in ('scheduled', 'live', 'finished', 'postponed', 'cancelled')),
  add constraint fixtures_distinct_teams check (home_team_id is null or away_team_id is null or home_team_id <> away_team_id),
  add constraint fixtures_goals_check check ((home_goals is null or home_goals >= 0) and (away_goals is null or away_goals >= 0)),
  add constraint fixtures_finished_needs_score check (status <> 'finished' or (home_goals is not null and away_goals is not null)),
  add constraint fixtures_score_only_if_played check (status in ('live', 'finished') or (home_goals is null and away_goals is null)),
  add constraint fixtures_manual_needs_teams check (source <> 'manual' or (home_team_id is not null and away_team_id is not null));

create unique index if not exists leagues_name_country_uq on public.leagues (lower(name), coalesce(country, ''));
create unique index if not exists teams_name_country_uq on public.teams (lower(name), coalesce(country, ''));
create unique index if not exists fixtures_unique_match on public.fixtures (league_id, home_team_id, away_team_id, kickoff)
  where home_team_id is not null and away_team_id is not null;

-- Contrat des statistiques d'équipe (voir docs/DATA_CONTRACT.md). Absent = « donnée non renseignée », jamais inventée.
create function public.team_stats_valid(s jsonb) returns boolean
language plpgsql immutable set search_path = '' as $$
declare
  side text; k text; v jsonb; el jsonb;
begin
  if s is null or jsonb_typeof(s) <> 'object' then return false; end if;
  if s ? 'form' and (jsonb_typeof(s -> 'form') <> 'string' or (s ->> 'form') !~ '^[WDL]{0,10}$') then return false; end if;
  foreach side in array array['home', 'away'] loop
    if s ? side then
      v := s -> side;
      if jsonb_typeof(v) <> 'object' then return false; end if;
      foreach k in array array['played', 'wins', 'draws', 'losses', 'gf', 'ga'] loop
        if not (v ? k) or jsonb_typeof(v -> k) <> 'number' or (v ->> k) !~ '^\d{1,4}$' then return false; end if;
      end loop;
      if (v ->> 'wins')::int + (v ->> 'draws')::int + (v ->> 'losses')::int > (v ->> 'played')::int then return false; end if;
    end if;
  end loop;
  foreach k in array array['shots_per_game', 'shots_on_target_per_game', 'possession_pct', 'clean_sheet_pct', 'failed_to_score_pct'] loop
    if s ? k and (jsonb_typeof(s -> k) <> 'number' or (s ->> k)::numeric < 0 or (s ->> k)::numeric > 100) then return false; end if;
  end loop;
  if s ? 'absences' then
    if jsonb_typeof(s -> 'absences') <> 'array' then return false; end if;
    for el in select * from jsonb_array_elements(s -> 'absences') loop
      if jsonb_typeof(el) <> 'object' or coalesce(btrim(el ->> 'player'), '') = ''
         or (el ->> 'reason') not in ('Blessure', 'Suspension', 'Incertain')
         or (el ? 'verified' and jsonb_typeof(el -> 'verified') <> 'boolean') then return false; end if;
    end loop;
  end if;
  return true;
end $$;

alter table public.team_stats
  add constraint team_stats_valid_check check (public.team_stats_valid(stats));

-- ═════════ 3. Cohérence des noms affichés (dénormalisés dans fixtures) ═════════
create function public.fixtures_sync() returns trigger
language plpgsql set search_path = '' as $$
begin
  if new.home_team_id is not null then select name into new.home_team from public.teams where id = new.home_team_id; end if;
  if new.away_team_id is not null then select name into new.away_team from public.teams where id = new.away_team_id; end if;
  if new.league_id is not null then select name into new.league_name from public.leagues where id = new.league_id; end if;
  -- Saisie manuelle : le code court est déduit du statut (les lignes API gardent le code de l'API).
  if new.source = 'manual' then
    new.status_short := case new.status
      when 'scheduled' then 'NS' when 'live' then 'LIVE' when 'finished' then 'FT'
      when 'postponed' then 'PST' when 'cancelled' then 'CANC' end;
  end if;
  return new;
end $$;
create trigger fixtures_sync_trg before insert or update on public.fixtures
  for each row execute function public.fixtures_sync();

create function public.propagate_names() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_table_name = 'teams' then
    update public.fixtures set home_team = new.name where home_team_id = new.id and home_team is distinct from new.name;
    update public.fixtures set away_team = new.name where away_team_id = new.id and away_team is distinct from new.name;
  else
    update public.fixtures set league_name = new.name where league_id = new.id and league_name is distinct from new.name;
  end if;
  return new;
end $$;
create trigger teams_propagate_name after update of name on public.teams
  for each row execute function public.propagate_names();
create trigger leagues_propagate_name after update of name on public.leagues
  for each row execute function public.propagate_names();

-- Un score ne peut pas changer sous des pronostics déjà soldés (sinon résultat affiché ≠ résultat enregistré).
-- Pour corriger un score : remettre d'abord les pronostics concernés « en attente », corriger, puis les resolder.
create function public.fixtures_lock_scored() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if (new.status, new.home_goals, new.away_goals) is distinct from (old.status, old.home_goals, old.away_goals)
     and exists (select 1 from public.predictions p where p.fixture_id = old.id and p.result <> 'pending') then
    raise exception 'Des pronostics sont déjà soldés sur ce match : remettez-les en attente avant de corriger le score.'
      using errcode = '23514';
  end if;
  return new;
end $$;
create trigger fixtures_lock_scored_trg before update on public.fixtures
  for each row execute function public.fixtures_lock_scored();

-- ═════════ 4. Index des clés étrangères manquants (audit) ═════════
create index if not exists fixtures_home_team_idx on public.fixtures (home_team_id);
create index if not exists fixtures_away_team_idx on public.fixtures (away_team_id);
create index if not exists predictions_created_by_idx on public.predictions (created_by);
create index if not exists predictions_reviewed_by_idx on public.predictions (reviewed_by);
create index if not exists scan_runs_triggered_by_idx on public.scan_runs (triggered_by);
create index if not exists standings_team_idx on public.standings (team_id);
create index if not exists team_stats_league_idx on public.team_stats (league_id);
create index if not exists prediction_events_actor_idx on public.prediction_events (actor);

-- ═════════ 5. Écriture administrateur des données sportives (RLS + privilèges) ═════════
-- Un administrateur ne touche QUE les lignes saisies à la main (source = 'manual', id ≥ 9e12).
-- Les lignes venant d'une API sont réservées au backend : une synchronisation les écraserait de toute façon.
grant insert, update, delete on public.leagues, public.teams, public.fixtures, public.team_stats to authenticated;

create policy leagues_admin_insert on public.leagues for insert to authenticated
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy leagues_admin_update on public.leagues for update to authenticated
  using ((select public.is_admin()) and source = 'manual')
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy leagues_admin_delete on public.leagues for delete to authenticated
  using ((select public.is_admin()) and source = 'manual');

create policy teams_admin_insert on public.teams for insert to authenticated
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy teams_admin_update on public.teams for update to authenticated
  using ((select public.is_admin()) and source = 'manual')
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy teams_admin_delete on public.teams for delete to authenticated
  using ((select public.is_admin()) and source = 'manual');

create policy fixtures_admin_insert on public.fixtures for insert to authenticated
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy fixtures_admin_update on public.fixtures for update to authenticated
  using ((select public.is_admin()) and source = 'manual')
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy fixtures_admin_delete on public.fixtures for delete to authenticated
  using ((select public.is_admin()) and source = 'manual');

create policy team_stats_admin_write on public.team_stats for all to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));

-- ═════════ 6. Workflow des pronostics : validation et publication = acte d'un ADMINISTRATEUR CONNECTÉ ═════════
-- Remplace la fonction de 0300 (même logique, plus la garde « humain »). Seuls passent :
--   • un utilisateur dont le profil est admin (is_admin()),
--   • l'éditeur SQL du projet (rôle postgres / supabase_admin), pour la maintenance.
-- Le rôle service_role (backend, bot, Edge Functions) est REFUSÉ pour valider et publier.
create or replace function public.predictions_workflow() returns trigger
language plpgsql set search_path = '' as $$
declare
  v_content_changed boolean;
  v_human boolean := public.is_admin() or current_user in ('postgres', 'supabase_admin');
begin
  if tg_op = 'INSERT' then
    -- Tout pronostic naît « proposé », non publié, non soldé : la publication est toujours un acte humain distinct.
    new.review := 'proposed';
    new.published := false;
    new.result := 'pending';
    new.reviewed_by := null; new.reviewed_at := null; new.published_at := null; new.settled_at := null;
    new.created_by := coalesce(new.created_by, (select auth.uid()));
    new.created_at := now();
    new.updated_at := now();
    return new;
  end if;

  if new.id <> old.id
     or new.fixture_id is distinct from old.fixture_id
     or new.source <> old.source
     or new.created_at <> old.created_at
     or new.created_by is distinct from old.created_by then
    raise exception 'Champs immuables : id, fixture_id, source, created_by, created_at' using errcode = '23514';
  end if;

  v_content_changed := (new.market, new.pick, new.odds, new.stake, new.probability, new.justification)
                       is distinct from
                       (old.market, old.pick, old.odds, old.stake, old.probability, old.justification);

  if v_content_changed then
    if old.result <> 'pending' then
      raise exception 'Pronostic soldé : contenu non modifiable' using errcode = '23514';
    end if;
    -- Modifier le contenu invalide la validation : il faut relire et revalider.
    if old.review = 'validated' then
      new.review := 'proposed';
      new.published := false;
    end if;
  end if;

  if new.review is distinct from old.review then
    if new.review = 'validated' then
      if btrim(new.justification) = '' then
        raise exception 'Justification obligatoire pour valider' using errcode = '23514';
      end if;
      if not v_human then
        raise exception 'La validation est réservée à un administrateur connecté' using errcode = '42501';
      end if;
      new.reviewed_by := (select auth.uid());
      new.reviewed_at := now();
    else
      new.published := false;
    end if;
  end if;

  if new.published and not old.published then
    if new.review <> 'validated' then
      raise exception 'Seul un pronostic validé peut être publié' using errcode = '23514';
    end if;
    if not v_human then
      raise exception 'La publication est réservée à un administrateur connecté' using errcode = '42501';
    end if;
    new.published_at := now();
  elsif not new.published and old.published then
    new.published_at := null;
  end if;

  if new.result is distinct from old.result then
    if new.result <> 'pending' then
      if not new.published then
        raise exception 'Seul un pronostic publié peut être soldé' using errcode = '23514';
      end if;
      new.settled_at := now();
    else
      new.settled_at := null;
    end if;
  end if;

  new.updated_at := now();
  return new;
end $$;

-- ═════════ 7. Règle « avant le match » ═════════
-- Un pronostic est enregistré et publié AVANT le coup d'envoi (date vérifiable : published_at < kickoff),
-- puis son contenu est figé. Seul le résultat peut ensuite être renseigné.
create function public.predictions_timing() returns trigger
language plpgsql set search_path = '' as $$
declare
  v_kickoff timestamptz;
begin
  if new.fixture_id is not null then
    select kickoff into v_kickoff from public.fixtures where id = new.fixture_id;
  end if;

  if tg_op = 'INSERT' then
    if v_kickoff is not null and v_kickoff <= now() then
      raise exception 'Le match a déjà commencé : un pronostic doit être enregistré avant le coup d''envoi' using errcode = '23514';
    end if;
    return new;
  end if;

  if new.published and not old.published then
    if new.fixture_id is null then
      raise exception 'Un pronostic publié doit être rattaché à un match' using errcode = '23514';
    end if;
    if v_kickoff <= now() then
      raise exception 'Publication impossible : le match a déjà commencé' using errcode = '23514';
    end if;
  end if;

  if v_kickoff is not null and v_kickoff <= now()
     and (new.market, new.pick, new.odds, new.stake, new.probability, new.justification, new.tier)
         is distinct from
         (old.market, old.pick, old.odds, old.stake, old.probability, old.justification, old.tier) then
    raise exception 'Le match a commencé : le pronostic est figé' using errcode = '23514';
  end if;
  return new;
end $$;
-- Nom choisi pour s'exécuter AVANT predictions_workflow_trg (ordre alphabétique des triggers).
create trigger predictions_timing_trg before insert or update on public.predictions
  for each row execute function public.predictions_timing();

revoke all on function public.team_stats_valid(jsonb), public.fixtures_sync(), public.propagate_names(),
  public.fixtures_lock_scored(), public.predictions_timing() from public, anon, authenticated;
grant execute on function public.team_stats_valid(jsonb) to anon, authenticated, service_role;  -- utilisée par une contrainte CHECK
