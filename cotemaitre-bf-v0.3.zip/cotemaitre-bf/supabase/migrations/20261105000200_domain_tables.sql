-- MIGRATION 0200 — Tables métier manquantes + colonnes complémentaires.
-- Ne recrée AUCUNE table du baseline : seulement des ALTER sur l'existant et des tables nouvelles.
-- Les identifiants football (leagues, teams, fixtures) sont ceux d'API-Football, pour des upserts directs.

-- ───────── Abonnements : plans ─────────
create table public.subscription_plans (
  id text primary key check (id ~ '^[a-z][a-z0-9_]*$'),
  name text not null,
  description text,
  price_cents integer check (price_cents is null or price_cents >= 0),  -- NULL = tarif à définir
  currency text not null default 'XOF',
  billing_interval text check (billing_interval in ('month','year','one_time')),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
insert into public.subscription_plans (id, name, description) values
  ('free', 'Gratuit', 'Accès aux pronostics gratuits publiés.'),
  ('vip',  'VIP',     'Analyses approfondies et sélections Premium.');

-- ───────── Championnats, équipes ─────────
create table public.leagues (
  id bigint primary key,                       -- id API-Football
  name text not null,
  country text,
  logo_url text,
  season int,
  is_active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.teams (
  id bigint primary key,                       -- id API-Football
  name text not null,
  short_name text,
  country text,
  logo_url text,
  updated_at timestamptz not null default now()
);

-- ───────── Matchs : compléments (les colonnes texte du baseline sont conservées) ─────────
alter table public.fixtures alter column league_id type bigint;
alter table public.fixtures alter column updated_at set not null;
alter table public.fixtures
  add column season int,
  add column round text,
  add column venue text,
  add column status_short text,                -- code court API-Football : NS, FT, PST…
  add column home_team_id bigint references public.teams(id),
  add column away_team_id bigint references public.teams(id),
  add constraint fixtures_league_id_fkey foreign key (league_id) references public.leagues(id);

-- ───────── Classements, statistiques d'équipes, cotes ─────────
create table public.standings (
  league_id bigint not null references public.leagues(id) on delete cascade,
  season int not null,
  team_id bigint not null references public.teams(id) on delete cascade,
  rank int not null,
  played int not null default 0, wins int not null default 0, draws int not null default 0, losses int not null default 0,
  goals_for int not null default 0, goals_against int not null default 0, points int not null default 0,
  form text,                                    -- ex. 'WWDLW'
  updated_at timestamptz not null default now(),
  primary key (league_id, season, team_id)
);

create table public.team_stats (
  team_id bigint not null references public.teams(id) on delete cascade,
  league_id bigint not null references public.leagues(id) on delete cascade,
  season int not null,
  stats jsonb not null,                         -- forme, domicile/extérieur, moyennes de buts, tirs, absences…
  updated_at timestamptz not null default now(),
  primary key (team_id, league_id, season)
);

create table public.odds (
  id bigint generated always as identity primary key,
  fixture_id bigint not null references public.fixtures(id) on delete cascade,
  bookmaker text not null,
  market text not null,
  selection text not null,
  price numeric(7,2) not null check (price >= 1.01),
  fetched_at timestamptz not null default now(),
  unique (fixture_id, bookmaker, market, selection)
);

-- ───────── Profils ─────────
-- Rôles : 'user' | 'admin' uniquement. Le statut VIP vient de l'abonnement, jamais du rôle.
alter table public.profiles drop constraint profiles_role_check;
update public.profiles set role = 'user' where role not in ('user','admin');
alter table public.profiles
  add constraint profiles_role_check check (role in ('user','admin')),
  add column display_name text,
  add column avatar_url text,
  add column updated_at timestamptz not null default now();
alter table public.profiles alter column created_at set not null;

-- ───────── Analyses : niveau d'accès ─────────
alter table public.analyses
  add column tier public.tier not null default 'free',   -- 'vip' = analyse approfondie réservée aux abonnés
  add column updated_at timestamptz not null default now();
alter table public.analyses alter column created_at set not null;

-- ───────── Pronostics : traçabilité de la validation / publication / règlement ─────────
alter table public.predictions drop constraint predictions_created_by_fkey;
alter table public.predictions
  add constraint predictions_created_by_fkey foreign key (created_by) references auth.users(id) on delete set null,
  add column reviewed_by uuid references auth.users(id) on delete set null,
  add column reviewed_at timestamptz,
  add column published_at timestamptz,
  add column settled_at timestamptz,
  add constraint predictions_source_check check (source in ('bot','bot-live','admin','import')),
  add constraint predictions_probability_check check (probability is null or (probability >= 0 and probability <= 1));
alter table public.predictions alter column created_at set not null;
alter table public.predictions alter column updated_at set not null;

create table public.prediction_events (
  id bigint generated always as identity primary key,
  prediction_id uuid not null references public.predictions(id) on delete cascade,
  actor uuid references auth.users(id) on delete set null,   -- NULL = service_role / système
  action text not null check (action in ('created','edited','validated','refused','reopened','published','unpublished','tier_changed','settled')),
  detail jsonb,
  at timestamptz not null default now()
);

-- ───────── Abonnements : un plan, un statut contrôlé ─────────
alter table public.subscriptions drop constraint subscriptions_user_id_fkey;
alter table public.subscriptions
  add constraint subscriptions_user_id_fkey foreign key (user_id) references auth.users(id) on delete cascade,
  add column plan_id text not null default 'free' references public.subscription_plans(id),
  add column provider text not null default 'manual',          -- 'system' | 'manual' | passerelle de paiement
  add column provider_customer_id text,
  add column provider_subscription_id text,
  add column cancel_at_period_end boolean not null default false,
  add column started_at timestamptz not null default now(),
  add column updated_at timestamptz not null default now();
alter table public.subscriptions alter column status set default 'active';
alter table public.subscriptions
  add constraint subscriptions_status_check check (status in ('active','trialing','past_due','canceled','expired'));

-- ───────── Journal des scans : traçabilité ─────────
alter table public.scan_runs
  add column finished_at timestamptz,
  add column triggered_by uuid references auth.users(id) on delete set null,   -- NULL = planificateur
  add column error text,
  add constraint scan_runs_mode_check check (mode in ('LIVE','DEMO'));

-- ───────── Index ─────────
create index fixtures_kickoff_idx on public.fixtures (kickoff);
create index fixtures_league_kickoff_idx on public.fixtures (league_id, kickoff);
create index predictions_fixture_idx on public.predictions (fixture_id);
create index predictions_review_idx on public.predictions (review, created_at desc);
create index predictions_public_idx on public.predictions (tier, published_at desc) where published and review = 'validated';
create index prediction_events_prediction_idx on public.prediction_events (prediction_id, at desc);
create index subscriptions_plan_status_idx on public.subscriptions (plan_id, status);
create index odds_fixture_idx on public.odds (fixture_id);
create index standings_league_rank_idx on public.standings (league_id, season, rank);
