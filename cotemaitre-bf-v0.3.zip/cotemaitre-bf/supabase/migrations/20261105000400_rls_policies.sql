-- MIGRATION 0400 — Row Level Security + privilèges explicites (défense en profondeur).
-- Deux barrières indépendantes : (1) GRANT/REVOKE au niveau des tables, (2) politiques RLS par ligne.
-- service_role (clé serveur) contourne RLS par conception : elle ne doit JAMAIS quitter le backend.

-- ───────── Secure by default : les futures tables n'héritent plus des droits anon/authenticated ─────────
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;

-- ───────── Activer RLS sur les nouvelles tables (le baseline l'a fait pour les siennes) ─────────
alter table public.subscription_plans enable row level security;
alter table public.leagues            enable row level security;
alter table public.teams              enable row level security;
alter table public.standings          enable row level security;
alter table public.team_stats         enable row level security;
alter table public.odds               enable row level security;
alter table public.prediction_events  enable row level security;

-- ───────── Remplacer les politiques du baseline ─────────
drop policy "profil lisible par son propriétaire" on public.profiles;
drop policy "fixtures publiques"                  on public.fixtures;
drop policy "analyses: admin"                     on public.analyses;
drop policy "pronostics gratuits publiés"         on public.predictions;
drop policy "pronostics VIP publiés (abonnés)"    on public.predictions;
drop policy "admin: tout sur pronostics"          on public.predictions;
drop policy "admin: scans"                        on public.scan_runs;
drop policy "abonnement: le sien"                 on public.subscriptions;

-- ───────── Profils : chacun voit et édite le sien (nom, avatar). Le rôle n'est modifiable que côté serveur. ─────────
create policy "profil: lecture du sien ou admin" on public.profiles for select to authenticated
  using (id = (select auth.uid()) or (select public.is_admin()));
create policy "profil: modification du sien" on public.profiles for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));

-- ───────── Données football : lecture publique, écriture réservée au backend (service_role) ─────────
create policy "ligues: lecture publique"      on public.leagues     for select to anon, authenticated using (true);
create policy "équipes: lecture publique"     on public.teams       for select to anon, authenticated using (true);
create policy "matchs: lecture publique"      on public.fixtures    for select to anon, authenticated using (true);
create policy "classements: lecture publique" on public.standings   for select to anon, authenticated using (true);
create policy "stats équipes: lecture publique" on public.team_stats for select to anon, authenticated using (true);
create policy "cotes: lecture publique"       on public.odds        for select to anon, authenticated using (true);
create policy "plans: lecture des plans actifs" on public.subscription_plans for select to anon, authenticated using (is_active);

-- ───────── Analyses : gratuites pour tous, approfondies (tier = 'vip') pour les abonnés ─────────
create policy "analyses: gratuites ou VIP" on public.analyses for select to anon, authenticated
  using (tier = 'free' or (select public.is_vip()));

-- ───────── Pronostics ─────────
-- Public : uniquement ce qui est VALIDÉ et PUBLIÉ. VIP : en plus, abonnés VIP/admin. Admin : tout.
create policy "pronostics: gratuits publiés" on public.predictions for select to anon, authenticated
  using (published and review = 'validated' and tier = 'free');
create policy "pronostics: VIP publiés pour abonnés" on public.predictions for select to authenticated
  using (published and review = 'validated' and tier = 'vip' and (select public.is_vip()));
create policy "pronostics: admin lecture" on public.predictions for select to authenticated
  using ((select public.is_admin()));
create policy "pronostics: admin création" on public.predictions for insert to authenticated
  with check ((select public.is_admin()));
create policy "pronostics: admin modification" on public.predictions for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy "pronostics: admin suppression" on public.predictions for delete to authenticated
  using ((select public.is_admin()) and not published and result = 'pending');

-- ───────── Journaux : réservés aux administrateurs (écriture par triggers / service_role) ─────────
create policy "historique pronostics: admin" on public.prediction_events for select to authenticated
  using ((select public.is_admin()));
create policy "scans: admin" on public.scan_runs for select to authenticated
  using ((select public.is_admin()));

-- ───────── Abonnements : chacun voit le sien ; AUCUNE écriture client (webhook paiement = service_role, ou RPC admin) ─────────
create policy "abonnement: le sien ou admin" on public.subscriptions for select to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()));

-- ───────── Privilèges de table (couche 1) ─────────
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;

grant select on public.leagues, public.teams, public.fixtures, public.standings, public.team_stats,
                public.odds, public.subscription_plans, public.analyses to anon, authenticated;
grant select on public.predictions to anon, authenticated;
grant insert, update, delete on public.predictions to authenticated;          -- filtré par RLS : admin uniquement
grant select on public.prediction_events, public.scan_runs, public.subscriptions to authenticated;
grant select on public.profiles to authenticated;
grant update (display_name, avatar_url) on public.profiles to authenticated;  -- jamais « role »
