-- MIGRATION 0500 — Vues publiques de performance (AGRÉGATS UNIQUEMENT, jamais de pronostic VIP en clair).
-- Les statistiques sont calculées sur les pronostics publiés, validés ET soldés : jamais sur du démo.
-- Ces vues s'exécutent avec les droits de leur propriétaire (comportement par défaut) : elles voient donc aussi
-- les pronostics VIP pour les agréger, mais n'exposent que des comptes et des ratios.
-- Le linter Supabase peut signaler « security definer view » : c'est voulu et limité à des agrégats.

create view public.performance_base as
  select
    p.id, p.tier, p.market, p.result, p.odds, p.stake, p.published_at,
    coalesce(f.league_name, 'Autre') as league_name
  from public.predictions p
  left join public.fixtures f on f.id = p.fixture_id
  where p.published and p.review = 'validated' and p.result <> 'pending';

-- Rendement théorique : uniquement sur les paris avec cote ET mise renseignées, hors annulés.
create view public.performance_overall as
  select
    count(*) filter (where result = 'won')::int  as won,
    count(*) filter (where result = 'lost')::int as lost,
    count(*) filter (where result = 'void')::int as void,
    count(*)::int as settled,
    case when count(*) filter (where result in ('won','lost')) > 0
         then round(count(*) filter (where result = 'won')::numeric / count(*) filter (where result in ('won','lost')), 4) end as win_rate,
    coalesce(sum(stake) filter (where odds is not null and stake is not null and result <> 'void'), 0) as staked,
    coalesce(sum(case when result = 'won' then stake * (odds - 1) when result = 'lost' then -stake end)
             filter (where odds is not null and stake is not null and result <> 'void'), 0) as profit,
    case when coalesce(sum(stake) filter (where odds is not null and stake is not null and result <> 'void'), 0) > 0
         then round(sum(case when result = 'won' then stake * (odds - 1) when result = 'lost' then -stake end)
                    filter (where odds is not null and stake is not null and result <> 'void')
                    / sum(stake) filter (where odds is not null and stake is not null and result <> 'void'), 4) end as roi
  from public.performance_base;

create view public.performance_by_league as
  select league_name,
         count(*) filter (where result = 'won')::int as won,
         count(*) filter (where result = 'lost')::int as lost,
         count(*)::int as settled,
         case when count(*) filter (where result in ('won','lost')) > 0
              then round(count(*) filter (where result = 'won')::numeric / count(*) filter (where result in ('won','lost')), 4) end as win_rate
  from public.performance_base group by league_name;

create view public.performance_by_market as
  select market,
         count(*) filter (where result = 'won')::int as won,
         count(*) filter (where result = 'lost')::int as lost,
         count(*)::int as settled,
         case when count(*) filter (where result in ('won','lost')) > 0
              then round(count(*) filter (where result = 'won')::numeric / count(*) filter (where result in ('won','lost')), 4) end as win_rate
  from public.performance_base group by market;

-- Aperçu VIP verrouillé : existence et résultat des sélections VIP, SANS le pari, la cote ni la justification.
create view public.vip_teasers as
  select p.id, p.market, p.result, p.published_at,
         f.home_team, f.away_team, f.league_name, f.kickoff
  from public.predictions p
  left join public.fixtures f on f.id = p.fixture_id
  where p.published and p.review = 'validated' and p.tier = 'vip';

revoke all on public.performance_base from anon, authenticated;   -- interne
grant select on public.performance_overall, public.performance_by_league, public.performance_by_market, public.vip_teasers
  to anon, authenticated;
