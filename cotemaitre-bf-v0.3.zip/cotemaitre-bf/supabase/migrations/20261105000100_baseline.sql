-- MIGRATION 0100 — BASELINE : copie fidèle de l'ancien supabase/schema.sql (étape 1). Ne pas modifier : les correctifs sont dans les migrations suivantes.
-- Principe : le public ne lit QUE les pronostics publiés ; seuls les admins écrivent ; le VIP est filtré par la base.

create type market as enum ('1X2','DC','OU','BTTS');
create type tier as enum ('free','vip');
create type review_status as enum ('proposed','validated','refused');
create type pick_result as enum ('pending','won','lost','void');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  role text not null default 'user' check (role in ('user','vip','admin')),
  created_at timestamptz default now()
);

create table fixtures (
  id bigint primary key,                 -- id API-Football
  league_id int not null, league_name text not null,
  home_team text not null, away_team text not null,
  kickoff timestamptz not null, status text not null,
  home_goals int, away_goals int,
  raw jsonb, updated_at timestamptz default now()
);

create table analyses (
  fixture_id bigint primary key references fixtures(id) on delete cascade,
  probabilities jsonb not null,          -- sortie du moteur statistique
  features jsonb, model_version text, created_at timestamptz default now()
);

create table predictions (
  id uuid primary key default gen_random_uuid(),
  fixture_id bigint references fixtures(id),
  market market not null, pick text not null,
  odds numeric(6,2) check (odds is null or odds >= 1.01),
  stake numeric(6,2) check (stake is null or stake > 0),
  probability numeric(5,4),
  justification text not null default '',
  tier tier not null default 'free',
  review review_status not null default 'proposed',
  published boolean not null default false,
  result pick_result not null default 'pending',
  source text not null default 'bot',
  created_by uuid references auth.users, created_at timestamptz default now(), updated_at timestamptz default now(),
  -- Règle métier appliquée par la base : jamais de publication sans validation humaine.
  constraint published_requires_validation check (not published or review = 'validated')
);

create table scan_runs (
  id uuid primary key default gen_random_uuid(),
  started_at timestamptz default now(), mode text not null default 'LIVE',
  detected int, analyzed int, discarded int, proposals int, details jsonb
);

create table subscriptions (
  user_id uuid primary key references auth.users, status text not null, current_period_end timestamptz
);

-- ───────── Sécurité (RLS) ─────────
alter table profiles enable row level security;
alter table fixtures enable row level security;
alter table analyses enable row level security;
alter table predictions enable row level security;
alter table scan_runs enable row level security;
alter table subscriptions enable row level security;

create function is_admin() returns boolean language sql stable security definer as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;
create function is_vip() returns boolean language sql stable security definer as
$$ select exists (select 1 from profiles where id = auth.uid() and role in ('vip','admin')) $$;

create policy "profil lisible par son propriétaire" on profiles for select using (id = auth.uid() or is_admin());
create policy "fixtures publiques" on fixtures for select using (true);
create policy "analyses: admin" on analyses for select using (is_admin());
create policy "pronostics gratuits publiés" on predictions for select using (published and tier = 'free');
create policy "pronostics VIP publiés (abonnés)" on predictions for select using (published and tier = 'vip' and is_vip());
create policy "admin: tout sur pronostics" on predictions for all using (is_admin()) with check (is_admin());
create policy "admin: scans" on scan_runs for select using (is_admin());
create policy "abonnement: le sien" on subscriptions for select using (user_id = auth.uid() or is_admin());
-- Les écritures de fixtures / analyses / scan_runs se font avec la clé service_role depuis le backend UNIQUEMENT.
