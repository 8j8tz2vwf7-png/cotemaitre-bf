-- MIGRATION 0300 — Fonctions de sécurité, triggers métier, RPC administrateur.
-- Toutes les fonctions SECURITY DEFINER fixent search_path = '' (anti-détournement) et qualifient leurs objets.

-- ───────── Aides d'autorisation (remplacent celles du baseline) ─────────
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin')
$$;

-- VIP = administrateur OU abonnement VIP actif/en essai non expiré.
create or replace function public.is_vip() returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_admin() or exists (
    select 1 from public.subscriptions s
    where s.user_id = (select auth.uid())
      and s.plan_id = 'vip'
      and s.status in ('active','trialing')
      and (s.current_period_end is null or s.current_period_end > now())
  )
$$;

-- ───────── Horodatage générique ─────────
create function public.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin
  new.updated_at := now();
  return new;
end $$;

create trigger touch_profiles       before update on public.profiles       for each row execute function public.touch_updated_at();
create trigger touch_fixtures       before update on public.fixtures       for each row execute function public.touch_updated_at();
create trigger touch_leagues        before update on public.leagues        for each row execute function public.touch_updated_at();
create trigger touch_teams          before update on public.teams          for each row execute function public.touch_updated_at();
create trigger touch_analyses       before update on public.analyses       for each row execute function public.touch_updated_at();
create trigger touch_team_stats     before update on public.team_stats     for each row execute function public.touch_updated_at();
create trigger touch_standings      before update on public.standings      for each row execute function public.touch_updated_at();
create trigger touch_subscriptions  before update on public.subscriptions  for each row execute function public.touch_updated_at();

-- ───────── Création automatique du profil + abonnement gratuit à l'inscription ─────────
-- Le rôle est TOUJOURS 'user' : on ne lit jamais raw_user_meta_data pour le rôle (modifiable par l'utilisateur).
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(nullif(btrim(new.raw_user_meta_data ->> 'display_name'), ''), split_part(coalesce(new.email, ''), '@', 1)))
  on conflict (id) do nothing;

  insert into public.subscriptions (user_id, plan_id, status, provider)
  values (new.id, 'free', 'active', 'system')
  on conflict (user_id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Rattrapage des comptes créés avant cette migration.
insert into public.profiles (id, display_name)
  select u.id, split_part(coalesce(u.email, ''), '@', 1) from auth.users u on conflict (id) do nothing;
insert into public.subscriptions (user_id, plan_id, status, provider)
  select u.id, 'free', 'active', 'system' from auth.users u on conflict (user_id) do nothing;

-- ───────── Workflow des pronostics, imposé par la base (même pour service_role) ─────────
create function public.predictions_workflow() returns trigger
language plpgsql set search_path = '' as $$
declare
  v_content_changed boolean;
begin
  if tg_op = 'INSERT' then
    -- Tout pronostic naît « proposé », non publié, non soldé : la publication est toujours un acte humain distinct.
    new.review := 'proposed';
    new.published := false;
    new.result := 'pending';
    new.reviewed_by := null; new.reviewed_at := null; new.published_at := null; new.settled_at := null;
    new.created_by := coalesce(new.created_by, (select auth.uid()));
    new.created_at := now();
    new.updated_at := now();
    return new;
  end if;

  if new.id <> old.id
     or new.fixture_id is distinct from old.fixture_id
     or new.source <> old.source
     or new.created_at <> old.created_at
     or new.created_by is distinct from old.created_by then
    raise exception 'Champs immuables : id, fixture_id, source, created_by, created_at' using errcode = '23514';
  end if;

  v_content_changed := (new.market, new.pick, new.odds, new.stake, new.probability, new.justification)
                       is distinct from
                       (old.market, old.pick, old.odds, old.stake, old.probability, old.justification);

  if v_content_changed then
    if old.result <> 'pending' then
      raise exception 'Pronostic soldé : contenu non modifiable' using errcode = '23514';
    end if;
    -- Modifier le contenu invalide la validation : il faut relire et revalider.
    if old.review = 'validated' then
      new.review := 'proposed';
      new.published := false;
    end if;
  end if;

  if new.review is distinct from old.review then
    if new.review = 'validated' then
      if btrim(new.justification) = '' then
        raise exception 'Justification obligatoire pour valider' using errcode = '23514';
      end if;
      new.reviewed_by := (select auth.uid());
      new.reviewed_at := now();
    else
      new.published := false;
    end if;
  end if;

  if new.published and not old.published then
    if new.review <> 'validated' then
      raise exception 'Seul un pronostic validé peut être publié' using errcode = '23514';
    end if;
    new.published_at := now();
  elsif not new.published and old.published then
    new.published_at := null;
  end if;

  if new.result is distinct from old.result then
    if new.result <> 'pending' then
      if not new.published then
        raise exception 'Seul un pronostic publié peut être soldé' using errcode = '23514';
      end if;
      new.settled_at := now();
    else
      new.settled_at := null;
    end if;
  end if;

  new.updated_at := now();
  return new;
end $$;

create trigger predictions_workflow_trg before insert or update on public.predictions
  for each row execute function public.predictions_workflow();

-- ───────── Journal d'audit des pronostics ─────────
create function public.predictions_log_event() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  v_actor uuid := (select auth.uid());
begin
  if tg_op = 'INSERT' then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, 'created', jsonb_build_object('source', new.source, 'market', new.market, 'pick', new.pick));
    return null;
  end if;

  if (new.market, new.pick, new.odds, new.stake, new.probability, new.justification)
     is distinct from (old.market, old.pick, old.odds, old.stake, old.probability, old.justification) then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, 'edited', jsonb_build_object('pick_before', old.pick, 'pick_after', new.pick, 'odds_before', old.odds, 'odds_after', new.odds));
  end if;
  if new.review is distinct from old.review then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor,
            case new.review when 'validated' then 'validated' when 'refused' then 'refused' else 'reopened' end,
            jsonb_build_object('from', old.review, 'to', new.review));
  end if;
  if new.published is distinct from old.published then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, case when new.published then 'published' else 'unpublished' end, jsonb_build_object('tier', new.tier));
  end if;
  if new.tier is distinct from old.tier then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, 'tier_changed', jsonb_build_object('from', old.tier, 'to', new.tier));
  end if;
  if new.result is distinct from old.result then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, 'settled', jsonb_build_object('from', old.result, 'to', new.result));
  end if;
  return null;
end $$;

create trigger predictions_log_trg after insert or update on public.predictions
  for each row execute function public.predictions_log_event();

-- ───────── Évaluation d'un pari à partir du score (miroir de src/lib/stats.ts → evaluatePick) ─────────
create function public.evaluate_pick(p_pick text, p_home_goals int, p_away_goals int) returns text
language sql immutable set search_path = '' as $$
  select case p_pick
    when 'Victoire domicile'    then case when p_home_goals >  p_away_goals then 'won' else 'lost' end
    when 'Match nul'            then case when p_home_goals =  p_away_goals then 'won' else 'lost' end
    when 'Victoire extérieure'  then case when p_away_goals >  p_home_goals then 'won' else 'lost' end
    when '1X'                   then case when p_home_goals >= p_away_goals then 'won' else 'lost' end
    when 'X2'                   then case when p_away_goals >= p_home_goals then 'won' else 'lost' end
    when '12'                   then case when p_home_goals <> p_away_goals then 'won' else 'lost' end
    when 'Plus de 1,5 buts'     then case when p_home_goals + p_away_goals >  1 then 'won' else 'lost' end
    when 'Moins de 1,5 buts'    then case when p_home_goals + p_away_goals <= 1 then 'won' else 'lost' end
    when 'Plus de 2,5 buts'     then case when p_home_goals + p_away_goals >  2 then 'won' else 'lost' end
    when 'Moins de 2,5 buts'    then case when p_home_goals + p_away_goals <= 2 then 'won' else 'lost' end
    when 'Plus de 3,5 buts'     then case when p_home_goals + p_away_goals >  3 then 'won' else 'lost' end
    when 'Moins de 3,5 buts'    then case when p_home_goals + p_away_goals <= 3 then 'won' else 'lost' end
    when 'Les deux équipes marquent : Oui' then case when p_home_goals > 0 and p_away_goals > 0 then 'won' else 'lost' end
    when 'Les deux équipes marquent : Non' then case when p_home_goals > 0 and p_away_goals > 0 then 'lost' else 'won' end
    else null
  end
$$;

-- ───────── RPC administrateur (contrôle du rôle fait EN BASE, pas seulement dans l'interface) ─────────
create function public.admin_settle_prediction(p_id uuid) returns public.pick_result
language plpgsql security definer set search_path = '' as $$
declare
  p public.predictions;
  f public.fixtures;
  r text;
begin
  if not public.is_admin() then
    raise exception 'Accès réservé aux administrateurs' using errcode = '42501';
  end if;
  select * into p from public.predictions where id = p_id;
  if not found then
    raise exception 'Pronostic introuvable' using errcode = 'P0002';
  end if;
  select * into f from public.fixtures where id = p.fixture_id;
  if not found or f.home_goals is null or f.away_goals is null
     or coalesce(f.status_short, f.status) not in ('FT','AET','PEN','finished') then
    raise exception 'Match non terminé ou score indisponible' using errcode = '22023';
  end if;
  r := public.evaluate_pick(p.pick, f.home_goals, f.away_goals);
  if r is null then
    raise exception 'Pari non évaluable automatiquement' using errcode = '22023';
  end if;
  update public.predictions set result = r::public.pick_result where id = p_id;
  return r::public.pick_result;
end $$;

create function public.admin_set_subscription(
  p_user uuid, p_plan text, p_status text default 'active', p_until timestamptz default null
) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then
    raise exception 'Accès réservé aux administrateurs' using errcode = '42501';
  end if;
  insert into public.subscriptions (user_id, plan_id, status, current_period_end, provider)
  values (p_user, p_plan, p_status, p_until, 'manual')
  on conflict (user_id) do update
    set plan_id = excluded.plan_id, status = excluded.status,
        current_period_end = excluded.current_period_end, provider = 'manual';
end $$;

-- ───────── Droits d'exécution : fermé par défaut, ouvert au strict nécessaire ─────────
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.is_admin(), public.is_vip() to anon, authenticated;
grant execute on function public.evaluate_pick(text, int, int) to anon, authenticated;
grant execute on function public.admin_settle_prediction(uuid) to authenticated;
grant execute on function public.admin_set_subscription(uuid, text, text, timestamptz) to authenticated;
