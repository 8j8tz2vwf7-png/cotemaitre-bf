-- Tests de la migration 0600 : saisie admin des données sportives, intégrité, validation humaine, règle « avant le match ».
-- S'exécute après 10_rls_and_workflow.test.sql (schéma t et jeu de données déjà présents).
\set ON_ERROR_STOP on
truncate t.results;

do $$
declare
  A uuid := 'a0000000-0000-0000-0000-000000000001';
  U uuid := 'b0000000-0000-0000-0000-000000000001';
  V uuid := 'c0000000-0000-0000-0000-000000000001';
  lg bigint; t1 bigint; t2 bigint; fx bigint; fx2 bigint; p uuid; n bigint;
begin
  -- ── Utilisateurs non admin ──
  perform t.become(U);
  perform t.throws('user: ne peut pas créer de championnat', $q$insert into public.leagues (name, source) values ('Pirate', 'manual')$q$, '42501');
  perform t.throws('user: ne peut pas créer d''équipe', $q$insert into public.teams (name, source) values ('Pirate FC', 'manual')$q$, '42501');
  perform t.throws('user: ne peut pas écrire de statistiques', $q$insert into public.team_stats (team_id, league_id, season, stats) values (10, 1, 2026, '{}')$q$, '42501');
  perform t.ok('user: ne modifie aucun match (RLS)', t.affected($q$update public.fixtures set status = 'cancelled'$q$) = 0);
  perform t.back();
  perform t.become(null);
  perform t.throws('anon: ne peut rien écrire (leagues)', $q$insert into public.leagues (name) values ('X')$q$, '42501');
  perform t.back();

  -- ── Admin : championnats, équipes, matchs ──
  perform t.become(A);
  insert into public.leagues (name, country) values ('Championnat du Faso', 'Burkina Faso') returning id into lg;
  perform t.ok('admin: crée un championnat (id manuel ≥ 9e12)', lg >= 9000000000000);
  insert into public.teams (name, country) values ('Étoile Filante', 'Burkina Faso') returning id into t1;
  insert into public.teams (name, country) values ('Racing Club', 'Burkina Faso') returning id into t2;
  perform t.ok('admin: crée deux équipes', t1 >= 9000000000000 and t2 > t1);
  perform t.throws('doublon de championnat refusé', $q$insert into public.leagues (name, country) values ('championnat du faso', 'Burkina Faso')$q$, '23505');
  perform t.throws('doublon d''équipe (même casse) refusé', $q$insert into public.teams (name, country) values ('Étoile Filante', 'Burkina Faso')$q$, '23505');
  perform t.throws('admin: ne peut pas se fabriquer un id d''API', $q$insert into public.leagues (id, name) values (5000, 'Faux API')$q$, '42501');
  perform t.throws('admin: ne peut pas créer une ligne source=api-football', $q$insert into public.leagues (name, source) values ('Faux API 2', 'api-football')$q$, '42501');

  insert into public.fixtures (league_id, home_team_id, away_team_id, kickoff)
    values (lg, t1, t2, now() + interval '3 days') returning id into fx;
  perform t.ok('match: noms et code statut synchronisés', (select (home_team, away_team, league_name, status, status_short) =
    ('Étoile Filante', 'Racing Club', 'Championnat du Faso', 'scheduled', 'NS') from public.fixtures where id = fx));
  perform t.throws('match: une équipe ne joue pas contre elle-même', format($q$insert into public.fixtures (league_id, home_team_id, away_team_id, kickoff) values (%s, %s, %s, now() + interval '5 days')$q$, lg, t1, t1), '23514');
  perform t.throws('match: doublon exact refusé', format($q$insert into public.fixtures (league_id, home_team_id, away_team_id, kickoff) select league_id, home_team_id, away_team_id, kickoff from public.fixtures where id = %s$q$, fx), '23505');
  perform t.throws('match: statut inconnu refusé', format($q$update public.fixtures set status = 'bizarre' where id = %s$q$, fx), '23514');
  perform t.throws('match: « terminé » sans score refusé', format($q$update public.fixtures set status = 'finished' where id = %s$q$, fx), '23514');
  perform t.throws('match: score sur un match programmé refusé', format($q$update public.fixtures set home_goals = 1, away_goals = 0 where id = %s$q$, fx), '23514');
  perform t.throws('match: score négatif refusé', format($q$update public.fixtures set status='live', home_goals = -1, away_goals = 0 where id = %s$q$, fx), '23514');

  -- Renommage : propagation aux matchs.
  update public.teams set name = 'Étoile Filante de Ouaga' where id = t1;
  update public.leagues set name = 'Faso Premier' where id = lg;
  perform t.ok('renommage propagé aux matchs', (select (home_team, league_name) = ('Étoile Filante de Ouaga', 'Faso Premier') from public.fixtures where id = fx));
  perform t.ok('admin: ne modifie pas une équipe venant d''une API', t.affected($q$update public.teams set name = 'Renommée' where source = 'api-football'$q$) = 0);

  -- ── Statistiques d'équipe : contrat ──
  insert into public.team_stats (team_id, league_id, season, stats) values
    (t1, lg, 2026, '{"form":"WWDLW","home":{"played":5,"wins":3,"draws":1,"losses":1,"gf":8,"ga":4},"possession_pct":54,"absences":[{"player":"A. Ouédraogo","reason":"Blessure","verified":true}]}');
  perform t.ok('admin: ajoute des statistiques valides', true);
  perform t.throws('stats: forme invalide refusée', format($q$insert into public.team_stats (team_id, league_id, season, stats) values (%s, %s, 2025, '{"form":"WXZ"}')$q$, t1, lg), '23514');
  perform t.throws('stats: V+N+D > joués refusé', format($q$insert into public.team_stats (team_id, league_id, season, stats) values (%s, %s, 2024, '{"home":{"played":2,"wins":2,"draws":1,"losses":0,"gf":1,"ga":0}}')$q$, t1, lg), '23514');
  perform t.throws('stats: pourcentage > 100 refusé', format($q$insert into public.team_stats (team_id, league_id, season, stats) values (%s, %s, 2023, '{"possession_pct":140}')$q$, t1, lg), '23514');
  perform t.throws('stats: absence sans motif valide refusée', format($q$insert into public.team_stats (team_id, league_id, season, stats) values (%s, %s, 2022, '{"absences":[{"player":"X","reason":"Vacances"}]}')$q$, t1, lg), '23514');

  -- ── Pronostic : avant le match ──
  insert into public.predictions (fixture_id, market, pick, odds, stake, justification, source)
    values (fx, '1X2', 'Victoire domicile', 2.1, 1, 'Forme et avantage du terrain', 'admin') returning id into p;
  update public.predictions set review = 'validated' where id = p;
  update public.predictions set published = true where id = p;
  perform t.ok('pronostic: validé puis publié par l''admin avant le match', (select published and published_at < f.kickoff from public.predictions x join public.fixtures f on f.id = x.fixture_id where x.id = p));
  perform t.back();

  -- Gel après coup d'envoi : on avance le match dans le passé (superutilisateur) et on tente de modifier.
  update public.fixtures set kickoff = now() - interval '1 hour' where id = fx;
  perform t.become(A);
  perform t.throws('pronostic : contenu gelé une fois le match commencé', format($q$update public.predictions set pick = 'Match nul' where id = %L$q$, p), '23514');
  perform t.back();
  update public.fixtures set kickoff = now() + interval '3 days' where id = fx;

  -- Création tardive refusée
  perform t.become(A);
  perform t.throws('pronostic : création refusée sur un match déjà commencé', $q$insert into public.predictions (fixture_id, market, pick, justification, source) values (103, '1X2', 'Match nul', 'trop tard', 'admin')$q$, '23514');
  perform t.back();

  -- Verrou du score sous pronostics soldés (manuel) : on simule un match terminé puis soldé
  perform t.become(A);
  insert into public.fixtures (league_id, home_team_id, away_team_id, kickoff) values (lg, t2, t1, now() + interval '9 days') returning id into fx2;
  perform t.back();
  p := t.mk(fx2, '1X2', 'Victoire domicile', 'free', 'pending', 2.0, 1);
  update public.fixtures set kickoff = now() - interval '2 hours' where id = fx2;
  perform t.become(A);
  update public.fixtures set status = 'finished', home_goals = 2, away_goals = 0 where id = fx2;
  perform t.ok('admin: renseigne le score → statut FT automatique', (select status_short = 'FT' from public.fixtures where id = fx2));
  perform public.admin_settle_prediction(p);
  perform t.ok('règlement depuis le score saisi', (select result = 'won' from public.predictions where id = p));
  perform t.throws('score non modifiable sous pronostic soldé', format($q$update public.fixtures set home_goals = 0 where id = %s$q$, fx2), '23514');
  perform t.back();
  perform t.become(A);
  update public.predictions set result = 'pending' where id = p;
  update public.fixtures set home_goals = 0, away_goals = 0 where id = fx2;
  perform t.ok('remise en attente puis correction du score possible', (select home_goals = 0 from public.fixtures where id = fx2));
  perform t.back();

  -- Suppression : une équipe utilisée par un match ne peut pas être supprimée (clé étrangère), une équipe libre oui.
  perform t.become(A);
  perform t.throws('équipe utilisée par un match : suppression refusée', format($q$delete from public.teams where id = %s$q$, t1), '23503');
  insert into public.teams (name, country) values ('Équipe temporaire', 'Burkina Faso') returning id into n;
  perform t.ok('admin: supprime une équipe manuelle libre', t.affected(format($q$delete from public.teams where id = %s$q$, n)) = 1);
  perform t.back();
end $$;

-- ═════════ Validation humaine : le backend (service_role) ne valide ni ne publie ═════════
do $$
declare p uuid;
begin
  perform t.become_service();
  insert into public.predictions (fixture_id, market, pick, justification, source) values (102, '1X2', 'Match nul', 'proposition du bot', 'bot') returning id into p;
  perform t.throws('bot: ne peut pas VALIDER (réservé admin connecté)', format($q$update public.predictions set review = 'validated' where id = %L$q$, p), '42501');
  perform t.back();
  -- admin SQL (rôle postgres) : autorisé pour maintenance
  update public.predictions set review = 'validated' where id = p;
  perform t.ok('SQL editor (postgres) peut valider', (select review = 'validated' from public.predictions where id = p));
  perform t.become_service();
  perform t.throws('bot: ne peut pas PUBLIER même un pronostic validé', format($q$update public.predictions set published = true where id = %L$q$, p), '42501');
  perform t.back();
  perform t.become('a0000000-0000-0000-0000-000000000001');
  update public.predictions set published = true where id = p;
  perform t.ok('admin connecté publie', (select published from public.predictions where id = p));
  perform t.back();
end $$;

-- ═════════ Index des clés étrangères ═════════
do $$
begin
  perform t.ok('schéma: toute clé étrangère a un index couvrant (colonne de tête)',
    (select count(*) from pg_constraint c
      where c.contype = 'f' and c.connamespace = 'public'::regnamespace
        and not exists (select 1 from pg_index i where i.indrelid = c.conrelid and i.indkey[0] = c.conkey[1])) = 0,
    (select string_agg(conrelid::regclass || '.' || conname, ', ') from pg_constraint c
      where c.contype = 'f' and c.connamespace = 'public'::regnamespace
        and not exists (select 1 from pg_index i where i.indrelid = c.conrelid and i.indkey[0] = c.conkey[1])));
end $$;

select case when ok then 'PASS' else 'FAIL' end as statut, name, detail from t.results order by n;
do $$
declare f int; n int;
begin
  select count(*) filter (where not ok), count(*) into f, n from t.results;
  raise notice '== sports 20 : % test(s), % échec(s) ==', n, f;
  if f > 0 then raise exception 'ÉCHECS dans 20_sports_data'; end if;
end $$;
