-- Tests de sécurité et de règles métier. Exécutés par scripts/test-sql.sh sur un PostgreSQL de test
-- (après tests/00_stub_supabase.sql + toutes les migrations). Échoue (code de sortie ≠ 0) si un test échoue.
\set ON_ERROR_STOP on

create schema t;
create table t.results (n int generated always as identity, name text, ok boolean, detail text);
grant usage on schema t to public;
grant all on t.results to public;
grant usage on all sequences in schema t to public;

create function t.ok(p_name text, p_cond boolean, p_detail text default null) returns void language sql as
$$ insert into t.results(name, ok, detail) values (p_name, coalesce(p_cond, false), p_detail) $$;
create function t.become(p_uid uuid) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claim.sub', coalesce(p_uid::text, ''), true);
  if p_uid is null then execute 'set local role anon'; else execute 'set local role authenticated'; end if;
end $$;
create function t.become_service() returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', '', true); execute 'set local role service_role'; end $$;
create function t.back() returns void language plpgsql as $$
begin execute 'reset role'; perform set_config('request.jwt.claim.sub', '', true); end $$;
create function t.throws(p_name text, p_sql text, p_state text default null) returns void language plpgsql as $$
declare v_state text;
begin
  begin
    execute p_sql;
    perform t.ok(p_name, false, 'aucune erreur levée');
  exception when others then
    get stacked diagnostics v_state = returned_sqlstate;
    perform t.ok(p_name, p_state is null or v_state = p_state, 'sqlstate=' || v_state || ' / ' || sqlerrm);
  end;
end $$;
create function t.affected(p_sql text) returns bigint language plpgsql as $$
declare n bigint; begin execute p_sql; get diagnostics n = row_count; return n; end $$;
create function t.count(p_sql text) returns bigint language plpgsql as $$
declare n bigint; begin execute 'select count(*) from (' || p_sql || ') q' into n; return n; end $$;

-- Crée un pronostic publié (et éventuellement soldé) — exécuté en superutilisateur.
create function t.mk(p_fixture bigint, p_market public.market, p_pick text, p_tier public.tier,
                     p_result public.pick_result, p_odds numeric, p_stake numeric) returns uuid language plpgsql as $$
declare v uuid; v_ko timestamptz;
begin
  -- Règle « avant le match » : on décale brièvement le coup d'envoi dans le futur pour enregistrer/publier,
  -- puis on le restaure (le résultat, lui, se règle après le match).
  select kickoff into v_ko from public.fixtures where id = p_fixture;
  alter table public.fixtures disable trigger fixtures_lock_scored_trg;
  update public.fixtures set kickoff = now() + interval '30 days' where id = p_fixture;
  insert into public.predictions (fixture_id, market, pick, odds, stake, justification, tier, source)
  values (p_fixture, p_market, p_pick, p_odds, p_stake, 'justification de test', p_tier, 'admin') returning id into v;
  update public.predictions set review = 'validated', published = true where id = v;
  update public.fixtures set kickoff = v_ko where id = p_fixture;
  alter table public.fixtures enable trigger fixtures_lock_scored_trg;
  if p_result <> 'pending' then update public.predictions set result = p_result where id = v; end if;
  return v;
end $$;

-- ═════════ 0. Jeu de données ═════════
do $$
declare
  A uuid := 'a0000000-0000-0000-0000-000000000001';  -- admin
  U uuid := 'b0000000-0000-0000-0000-000000000001';  -- utilisateur gratuit
  V uuid := 'c0000000-0000-0000-0000-000000000001';  -- VIP actif
  X uuid := 'd0000000-0000-0000-0000-000000000001';  -- VIP expiré
  Y uuid := 'e0000000-0000-0000-0000-000000000001';  -- VIP annulé
begin
  insert into auth.users (id, email) values
    (A, 'admin@test.local'), (U, 'user@test.local'), (V, 'vip@test.local'), (X, 'expired@test.local'), (Y, 'canceled@test.local');
  update public.profiles set role = 'admin' where id = A;
  update public.subscriptions set plan_id = 'vip', status = 'active' where user_id = V;
  update public.subscriptions set plan_id = 'vip', status = 'active', current_period_end = now() - interval '1 day' where user_id = X;
  update public.subscriptions set plan_id = 'vip', status = 'canceled' where user_id = Y;

  -- Inscription malveillante : un rôle dans les métadonnées ne doit rien élever.
  insert into auth.users (id, email, raw_user_meta_data)
    values ('f0000000-0000-0000-0000-000000000001', 'evil@test.local', '{"role":"admin","display_name":"Evil"}');

  insert into public.leagues (id, name) values (1, 'Ligue A'), (2, 'Ligue B');
  insert into public.teams (id, name) values (10, 'Equipe 10'), (11, 'Equipe 11'), (12, 'Equipe 12'), (13, 'Equipe 13');
  insert into public.fixtures (id, league_id, league_name, home_team, away_team, kickoff, status, status_short, home_goals, away_goals, home_team_id, away_team_id, source) values
    (100, 1, 'Ligue A', 'Equipe 10', 'Equipe 11', now() - interval '1 day', 'finished', 'FT', 2, 1, 10, 11, 'api-football'),
    (101, 2, 'Ligue B', 'Equipe 12', 'Equipe 13', now() + interval '1 day', 'scheduled', 'NS', null, null, 12, 13, 'api-football'),
    (102, 1, 'Ligue A', 'Equipe 11', 'Equipe 10', now() + interval '2 day', 'scheduled', 'NS', null, null, 11, 10, 'api-football'),
    (103, 2, 'Ligue B', 'Equipe 13', 'Equipe 12', now() - interval '2 day', 'finished', 'FT', 0, 0, 13, 12, 'api-football');
  perform t.ok('setup: données de test créées', true);
end $$;

-- ═════════ 1. Inscription : profil + abonnement gratuit automatiques ═════════
do $$
begin
  perform t.ok('signup: un profil par compte', (select count(*) from public.profiles) = (select count(*) from auth.users));
  perform t.ok('signup: un abonnement par compte', (select count(*) from public.subscriptions) = (select count(*) from auth.users));
  perform t.ok('signup: rôle « user » par défaut', (select role from public.profiles where id = 'b0000000-0000-0000-0000-000000000001') = 'user');
  perform t.ok('signup: abonnement gratuit actif par défaut',
    (select plan_id || '/' || status from public.subscriptions where user_id = 'b0000000-0000-0000-0000-000000000001') = 'free/active');
  perform t.ok('signup: {"role":"admin"} dans les métadonnées n''élève PAS les droits',
    (select role from public.profiles where id = 'f0000000-0000-0000-0000-000000000001') = 'user');
  perform t.ok('signup: display_name repris des métadonnées',
    (select display_name from public.profiles where id = 'f0000000-0000-0000-0000-000000000001') = 'Evil');
end $$;

-- ═════════ 2. Statistiques : calcul sur pronostics publiés ET soldés uniquement ═════════
do $$
begin
  perform t.mk(100, '1X2', 'Victoire domicile', 'free', 'won',  2.00, 1);
  perform t.mk(100, 'DC',  '1X',                'free', 'won',  1.50, 2);
  perform t.mk(103, 'OU',  'Plus de 2,5 buts',  'free', 'lost', 1.80, 1);
  perform t.mk(103, 'BTTS','Les deux équipes marquent : Oui', 'free', 'void', 2.00, 1);
  perform t.mk(100, '1X2', 'Victoire domicile', 'free', 'won',  null, null);   -- ni cote ni mise : hors ROI
  perform t.mk(101, '1X2', 'Match nul',         'free', 'pending', 3.00, 1);   -- publié mais non soldé : ignoré
  insert into public.predictions (fixture_id, market, pick, justification, source) values (102, '1X2', 'Match nul', 'brouillon', 'bot'); -- proposé : ignoré
  perform t.ok('stats: gagnés/perdus/annulés/soldés',
    (select (won, lost, void, settled) = (3, 1, 1, 5) from public.performance_overall));
  perform t.ok('stats: taux de réussite = 3 / (3+1) = 0,75 (annulés exclus)', (select win_rate from public.performance_overall) = 0.75);
  perform t.ok('stats: mises = 4 (annulé et sans-cote exclus)', (select staked from public.performance_overall) = 4);
  perform t.ok('stats: profit = +1', (select profit from public.performance_overall) = 1);
  perform t.ok('stats: ROI = 25 %', (select roi from public.performance_overall) = 0.25);
  perform t.ok('stats: par championnat (A : 3 gagnés / 3 soldés)',
    (select (won, settled) = (3, 3) from public.performance_by_league where league_name = 'Ligue A'));
  perform t.ok('stats: par championnat (B : 0 gagné / 1 perdu)',
    (select (won, lost) = (0, 1) from public.performance_by_league where league_name = 'Ligue B'));
  perform t.ok('stats: par type de pari (1X2 : 2 gagnés)', (select won from public.performance_by_market where market = '1X2') = 2);
end $$;

-- ═════════ 3. Visiteur anonyme ═════════
do $$
declare
  n_free bigint; n_vip_pub bigint;
begin
  perform t.mk(102, '1X2', 'Victoire domicile', 'vip', 'pending', 2.5, 2);        -- VIP publié, en cours
  insert into public.analyses (fixture_id, probabilities, tier) values (100, '{"home":0.5}', 'free'), (101, '{"home":0.4}', 'vip');
  select count(*) into n_free from public.predictions where published and review = 'validated' and tier = 'free';
  select count(*) into n_vip_pub from public.predictions where published and review = 'validated' and tier = 'vip';
  perform t.ok('prérequis: il existe des pronostics gratuits et VIP publiés', n_free > 0 and n_vip_pub > 0);

  perform t.become(null);
  perform t.ok('anon: voit exactement les pronostics gratuits publiés', (select count(*) from public.predictions) = n_free);
  perform t.ok('anon: ne voit AUCUN pronostic VIP', (select count(*) from public.predictions where tier = 'vip') = 0);
  perform t.ok('anon: ne voit aucun brouillon', (select count(*) from public.predictions where review <> 'validated') = 0);
  perform t.ok('anon: lit les matchs', (select count(*) from public.fixtures) = 4);
  perform t.ok('anon: lit les championnats et équipes', (select count(*) from public.leagues) = 2 and (select count(*) from public.teams) = 4);
  perform t.ok('anon: analyse gratuite visible, analyse VIP invisible', (select count(*) from public.analyses) = 1);
  perform t.ok('anon: plans actifs lisibles', (select count(*) from public.subscription_plans) = 2);
  perform t.ok('anon: lit les stats publiques', (select settled from public.performance_overall) = 5);
  perform t.ok('anon: vip_teasers montre la sélection VIP', (select count(*) from public.vip_teasers) = n_vip_pub);
  perform t.throws('anon: profiles interdit', 'select * from public.profiles', '42501');
  perform t.throws('anon: subscriptions interdit', 'select * from public.subscriptions', '42501');
  perform t.throws('anon: scan_runs interdit', 'select * from public.scan_runs', '42501');
  perform t.throws('anon: prediction_events interdit', 'select * from public.prediction_events', '42501');
  perform t.throws('anon: performance_base (interne) interdit', 'select * from public.performance_base', '42501');
  perform t.throws('anon: insertion de pronostic interdite',
    $q$insert into public.predictions (market, pick, justification, source) values ('1X2','Match nul','x','admin')$q$, '42501');
  perform t.throws('anon: RPC admin_settle_prediction interdite',
    $q$select public.admin_settle_prediction(gen_random_uuid())$q$, '42501');
  perform t.throws('anon: écriture de matchs interdite',
    $q$insert into public.leagues (id, name) values (99, 'pirate')$q$, '42501');
  perform t.back();
  perform t.ok('vip_teasers: n''expose ni pari, ni cote, ni justification',
    (select count(*) from information_schema.columns where table_schema = 'public' and table_name = 'vip_teasers'
        and column_name in ('pick', 'odds', 'stake', 'justification', 'probability')) = 0);
end $$;

-- ═════════ 4. Utilisateur connecté (plan gratuit) ═════════
do $$
declare
  U uuid := 'b0000000-0000-0000-0000-000000000001';
  n_free bigint;
begin
  select count(*) into n_free from public.predictions where published and review = 'validated' and tier = 'free';
  perform t.become(U);
  perform t.ok('user: is_vip() = faux', not public.is_vip());
  perform t.ok('user: is_admin() = faux', not public.is_admin());
  perform t.ok('user: voit les pronostics gratuits publiés uniquement', (select count(*) from public.predictions) = n_free);
  perform t.ok('user: aucun VIP', (select count(*) from public.predictions where tier = 'vip') = 0);
  perform t.ok('user: analyse VIP invisible', (select count(*) from public.analyses) = 1);
  perform t.ok('user: ne voit que son profil', (select count(*) from public.profiles) = 1);
  perform t.ok('user: ne voit que son abonnement', (select count(*) from public.subscriptions) = 1);
  perform t.ok('user: aucun historique de pronostics visible', (select count(*) from public.prediction_events) = 0);
  perform t.ok('user: aucun scan visible', (select count(*) from public.scan_runs) = 0);
  perform t.ok('user: peut modifier son nom', t.affected($q$update public.profiles set display_name = 'Moi' where id = 'b0000000-0000-0000-0000-000000000001'$q$) = 1);
  perform t.ok('user: ne peut pas modifier le profil d''un autre', t.affected($q$update public.profiles set display_name = 'Pirate' where id <> 'b0000000-0000-0000-0000-000000000001'$q$) = 0);
  perform t.throws('user: ne peut PAS se donner le rôle admin', $q$update public.profiles set role = 'admin' where id = 'b0000000-0000-0000-0000-000000000001'$q$, '42501');
  perform t.throws('user: ne peut pas créer de profil', $q$insert into public.profiles (id, role) values (gen_random_uuid(), 'admin')$q$, '42501');
  perform t.throws('user: ne peut PAS s''accorder le VIP (update)', $q$update public.subscriptions set plan_id = 'vip' where user_id = 'b0000000-0000-0000-0000-000000000001'$q$, '42501');
  perform t.throws('user: ne peut PAS s''accorder le VIP (insert)', $q$insert into public.subscriptions (user_id, plan_id, status) values (gen_random_uuid(), 'vip', 'active')$q$, '42501');
  perform t.throws('user: insertion de pronostic refusée par RLS',
    $q$insert into public.predictions (market, pick, justification, source) values ('1X2','Match nul','x','admin')$q$, '42501');
  perform t.ok('user: modification de pronostic sans effet', t.affected($q$update public.predictions set justification = 'hack'$q$) = 0);
  perform t.ok('user: suppression de pronostic sans effet', t.affected($q$delete from public.predictions$q$) = 0);
  perform t.throws('user: RPC admin_settle_prediction refusée', $q$select public.admin_settle_prediction(gen_random_uuid())$q$, '42501');
  perform t.throws('user: RPC admin_set_subscription refusée (auto-attribution VIP)',
    $q$select public.admin_set_subscription('b0000000-0000-0000-0000-000000000001', 'vip')$q$, '42501');
  perform t.back();
  perform t.ok('user: son abonnement est resté gratuit', (select plan_id from public.subscriptions where user_id = U) = 'free');
  perform t.ok('user: son rôle est resté « user »', (select role from public.profiles where id = U) = 'user');
end $$;

-- ═════════ 5. Abonnés VIP ═════════
do $$
declare
  V uuid := 'c0000000-0000-0000-0000-000000000001';
  X uuid := 'd0000000-0000-0000-0000-000000000001';
  Y uuid := 'e0000000-0000-0000-0000-000000000001';
  n_pub bigint; n_free bigint;
begin
  select count(*) into n_pub from public.predictions where published and review = 'validated';
  select count(*) into n_free from public.predictions where published and review = 'validated' and tier = 'free';
  perform t.become(V);
  perform t.ok('vip: is_vip() = vrai', public.is_vip());
  perform t.ok('vip: is_admin() = faux', not public.is_admin());
  perform t.ok('vip: voit gratuits + VIP publiés', (select count(*) from public.predictions) = n_pub);
  perform t.ok('vip: voit l''analyse VIP', (select count(*) from public.analyses) = 2);
  perform t.ok('vip: ne voit aucun brouillon', (select count(*) from public.predictions where review <> 'validated') = 0);
  perform t.ok('vip: ne peut pas modifier un pronostic', t.affected($q$update public.predictions set justification = 'hack'$q$) = 0);
  perform t.back();

  perform t.become(X);
  perform t.ok('vip expiré: is_vip() = faux', not public.is_vip());
  perform t.ok('vip expiré: ne voit que le gratuit', (select count(*) from public.predictions) = n_free);
  perform t.back();
  perform t.become(Y);
  perform t.ok('vip annulé: is_vip() = faux', not public.is_vip());
  perform t.ok('vip annulé: ne voit que le gratuit', (select count(*) from public.predictions) = n_free);
  perform t.back();
end $$;

-- ═════════ 6. Administrateur : accès, workflow et audit ═════════
do $$
declare
  A uuid := 'a0000000-0000-0000-0000-000000000001';
  p uuid; q uuid; d uuid; r record; n_total bigint; v_res public.pick_result;
begin
  select count(*) into n_total from public.predictions;
  perform t.become(A);
  perform t.ok('admin: is_admin() = vrai et is_vip() = vrai', public.is_admin() and public.is_vip());
  perform t.ok('admin: voit tous les pronostics (brouillons inclus)', (select count(*) from public.predictions) = n_total);
  perform t.ok('admin: voit tous les profils et abonnements', (select count(*) from public.profiles) = 6 and (select count(*) from public.subscriptions) = 6);
  perform t.ok('admin: voit les scans', (select count(*) from public.scan_runs) >= 0);

  -- Création : même en demandant « publié + validé », le pronostic naît proposé.
  insert into public.predictions (fixture_id, market, pick, justification, tier, source, review, published, result)
    values (101, '1X2', 'Victoire domicile', '', 'free', 'admin', 'validated', true, 'won') returning id into p;
  perform t.ok('workflow: naît proposé / non publié / non soldé même si on force',
    (select (review, published, result) = ('proposed', false, 'pending') from public.predictions where id = p));
  perform t.ok('workflow: created_by = l''admin connecté', (select created_by from public.predictions where id = p) = A);

  perform t.throws('workflow: valider sans justification refusé', format($q$update public.predictions set review = 'validated' where id = %L$q$, p), '23514');
  perform t.throws('workflow: publier un pronostic non validé refusé', format($q$update public.predictions set published = true where id = %L$q$, p), '23514');
  perform t.throws('workflow: solder un pronostic non publié refusé', format($q$update public.predictions set result = 'won' where id = %L$q$, p), '23514');

  update public.predictions set justification = 'Analyse statistique de test.' where id = p;
  update public.predictions set review = 'validated' where id = p;
  perform t.ok('workflow: validation enregistre reviewed_by / reviewed_at',
    (select reviewed_by = A and reviewed_at is not null from public.predictions where id = p));
  update public.predictions set published = true where id = p;
  perform t.ok('workflow: publication enregistre published_at', (select published_at is not null from public.predictions where id = p));

  perform t.back(); perform t.become(null);
  perform t.ok('anon voit désormais le pronostic publié', (select count(*) from public.predictions where id = p) = 1);
  perform t.back(); perform t.become(A);

  -- Modification d'un pronostic publié => dépublié + à revalider.
  update public.predictions set odds = 1.95 where id = p;
  perform t.ok('workflow: modifier un publié le dépublie et le remet « proposé »',
    (select (review, published) = ('proposed', false) from public.predictions where id = p));
  perform t.back(); perform t.become(null);
  perform t.ok('anon ne le voit plus', (select count(*) from public.predictions where id = p) = 0);
  perform t.back(); perform t.become(A);

  -- Changement de catégorie : autorisé, ne dépublie pas, journalisé.
  update public.predictions set review = 'validated' where id = p;
  update public.predictions set published = true where id = p;
  update public.predictions set tier = 'vip' where id = p;
  perform t.ok('workflow: changer Gratuit→VIP garde la publication', (select published and tier = 'vip' from public.predictions where id = p));

  -- Règlement et protection de l'historique.
  update public.predictions set result = 'lost' where id = p;
  perform t.ok('workflow: règlement enregistre settled_at', (select settled_at is not null from public.predictions where id = p));
  perform t.throws('workflow: contenu d''un pronostic soldé non modifiable', format($q$update public.predictions set pick = 'Match nul' where id = %L$q$, p), '23514');
  perform t.throws('workflow: champ source immuable', format($q$update public.predictions set source = 'bot' where id = %L$q$, p), '23514');
  perform t.throws('workflow: fixture_id immuable', format($q$update public.predictions set fixture_id = 100 where id = %L$q$, p), '23514');
  perform t.ok('workflow: un pronostic publié/soldé ne peut pas être supprimé', t.affected(format($q$delete from public.predictions where id = %L$q$, p)) = 0);

  -- Refus puis réouverture.
  insert into public.predictions (fixture_id, market, pick, justification, source) values (102, 'DC', '1X', 'à refuser', 'admin') returning id into d;
  update public.predictions set review = 'refused' where id = d;
  perform t.ok('workflow: refusé reste non publié', (select review = 'refused' and not published from public.predictions where id = d));
  update public.predictions set review = 'proposed' where id = d;
  perform t.ok('workflow: remise en attente possible', (select review = 'proposed' from public.predictions where id = d));
  perform t.ok('workflow: un brouillon peut être supprimé', t.affected(format($q$delete from public.predictions where id = %L$q$, d)) = 1);

  -- Règlement automatique côté base à partir du score (fixture 100 : 2-1, terminé).
  perform t.back();
  q := t.mk(100, '1X2', 'Match nul', 'free', 'pending', null, null);   -- enregistré avant le match (t.mk décale le coup d'envoi)
  perform t.become('a0000000-0000-0000-0000-000000000001');
  v_res := public.admin_settle_prediction(q);
  perform t.ok('RPC: règlement auto « Match nul » sur 2-1 = perdu', v_res = 'lost' and (select result from public.predictions where id = q) = 'lost');
  insert into public.predictions (fixture_id, market, pick, justification, source) values (101, '1X2', 'Match nul', 'test', 'admin') returning id into d;
  update public.predictions set review = 'validated' where id = d;
  update public.predictions set published = true where id = d;
  perform t.throws('RPC: règlement refusé si le match n''est pas terminé', format($q$select public.admin_settle_prediction(%L)$q$, d), '22023');

  -- Journal d'audit.
  perform t.ok('audit: événements created/validated/published/edited/tier_changed/settled/refused/reopened journalisés',
    (select count(distinct action) from public.prediction_events where prediction_id in (p, q, d) or action in ('refused','reopened')) >= 8);
  perform t.ok('audit: l''acteur est tracé', (select count(*) from public.prediction_events where actor = A) > 0);

  -- Protections des droits : même l'admin ne se promeut pas via le client.
  perform t.throws('admin: changement de rôle via le client refusé (réservé SQL/service)',
    $q$update public.profiles set role = 'admin' where id = 'b0000000-0000-0000-0000-000000000001'$q$, '42501');
  perform t.throws('admin: pas d''écriture directe sur subscriptions', $q$update public.subscriptions set plan_id = 'vip'$q$, '42501');
  perform t.ok('admin: ne peut pas supprimer les matchs venant d''une API (source ≠ manual)', t.affected($q$delete from public.fixtures$q$) = 0);

  -- Attribution d'un abonnement via RPC contrôlée.
  perform public.admin_set_subscription('b0000000-0000-0000-0000-000000000001', 'vip', 'active', now() + interval '30 days');
  perform t.back();
  perform t.become('b0000000-0000-0000-0000-000000000001');
  perform t.ok('RPC: l''utilisateur devient VIP après attribution par l''admin', public.is_vip());
  perform t.back();
end $$;

-- ═════════ 7. Backend (service_role) : le bot ne peut jamais publier ═════════
do $$
declare p uuid;
begin
  perform t.become_service();
  insert into public.predictions (fixture_id, market, pick, justification, source, review, published, tier)
    values (102, 'OU', 'Plus de 2,5 buts', 'généré par le bot', 'bot', 'validated', true, 'free') returning id into p;
  perform t.ok('bot: une proposition forcée « publiée/validée » est ramenée à proposée/non publiée',
    (select (review, published) = ('proposed', false) from public.predictions where id = p));
  perform t.throws('bot: ne peut pas publier sans validation', format($q$update public.predictions set published = true where id = %L$q$, p), '23514');
  perform t.throws('bot: source inconnue refusée', $q$insert into public.predictions (market, pick, source) values ('1X2','Match nul','pirate')$q$, '23514');
  perform t.ok('bot: peut écrire matchs et analyses (service_role)', t.affected($q$insert into public.leagues (id, name) values (50, 'Ligue C')$q$) = 1);
  perform t.ok('bot: peut journaliser un scan', t.affected($q$insert into public.scan_runs (mode, detected, analyzed, discarded, proposals) values ('LIVE', 5, 5, 1, 1)$q$) = 1);
  perform t.back();
  perform t.throws('scan_runs: refuse un mode inconnu', $q$insert into public.scan_runs (mode) values ('FAKE')$q$, '23514');
end $$;

-- ═════════ 8. Intégrité du schéma ═════════
do $$
begin
  perform t.ok('schéma: RLS activée sur toutes les tables publiques',
    (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace
      where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity) = 0);
  perform t.ok('schéma: aucune fonction SECURITY DEFINER sans search_path fixé',
    (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname = 'public' and p.prosecdef and not coalesce(p.proconfig::text, '') like '%search_path=%') = 0);
  perform t.ok('schéma: anon ne peut exécuter aucune RPC admin',
    not has_function_privilege('anon', 'public.admin_settle_prediction(uuid)', 'execute')
    and not has_function_privilege('anon', 'public.admin_set_subscription(uuid,text,text,timestamptz)', 'execute'));
  perform t.ok('schéma: authenticated n''a pas UPDATE sur profiles.role', not has_column_privilege('authenticated', 'public.profiles', 'role', 'update'));
  perform t.ok('schéma: authenticated n''a aucun droit d''écriture sur subscriptions',
    not has_table_privilege('authenticated', 'public.subscriptions', 'insert') and not has_table_privilege('authenticated', 'public.subscriptions', 'update'));
  perform t.ok('schéma: anon n''a aucun droit sur profiles', not has_table_privilege('anon', 'public.profiles', 'select'));
end $$;

-- ═════════ Bilan ═════════
\echo
select case when ok then 'PASS' else 'FAIL' end as statut, name, case when ok then '' else detail end as detail from t.results order by n;
do $$
declare f int; total int;
begin
  select count(*) filter (where not ok), count(*) into f, total from t.results;
  raise notice '== % test(s), % échec(s) ==', total, f;
  if f > 0 then raise exception '% test(s) SQL en échec', f; end if;
end $$;
