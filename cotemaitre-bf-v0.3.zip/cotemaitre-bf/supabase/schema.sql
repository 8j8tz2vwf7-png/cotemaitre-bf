-- GÉNÉRÉ par scripts/build-schema.sh — NE PAS MODIFIER. Source de vérité : supabase/migrations/.
-- Pour un projet Supabase vierge, exécutez plutôt les migrations dans l'ordre (voir le README).

-- ═════ 20261105000100_baseline.sql ═════
-- MIGRATION 0100 — BASELINE : copie fidèle de l'ancien supabase/schema.sql (étape 1). Ne pas modifier : les correctifs sont dans les migrations suivantes.
-- Principe : le public ne lit QUE les pronostics publiés ; seuls les admins écrivent ; le VIP est filtré par la base.

create type market as enum ('1X2','DC','OU','BTTS');
create type tier as enum ('free','vip');
create type review_status as enum ('proposed','validated','refused');
create type pick_result as enum ('pending','won','lost','void');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  role text not null default 'user' check (role in ('user','vip','admin')),
  created_at timestamptz default now()
);

create table fixtures (
  id bigint primary key,                 -- id API-Football
  league_id int not null, league_name text not null,
  home_team text not null, away_team text not null,
  kickoff timestamptz not null, status text not null,
  home_goals int, away_goals int,
  raw jsonb, updated_at timestamptz default now()
);

create table analyses (
  fixture_id bigint primary key references fixtures(id) on delete cascade,
  probabilities jsonb not null,          -- sortie du moteur statistique
  features jsonb, model_version text, created_at timestamptz default now()
);

create table predictions (
  id uuid primary key default gen_random_uuid(),
  fixture_id bigint references fixtures(id),
  market market not null, pick text not null,
  odds numeric(6,2) check (odds is null or odds >= 1.01),
  stake numeric(6,2) check (stake is null or stake > 0),
  probability numeric(5,4),
  justification text not null default '',
  tier tier not null default 'free',
  review review_status not null default 'proposed',
  published boolean not null default false,
  result pick_result not null default 'pending',
  source text not null default 'bot',
  created_by uuid references auth.users, created_at timestamptz default now(), updated_at timestamptz default now(),
  -- Règle métier appliquée par la base : jamais de publication sans validation humaine.
  constraint published_requires_validation check (not published or review = 'validated')
);

create table scan_runs (
  id uuid primary key default gen_random_uuid(),
  started_at timestamptz default now(), mode text not null default 'LIVE',
  detected int, analyzed int, discarded int, proposals int, details jsonb
);

create table subscriptions (
  user_id uuid primary key references auth.users, status text not null, current_period_end timestamptz
);

-- ───────── Sécurité (RLS) ─────────
alter table profiles enable row level security;
alter table fixtures enable row level security;
alter table analyses enable row level security;
alter table predictions enable row level security;
alter table scan_runs enable row level security;
alter table subscriptions enable row level security;

create function is_admin() returns boolean language sql stable security definer as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;
create function is_vip() returns boolean language sql stable security definer as
$$ select exists (select 1 from profiles where id = auth.uid() and role in ('vip','admin')) $$;

create policy "profil lisible par son propriétaire" on profiles for select using (id = auth.uid() or is_admin());
create policy "fixtures publiques" on fixtures for select using (true);
create policy "analyses: admin" on analyses for select using (is_admin());
create policy "pronostics gratuits publiés" on predictions for select using (published and tier = 'free');
create policy "pronostics VIP publiés (abonnés)" on predictions for select using (published and tier = 'vip' and is_vip());
create policy "admin: tout sur pronostics" on predictions for all using (is_admin()) with check (is_admin());
create policy "admin: scans" on scan_runs for select using (is_admin());
create policy "abonnement: le sien" on subscriptions for select using (user_id = auth.uid() or is_admin());
-- Les écritures de fixtures / analyses / scan_runs se font avec la clé service_role depuis le backend UNIQUEMENT.

-- ═════ 20261105000200_domain_tables.sql ═════
-- MIGRATION 0200 — Tables métier manquantes + colonnes complémentaires.
-- Ne recrée AUCUNE table du baseline : seulement des ALTER sur l'existant et des tables nouvelles.
-- Les identifiants football (leagues, teams, fixtures) sont ceux d'API-Football, pour des upserts directs.

-- ───────── Abonnements : plans ─────────
create table public.subscription_plans (
  id text primary key check (id ~ '^[a-z][a-z0-9_]*$'),
  name text not null,
  description text,
  price_cents integer check (price_cents is null or price_cents >= 0),  -- NULL = tarif à définir
  currency text not null default 'XOF',
  billing_interval text check (billing_interval in ('month','year','one_time')),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
insert into public.subscription_plans (id, name, description) values
  ('free', 'Gratuit', 'Accès aux pronostics gratuits publiés.'),
  ('vip',  'VIP',     'Analyses approfondies et sélections Premium.');

-- ───────── Championnats, équipes ─────────
create table public.leagues (
  id bigint primary key,                       -- id API-Football
  name text not null,
  country text,
  logo_url text,
  season int,
  is_active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.teams (
  id bigint primary key,                       -- id API-Football
  name text not null,
  short_name text,
  country text,
  logo_url text,
  updated_at timestamptz not null default now()
);

-- ───────── Matchs : compléments (les colonnes texte du baseline sont conservées) ─────────
alter table public.fixtures alter column league_id type bigint;
alter table public.fixtures alter column updated_at set not null;
alter table public.fixtures
  add column season int,
  add column round text,
  add column venue text,
  add column status_short text,                -- code court API-Football : NS, FT, PST…
  add column home_team_id bigint references public.teams(id),
  add column away_team_id bigint references public.teams(id),
  add constraint fixtures_league_id_fkey foreign key (league_id) references public.leagues(id);

-- ───────── Classements, statistiques d'équipes, cotes ─────────
create table public.standings (
  league_id bigint not null references public.leagues(id) on delete cascade,
  season int not null,
  team_id bigint not null references public.teams(id) on delete cascade,
  rank int not null,
  played int not null default 0, wins int not null default 0, draws int not null default 0, losses int not null default 0,
  goals_for int not null default 0, goals_against int not null default 0, points int not null default 0,
  form text,                                    -- ex. 'WWDLW'
  updated_at timestamptz not null default now(),
  primary key (league_id, season, team_id)
);

create table public.team_stats (
  team_id bigint not null references public.teams(id) on delete cascade,
  league_id bigint not null references public.leagues(id) on delete cascade,
  season int not null,
  stats jsonb not null,                         -- forme, domicile/extérieur, moyennes de buts, tirs, absences…
  updated_at timestamptz not null default now(),
  primary key (team_id, league_id, season)
);

create table public.odds (
  id bigint generated always as identity primary key,
  fixture_id bigint not null references public.fixtures(id) on delete cascade,
  bookmaker text not null,
  market text not null,
  selection text not null,
  price numeric(7,2) not null check (price >= 1.01),
  fetched_at timestamptz not null default now(),
  unique (fixture_id, bookmaker, market, selection)
);

-- ───────── Profils ─────────
-- Rôles : 'user' | 'admin' uniquement. Le statut VIP vient de l'abonnement, jamais du rôle.
alter table public.profiles drop constraint profiles_role_check;
update public.profiles set role = 'user' where role not in ('user','admin');
alter table public.profiles
  add constraint profiles_role_check check (role in ('user','admin')),
  add column display_name text,
  add column avatar_url text,
  add column updated_at timestamptz not null default now();
alter table public.profiles alter column created_at set not null;

-- ───────── Analyses : niveau d'accès ─────────
alter table public.analyses
  add column tier public.tier not null default 'free',   -- 'vip' = analyse approfondie réservée aux abonnés
  add column updated_at timestamptz not null default now();
alter table public.analyses alter column created_at set not null;

-- ───────── Pronostics : traçabilité de la validation / publication / règlement ─────────
alter table public.predictions drop constraint predictions_created_by_fkey;
alter table public.predictions
  add constraint predictions_created_by_fkey foreign key (created_by) references auth.users(id) on delete set null,
  add column reviewed_by uuid references auth.users(id) on delete set null,
  add column reviewed_at timestamptz,
  add column published_at timestamptz,
  add column settled_at timestamptz,
  add constraint predictions_source_check check (source in ('bot','bot-live','admin','import')),
  add constraint predictions_probability_check check (probability is null or (probability >= 0 and probability <= 1));
alter table public.predictions alter column created_at set not null;
alter table public.predictions alter column updated_at set not null;

create table public.prediction_events (
  id bigint generated always as identity primary key,
  prediction_id uuid not null references public.predictions(id) on delete cascade,
  actor uuid references auth.users(id) on delete set null,   -- NULL = service_role / système
  action text not null check (action in ('created','edited','validated','refused','reopened','published','unpublished','tier_changed','settled')),
  detail jsonb,
  at timestamptz not null default now()
);

-- ───────── Abonnements : un plan, un statut contrôlé ─────────
alter table public.subscriptions drop constraint subscriptions_user_id_fkey;
alter table public.subscriptions
  add constraint subscriptions_user_id_fkey foreign key (user_id) references auth.users(id) on delete cascade,
  add column plan_id text not null default 'free' references public.subscription_plans(id),
  add column provider text not null default 'manual',          -- 'system' | 'manual' | passerelle de paiement
  add column provider_customer_id text,
  add column provider_subscription_id text,
  add column cancel_at_period_end boolean not null default false,
  add column started_at timestamptz not null default now(),
  add column updated_at timestamptz not null default now();
alter table public.subscriptions alter column status set default 'active';
alter table public.subscriptions
  add constraint subscriptions_status_check check (status in ('active','trialing','past_due','canceled','expired'));

-- ───────── Journal des scans : traçabilité ─────────
alter table public.scan_runs
  add column finished_at timestamptz,
  add column triggered_by uuid references auth.users(id) on delete set null,   -- NULL = planificateur
  add column error text,
  add constraint scan_runs_mode_check check (mode in ('LIVE','DEMO'));

-- ───────── Index ─────────
create index fixtures_kickoff_idx on public.fixtures (kickoff);
create index fixtures_league_kickoff_idx on public.fixtures (league_id, kickoff);
create index predictions_fixture_idx on public.predictions (fixture_id);
create index predictions_review_idx on public.predictions (review, created_at desc);
create index predictions_public_idx on public.predictions (tier, published_at desc) where published and review = 'validated';
create index prediction_events_prediction_idx on public.prediction_events (prediction_id, at desc);
create index subscriptions_plan_status_idx on public.subscriptions (plan_id, status);
create index odds_fixture_idx on public.odds (fixture_id);
create index standings_league_rank_idx on public.standings (league_id, season, rank);

-- ═════ 20261105000300_functions_triggers.sql ═════
-- MIGRATION 0300 — Fonctions de sécurité, triggers métier, RPC administrateur.
-- Toutes les fonctions SECURITY DEFINER fixent search_path = '' (anti-détournement) et qualifient leurs objets.

-- ───────── Aides d'autorisation (remplacent celles du baseline) ─────────
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin')
$$;

-- VIP = administrateur OU abonnement VIP actif/en essai non expiré.
create or replace function public.is_vip() returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_admin() or exists (
    select 1 from public.subscriptions s
    where s.user_id = (select auth.uid())
      and s.plan_id = 'vip'
      and s.status in ('active','trialing')
      and (s.current_period_end is null or s.current_period_end > now())
  )
$$;

-- ───────── Horodatage générique ─────────
create function public.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin
  new.updated_at := now();
  return new;
end $$;

create trigger touch_profiles       before update on public.profiles       for each row execute function public.touch_updated_at();
create trigger touch_fixtures       before update on public.fixtures       for each row execute function public.touch_updated_at();
create trigger touch_leagues        before update on public.leagues        for each row execute function public.touch_updated_at();
create trigger touch_teams          before update on public.teams          for each row execute function public.touch_updated_at();
create trigger touch_analyses       before update on public.analyses       for each row execute function public.touch_updated_at();
create trigger touch_team_stats     before update on public.team_stats     for each row execute function public.touch_updated_at();
create trigger touch_standings      before update on public.standings      for each row execute function public.touch_updated_at();
create trigger touch_subscriptions  before update on public.subscriptions  for each row execute function public.touch_updated_at();

-- ───────── Création automatique du profil + abonnement gratuit à l'inscription ─────────
-- Le rôle est TOUJOURS 'user' : on ne lit jamais raw_user_meta_data pour le rôle (modifiable par l'utilisateur).
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(nullif(btrim(new.raw_user_meta_data ->> 'display_name'), ''), split_part(coalesce(new.email, ''), '@', 1)))
  on conflict (id) do nothing;

  insert into public.subscriptions (user_id, plan_id, status, provider)
  values (new.id, 'free', 'active', 'system')
  on conflict (user_id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Rattrapage des comptes créés avant cette migration.
insert into public.profiles (id, display_name)
  select u.id, split_part(coalesce(u.email, ''), '@', 1) from auth.users u on conflict (id) do nothing;
insert into public.subscriptions (user_id, plan_id, status, provider)
  select u.id, 'free', 'active', 'system' from auth.users u on conflict (user_id) do nothing;

-- ───────── Workflow des pronostics, imposé par la base (même pour service_role) ─────────
create function public.predictions_workflow() returns trigger
language plpgsql set search_path = '' as $$
declare
  v_content_changed boolean;
begin
  if tg_op = 'INSERT' then
    -- Tout pronostic naît « proposé », non publié, non soldé : la publication est toujours un acte humain distinct.
    new.review := 'proposed';
    new.published := false;
    new.result := 'pending';
    new.reviewed_by := null; new.reviewed_at := null; new.published_at := null; new.settled_at := null;
    new.created_by := coalesce(new.created_by, (select auth.uid()));
    new.created_at := now();
    new.updated_at := now();
    return new;
  end if;

  if new.id <> old.id
     or new.fixture_id is distinct from old.fixture_id
     or new.source <> old.source
     or new.created_at <> old.created_at
     or new.created_by is distinct from old.created_by then
    raise exception 'Champs immuables : id, fixture_id, source, created_by, created_at' using errcode = '23514';
  end if;

  v_content_changed := (new.market, new.pick, new.odds, new.stake, new.probability, new.justification)
                       is distinct from
                       (old.market, old.pick, old.odds, old.stake, old.probability, old.justification);

  if v_content_changed then
    if old.result <> 'pending' then
      raise exception 'Pronostic soldé : contenu non modifiable' using errcode = '23514';
    end if;
    -- Modifier le contenu invalide la validation : il faut relire et revalider.
    if old.review = 'validated' then
      new.review := 'proposed';
      new.published := false;
    end if;
  end if;

  if new.review is distinct from old.review then
    if new.review = 'validated' then
      if btrim(new.justification) = '' then
        raise exception 'Justification obligatoire pour valider' using errcode = '23514';
      end if;
      new.reviewed_by := (select auth.uid());
      new.reviewed_at := now();
    else
      new.published := false;
    end if;
  end if;

  if new.published and not old.published then
    if new.review <> 'validated' then
      raise exception 'Seul un pronostic validé peut être publié' using errcode = '23514';
    end if;
    new.published_at := now();
  elsif not new.published and old.published then
    new.published_at := null;
  end if;

  if new.result is distinct from old.result then
    if new.result <> 'pending' then
      if not new.published then
        raise exception 'Seul un pronostic publié peut être soldé' using errcode = '23514';
      end if;
      new.settled_at := now();
    else
      new.settled_at := null;
    end if;
  end if;

  new.updated_at := now();
  return new;
end $$;

create trigger predictions_workflow_trg before insert or update on public.predictions
  for each row execute function public.predictions_workflow();

-- ───────── Journal d'audit des pronostics ─────────
create function public.predictions_log_event() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  v_actor uuid := (select auth.uid());
begin
  if tg_op = 'INSERT' then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, 'created', jsonb_build_object('source', new.source, 'market', new.market, 'pick', new.pick));
    return null;
  end if;

  if (new.market, new.pick, new.odds, new.stake, new.probability, new.justification)
     is distinct from (old.market, old.pick, old.odds, old.stake, old.probability, old.justification) then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, 'edited', jsonb_build_object('pick_before', old.pick, 'pick_after', new.pick, 'odds_before', old.odds, 'odds_after', new.odds));
  end if;
  if new.review is distinct from old.review then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor,
            case new.review when 'validated' then 'validated' when 'refused' then 'refused' else 'reopened' end,
            jsonb_build_object('from', old.review, 'to', new.review));
  end if;
  if new.published is distinct from old.published then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, case when new.published then 'published' else 'unpublished' end, jsonb_build_object('tier', new.tier));
  end if;
  if new.tier is distinct from old.tier then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, 'tier_changed', jsonb_build_object('from', old.tier, 'to', new.tier));
  end if;
  if new.result is distinct from old.result then
    insert into public.prediction_events (prediction_id, actor, action, detail)
    values (new.id, v_actor, 'settled', jsonb_build_object('from', old.result, 'to', new.result));
  end if;
  return null;
end $$;

create trigger predictions_log_trg after insert or update on public.predictions
  for each row execute function public.predictions_log_event();

-- ───────── Évaluation d'un pari à partir du score (miroir de src/lib/stats.ts → evaluatePick) ─────────
create function public.evaluate_pick(p_pick text, p_home_goals int, p_away_goals int) returns text
language sql immutable set search_path = '' as $$
  select case p_pick
    when 'Victoire domicile'    then case when p_home_goals >  p_away_goals then 'won' else 'lost' end
    when 'Match nul'            then case when p_home_goals =  p_away_goals then 'won' else 'lost' end
    when 'Victoire extérieure'  then case when p_away_goals >  p_home_goals then 'won' else 'lost' end
    when '1X'                   then case when p_home_goals >= p_away_goals then 'won' else 'lost' end
    when 'X2'                   then case when p_away_goals >= p_home_goals then 'won' else 'lost' end
    when '12'                   then case when p_home_goals <> p_away_goals then 'won' else 'lost' end
    when 'Plus de 1,5 buts'     then case when p_home_goals + p_away_goals >  1 then 'won' else 'lost' end
    when 'Moins de 1,5 buts'    then case when p_home_goals + p_away_goals <= 1 then 'won' else 'lost' end
    when 'Plus de 2,5 buts'     then case when p_home_goals + p_away_goals >  2 then 'won' else 'lost' end
    when 'Moins de 2,5 buts'    then case when p_home_goals + p_away_goals <= 2 then 'won' else 'lost' end
    when 'Plus de 3,5 buts'     then case when p_home_goals + p_away_goals >  3 then 'won' else 'lost' end
    when 'Moins de 3,5 buts'    then case when p_home_goals + p_away_goals <= 3 then 'won' else 'lost' end
    when 'Les deux équipes marquent : Oui' then case when p_home_goals > 0 and p_away_goals > 0 then 'won' else 'lost' end
    when 'Les deux équipes marquent : Non' then case when p_home_goals > 0 and p_away_goals > 0 then 'lost' else 'won' end
    else null
  end
$$;

-- ───────── RPC administrateur (contrôle du rôle fait EN BASE, pas seulement dans l'interface) ─────────
create function public.admin_settle_prediction(p_id uuid) returns public.pick_result
language plpgsql security definer set search_path = '' as $$
declare
  p public.predictions;
  f public.fixtures;
  r text;
begin
  if not public.is_admin() then
    raise exception 'Accès réservé aux administrateurs' using errcode = '42501';
  end if;
  select * into p from public.predictions where id = p_id;
  if not found then
    raise exception 'Pronostic introuvable' using errcode = 'P0002';
  end if;
  select * into f from public.fixtures where id = p.fixture_id;
  if not found or f.home_goals is null or f.away_goals is null
     or coalesce(f.status_short, f.status) not in ('FT','AET','PEN','finished') then
    raise exception 'Match non terminé ou score indisponible' using errcode = '22023';
  end if;
  r := public.evaluate_pick(p.pick, f.home_goals, f.away_goals);
  if r is null then
    raise exception 'Pari non évaluable automatiquement' using errcode = '22023';
  end if;
  update public.predictions set result = r::public.pick_result where id = p_id;
  return r::public.pick_result;
end $$;

create function public.admin_set_subscription(
  p_user uuid, p_plan text, p_status text default 'active', p_until timestamptz default null
) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then
    raise exception 'Accès réservé aux administrateurs' using errcode = '42501';
  end if;
  insert into public.subscriptions (user_id, plan_id, status, current_period_end, provider)
  values (p_user, p_plan, p_status, p_until, 'manual')
  on conflict (user_id) do update
    set plan_id = excluded.plan_id, status = excluded.status,
        current_period_end = excluded.current_period_end, provider = 'manual';
end $$;

-- ───────── Droits d'exécution : fermé par défaut, ouvert au strict nécessaire ─────────
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.is_admin(), public.is_vip() to anon, authenticated;
grant execute on function public.evaluate_pick(text, int, int) to anon, authenticated;
grant execute on function public.admin_settle_prediction(uuid) to authenticated;
grant execute on function public.admin_set_subscription(uuid, text, text, timestamptz) to authenticated;

-- ═════ 20261105000400_rls_policies.sql ═════
-- MIGRATION 0400 — Row Level Security + privilèges explicites (défense en profondeur).
-- Deux barrières indépendantes : (1) GRANT/REVOKE au niveau des tables, (2) politiques RLS par ligne.
-- service_role (clé serveur) contourne RLS par conception : elle ne doit JAMAIS quitter le backend.

-- ───────── Secure by default : les futures tables n'héritent plus des droits anon/authenticated ─────────
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;

-- ───────── Activer RLS sur les nouvelles tables (le baseline l'a fait pour les siennes) ─────────
alter table public.subscription_plans enable row level security;
alter table public.leagues            enable row level security;
alter table public.teams              enable row level security;
alter table public.standings          enable row level security;
alter table public.team_stats         enable row level security;
alter table public.odds               enable row level security;
alter table public.prediction_events  enable row level security;

-- ───────── Remplacer les politiques du baseline ─────────
drop policy "profil lisible par son propriétaire" on public.profiles;
drop policy "fixtures publiques"                  on public.fixtures;
drop policy "analyses: admin"                     on public.analyses;
drop policy "pronostics gratuits publiés"         on public.predictions;
drop policy "pronostics VIP publiés (abonnés)"    on public.predictions;
drop policy "admin: tout sur pronostics"          on public.predictions;
drop policy "admin: scans"                        on public.scan_runs;
drop policy "abonnement: le sien"                 on public.subscriptions;

-- ───────── Profils : chacun voit et édite le sien (nom, avatar). Le rôle n'est modifiable que côté serveur. ─────────
create policy "profil: lecture du sien ou admin" on public.profiles for select to authenticated
  using (id = (select auth.uid()) or (select public.is_admin()));
create policy "profil: modification du sien" on public.profiles for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));

-- ───────── Données football : lecture publique, écriture réservée au backend (service_role) ─────────
create policy "ligues: lecture publique"      on public.leagues     for select to anon, authenticated using (true);
create policy "équipes: lecture publique"     on public.teams       for select to anon, authenticated using (true);
create policy "matchs: lecture publique"      on public.fixtures    for select to anon, authenticated using (true);
create policy "classements: lecture publique" on public.standings   for select to anon, authenticated using (true);
create policy "stats équipes: lecture publique" on public.team_stats for select to anon, authenticated using (true);
create policy "cotes: lecture publique"       on public.odds        for select to anon, authenticated using (true);
create policy "plans: lecture des plans actifs" on public.subscription_plans for select to anon, authenticated using (is_active);

-- ───────── Analyses : gratuites pour tous, approfondies (tier = 'vip') pour les abonnés ─────────
create policy "analyses: gratuites ou VIP" on public.analyses for select to anon, authenticated
  using (tier = 'free' or (select public.is_vip()));

-- ───────── Pronostics ─────────
-- Public : uniquement ce qui est VALIDÉ et PUBLIÉ. VIP : en plus, abonnés VIP/admin. Admin : tout.
create policy "pronostics: gratuits publiés" on public.predictions for select to anon, authenticated
  using (published and review = 'validated' and tier = 'free');
create policy "pronostics: VIP publiés pour abonnés" on public.predictions for select to authenticated
  using (published and review = 'validated' and tier = 'vip' and (select public.is_vip()));
create policy "pronostics: admin lecture" on public.predictions for select to authenticated
  using ((select public.is_admin()));
create policy "pronostics: admin création" on public.predictions for insert to authenticated
  with check ((select public.is_admin()));
create policy "pronostics: admin modification" on public.predictions for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy "pronostics: admin suppression" on public.predictions for delete to authenticated
  using ((select public.is_admin()) and not published and result = 'pending');

-- ───────── Journaux : réservés aux administrateurs (écriture par triggers / service_role) ─────────
create policy "historique pronostics: admin" on public.prediction_events for select to authenticated
  using ((select public.is_admin()));
create policy "scans: admin" on public.scan_runs for select to authenticated
  using ((select public.is_admin()));

-- ───────── Abonnements : chacun voit le sien ; AUCUNE écriture client (webhook paiement = service_role, ou RPC admin) ─────────
create policy "abonnement: le sien ou admin" on public.subscriptions for select to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()));

-- ───────── Privilèges de table (couche 1) ─────────
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;

grant select on public.leagues, public.teams, public.fixtures, public.standings, public.team_stats,
                public.odds, public.subscription_plans, public.analyses to anon, authenticated;
grant select on public.predictions to anon, authenticated;
grant insert, update, delete on public.predictions to authenticated;          -- filtré par RLS : admin uniquement
grant select on public.prediction_events, public.scan_runs, public.subscriptions to authenticated;
grant select on public.profiles to authenticated;
grant update (display_name, avatar_url) on public.profiles to authenticated;  -- jamais « role »

-- ═════ 20261105000500_views_performance.sql ═════
-- MIGRATION 0500 — Vues publiques de performance (AGRÉGATS UNIQUEMENT, jamais de pronostic VIP en clair).
-- Les statistiques sont calculées sur les pronostics publiés, validés ET soldés : jamais sur du démo.
-- Ces vues s'exécutent avec les droits de leur propriétaire (comportement par défaut) : elles voient donc aussi
-- les pronostics VIP pour les agréger, mais n'exposent que des comptes et des ratios.
-- Le linter Supabase peut signaler « security definer view » : c'est voulu et limité à des agrégats.

create view public.performance_base as
  select
    p.id, p.tier, p.market, p.result, p.odds, p.stake, p.published_at,
    coalesce(f.league_name, 'Autre') as league_name
  from public.predictions p
  left join public.fixtures f on f.id = p.fixture_id
  where p.published and p.review = 'validated' and p.result <> 'pending';

-- Rendement théorique : uniquement sur les paris avec cote ET mise renseignées, hors annulés.
create view public.performance_overall as
  select
    count(*) filter (where result = 'won')::int  as won,
    count(*) filter (where result = 'lost')::int as lost,
    count(*) filter (where result = 'void')::int as void,
    count(*)::int as settled,
    case when count(*) filter (where result in ('won','lost')) > 0
         then round(count(*) filter (where result = 'won')::numeric / count(*) filter (where result in ('won','lost')), 4) end as win_rate,
    coalesce(sum(stake) filter (where odds is not null and stake is not null and result <> 'void'), 0) as staked,
    coalesce(sum(case when result = 'won' then stake * (odds - 1) when result = 'lost' then -stake end)
             filter (where odds is not null and stake is not null and result <> 'void'), 0) as profit,
    case when coalesce(sum(stake) filter (where odds is not null and stake is not null and result <> 'void'), 0) > 0
         then round(sum(case when result = 'won' then stake * (odds - 1) when result = 'lost' then -stake end)
                    filter (where odds is not null and stake is not null and result <> 'void')
                    / sum(stake) filter (where odds is not null and stake is not null and result <> 'void'), 4) end as roi
  from public.performance_base;

create view public.performance_by_league as
  select league_name,
         count(*) filter (where result = 'won')::int as won,
         count(*) filter (where result = 'lost')::int as lost,
         count(*)::int as settled,
         case when count(*) filter (where result in ('won','lost')) > 0
              then round(count(*) filter (where result = 'won')::numeric / count(*) filter (where result in ('won','lost')), 4) end as win_rate
  from public.performance_base group by league_name;

create view public.performance_by_market as
  select market,
         count(*) filter (where result = 'won')::int as won,
         count(*) filter (where result = 'lost')::int as lost,
         count(*)::int as settled,
         case when count(*) filter (where result in ('won','lost')) > 0
              then round(count(*) filter (where result = 'won')::numeric / count(*) filter (where result in ('won','lost')), 4) end as win_rate
  from public.performance_base group by market;

-- Aperçu VIP verrouillé : existence et résultat des sélections VIP, SANS le pari, la cote ni la justification.
create view public.vip_teasers as
  select p.id, p.market, p.result, p.published_at,
         f.home_team, f.away_team, f.league_name, f.kickoff
  from public.predictions p
  left join public.fixtures f on f.id = p.fixture_id
  where p.published and p.review = 'validated' and p.tier = 'vip';

revoke all on public.performance_base from anon, authenticated;   -- interne
grant select on public.performance_overall, public.performance_by_league, public.performance_by_market, public.vip_teasers
  to anon, authenticated;

-- ═════ 20261105000600_sports_data_admin.sql ═════
-- MIGRATION 0600 — Données sportives administrables, cohérence, règle « avant le match », validation humaine stricte.
-- Corrige l'audit de l'étape 3 :
--   C1  l'administrateur ne pouvait écrire ni championnats, ni équipes, ni matchs, ni statistiques.
--   Faille : un `service_role` (le bot) pouvait valider PUIS publier. La validation et la publication exigent
--           désormais un administrateur connecté.
--   Intégrité : statuts, scores, doublons, noms dénormalisés, clés étrangères sans index.
--   Règle métier : un pronostic est enregistré et publié AVANT le coup d'envoi, puis figé.

-- ═════════ 1. Origine des données et identifiants sans collision avec une API ═════════
-- Les lignes saisies à la main reçoivent un identifiant ≥ 9 000 000 000 000 ; les identifiants des API
-- (API-Football : < 10 millions) ne peuvent donc jamais les écraser.
create sequence if not exists public.manual_id_seq start 9000000000000 minvalue 9000000000000;
grant usage on sequence public.manual_id_seq to authenticated;

alter table public.leagues  add column if not exists source text not null default 'manual' check (source in ('manual', 'api-football'));
alter table public.teams    add column if not exists source text not null default 'manual' check (source in ('manual', 'api-football'));
alter table public.fixtures add column if not exists source text not null default 'manual' check (source in ('manual', 'api-football'));

alter table public.leagues  alter column id set default nextval('public.manual_id_seq');
alter table public.teams    alter column id set default nextval('public.manual_id_seq');
alter table public.fixtures alter column id set default nextval('public.manual_id_seq');

-- ═════════ 2. Contraintes d'intégrité ═════════
alter table public.fixtures alter column status set default 'scheduled';
alter table public.fixtures alter column kickoff set not null;
alter table public.fixtures
  add constraint fixtures_status_check check (status in ('scheduled', 'live', 'finished', 'postponed', 'cancelled')),
  add constraint fixtures_distinct_teams check (home_team_id is null or away_team_id is null or home_team_id <> away_team_id),
  add constraint fixtures_goals_check check ((home_goals is null or home_goals >= 0) and (away_goals is null or away_goals >= 0)),
  add constraint fixtures_finished_needs_score check (status <> 'finished' or (home_goals is not null and away_goals is not null)),
  add constraint fixtures_score_only_if_played check (status in ('live', 'finished') or (home_goals is null and away_goals is null)),
  add constraint fixtures_manual_needs_teams check (source <> 'manual' or (home_team_id is not null and away_team_id is not null));

create unique index if not exists leagues_name_country_uq on public.leagues (lower(name), coalesce(country, ''));
create unique index if not exists teams_name_country_uq on public.teams (lower(name), coalesce(country, ''));
create unique index if not exists fixtures_unique_match on public.fixtures (league_id, home_team_id, away_team_id, kickoff)
  where home_team_id is not null and away_team_id is not null;

-- Contrat des statistiques d'équipe (voir docs/DATA_CONTRACT.md). Absent = « donnée non renseignée », jamais inventée.
create function public.team_stats_valid(s jsonb) returns boolean
language plpgsql immutable set search_path = '' as $$
declare
  side text; k text; v jsonb; el jsonb;
begin
  if s is null or jsonb_typeof(s) <> 'object' then return false; end if;
  if s ? 'form' and (jsonb_typeof(s -> 'form') <> 'string' or (s ->> 'form') !~ '^[WDL]{0,10}$') then return false; end if;
  foreach side in array array['home', 'away'] loop
    if s ? side then
      v := s -> side;
      if jsonb_typeof(v) <> 'object' then return false; end if;
      foreach k in array array['played', 'wins', 'draws', 'losses', 'gf', 'ga'] loop
        if not (v ? k) or jsonb_typeof(v -> k) <> 'number' or (v ->> k) !~ '^\d{1,4}$' then return false; end if;
      end loop;
      if (v ->> 'wins')::int + (v ->> 'draws')::int + (v ->> 'losses')::int > (v ->> 'played')::int then return false; end if;
    end if;
  end loop;
  foreach k in array array['shots_per_game', 'shots_on_target_per_game', 'possession_pct', 'clean_sheet_pct', 'failed_to_score_pct'] loop
    if s ? k and (jsonb_typeof(s -> k) <> 'number' or (s ->> k)::numeric < 0 or (s ->> k)::numeric > 100) then return false; end if;
  end loop;
  if s ? 'absences' then
    if jsonb_typeof(s -> 'absences') <> 'array' then return false; end if;
    for el in select * from jsonb_array_elements(s -> 'absences') loop
      if jsonb_typeof(el) <> 'object' or coalesce(btrim(el ->> 'player'), '') = ''
         or (el ->> 'reason') not in ('Blessure', 'Suspension', 'Incertain')
         or (el ? 'verified' and jsonb_typeof(el -> 'verified') <> 'boolean') then return false; end if;
    end loop;
  end if;
  return true;
end $$;

alter table public.team_stats
  add constraint team_stats_valid_check check (public.team_stats_valid(stats));

-- ═════════ 3. Cohérence des noms affichés (dénormalisés dans fixtures) ═════════
create function public.fixtures_sync() returns trigger
language plpgsql set search_path = '' as $$
begin
  if new.home_team_id is not null then select name into new.home_team from public.teams where id = new.home_team_id; end if;
  if new.away_team_id is not null then select name into new.away_team from public.teams where id = new.away_team_id; end if;
  if new.league_id is not null then select name into new.league_name from public.leagues where id = new.league_id; end if;
  -- Saisie manuelle : le code court est déduit du statut (les lignes API gardent le code de l'API).
  if new.source = 'manual' then
    new.status_short := case new.status
      when 'scheduled' then 'NS' when 'live' then 'LIVE' when 'finished' then 'FT'
      when 'postponed' then 'PST' when 'cancelled' then 'CANC' end;
  end if;
  return new;
end $$;
create trigger fixtures_sync_trg before insert or update on public.fixtures
  for each row execute function public.fixtures_sync();

create function public.propagate_names() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_table_name = 'teams' then
    update public.fixtures set home_team = new.name where home_team_id = new.id and home_team is distinct from new.name;
    update public.fixtures set away_team = new.name where away_team_id = new.id and away_team is distinct from new.name;
  else
    update public.fixtures set league_name = new.name where league_id = new.id and league_name is distinct from new.name;
  end if;
  return new;
end $$;
create trigger teams_propagate_name after update of name on public.teams
  for each row execute function public.propagate_names();
create trigger leagues_propagate_name after update of name on public.leagues
  for each row execute function public.propagate_names();

-- Un score ne peut pas changer sous des pronostics déjà soldés (sinon résultat affiché ≠ résultat enregistré).
-- Pour corriger un score : remettre d'abord les pronostics concernés « en attente », corriger, puis les resolder.
create function public.fixtures_lock_scored() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if (new.status, new.home_goals, new.away_goals) is distinct from (old.status, old.home_goals, old.away_goals)
     and exists (select 1 from public.predictions p where p.fixture_id = old.id and p.result <> 'pending') then
    raise exception 'Des pronostics sont déjà soldés sur ce match : remettez-les en attente avant de corriger le score.'
      using errcode = '23514';
  end if;
  return new;
end $$;
create trigger fixtures_lock_scored_trg before update on public.fixtures
  for each row execute function public.fixtures_lock_scored();

-- ═════════ 4. Index des clés étrangères manquants (audit) ═════════
create index if not exists fixtures_home_team_idx on public.fixtures (home_team_id);
create index if not exists fixtures_away_team_idx on public.fixtures (away_team_id);
create index if not exists predictions_created_by_idx on public.predictions (created_by);
create index if not exists predictions_reviewed_by_idx on public.predictions (reviewed_by);
create index if not exists scan_runs_triggered_by_idx on public.scan_runs (triggered_by);
create index if not exists standings_team_idx on public.standings (team_id);
create index if not exists team_stats_league_idx on public.team_stats (league_id);
create index if not exists prediction_events_actor_idx on public.prediction_events (actor);

-- ═════════ 5. Écriture administrateur des données sportives (RLS + privilèges) ═════════
-- Un administrateur ne touche QUE les lignes saisies à la main (source = 'manual', id ≥ 9e12).
-- Les lignes venant d'une API sont réservées au backend : une synchronisation les écraserait de toute façon.
grant insert, update, delete on public.leagues, public.teams, public.fixtures, public.team_stats to authenticated;

create policy leagues_admin_insert on public.leagues for insert to authenticated
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy leagues_admin_update on public.leagues for update to authenticated
  using ((select public.is_admin()) and source = 'manual')
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy leagues_admin_delete on public.leagues for delete to authenticated
  using ((select public.is_admin()) and source = 'manual');

create policy teams_admin_insert on public.teams for insert to authenticated
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy teams_admin_update on public.teams for update to authenticated
  using ((select public.is_admin()) and source = 'manual')
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy teams_admin_delete on public.teams for delete to authenticated
  using ((select public.is_admin()) and source = 'manual');

create policy fixtures_admin_insert on public.fixtures for insert to authenticated
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy fixtures_admin_update on public.fixtures for update to authenticated
  using ((select public.is_admin()) and source = 'manual')
  with check ((select public.is_admin()) and source = 'manual' and id >= 9000000000000);
create policy fixtures_admin_delete on public.fixtures for delete to authenticated
  using ((select public.is_admin()) and source = 'manual');

create policy team_stats_admin_write on public.team_stats for all to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));

-- ═════════ 6. Workflow des pronostics : validation et publication = acte d'un ADMINISTRATEUR CONNECTÉ ═════════
-- Remplace la fonction de 0300 (même logique, plus la garde « humain »). Seuls passent :
--   • un utilisateur dont le profil est admin (is_admin()),
--   • l'éditeur SQL du projet (rôle postgres / supabase_admin), pour la maintenance.
-- Le rôle service_role (backend, bot, Edge Functions) est REFUSÉ pour valider et publier.
create or replace function public.predictions_workflow() returns trigger
language plpgsql set search_path = '' as $$
declare
  v_content_changed boolean;
  v_human boolean := public.is_admin() or current_user in ('postgres', 'supabase_admin');
begin
  if tg_op = 'INSERT' then
    -- Tout pronostic naît « proposé », non publié, non soldé : la publication est toujours un acte humain distinct.
    new.review := 'proposed';
    new.published := false;
    new.result := 'pending';
    new.reviewed_by := null; new.reviewed_at := null; new.published_at := null; new.settled_at := null;
    new.created_by := coalesce(new.created_by, (select auth.uid()));
    new.created_at := now();
    new.updated_at := now();
    return new;
  end if;

  if new.id <> old.id
     or new.fixture_id is distinct from old.fixture_id
     or new.source <> old.source
     or new.created_at <> old.created_at
     or new.created_by is distinct from old.created_by then
    raise exception 'Champs immuables : id, fixture_id, source, created_by, created_at' using errcode = '23514';
  end if;

  v_content_changed := (new.market, new.pick, new.odds, new.stake, new.probability, new.justification)
                       is distinct from
                       (old.market, old.pick, old.odds, old.stake, old.probability, old.justification);

  if v_content_changed then
    if old.result <> 'pending' then
      raise exception 'Pronostic soldé : contenu non modifiable' using errcode = '23514';
    end if;
    -- Modifier le contenu invalide la validation : il faut relire et revalider.
    if old.review = 'validated' then
      new.review := 'proposed';
      new.published := false;
    end if;
  end if;

  if new.review is distinct from old.review then
    if new.review = 'validated' then
      if btrim(new.justification) = '' then
        raise exception 'Justification obligatoire pour valider' using errcode = '23514';
      end if;
      if not v_human then
        raise exception 'La validation est réservée à un administrateur connecté' using errcode = '42501';
      end if;
      new.reviewed_by := (select auth.uid());
      new.reviewed_at := now();
    else
      new.published := false;
    end if;
  end if;

  if new.published and not old.published then
    if new.review <> 'validated' then
      raise exception 'Seul un pronostic validé peut être publié' using errcode = '23514';
    end if;
    if not v_human then
      raise exception 'La publication est réservée à un administrateur connecté' using errcode = '42501';
    end if;
    new.published_at := now();
  elsif not new.published and old.published then
    new.published_at := null;
  end if;

  if new.result is distinct from old.result then
    if new.result <> 'pending' then
      if not new.published then
        raise exception 'Seul un pronostic publié peut être soldé' using errcode = '23514';
      end if;
      new.settled_at := now();
    else
      new.settled_at := null;
    end if;
  end if;

  new.updated_at := now();
  return new;
end $$;

-- ═════════ 7. Règle « avant le match » ═════════
-- Un pronostic est enregistré et publié AVANT le coup d'envoi (date vérifiable : published_at < kickoff),
-- puis son contenu est figé. Seul le résultat peut ensuite être renseigné.
create function public.predictions_timing() returns trigger
language plpgsql set search_path = '' as $$
declare
  v_kickoff timestamptz;
begin
  if new.fixture_id is not null then
    select kickoff into v_kickoff from public.fixtures where id = new.fixture_id;
  end if;

  if tg_op = 'INSERT' then
    if v_kickoff is not null and v_kickoff <= now() then
      raise exception 'Le match a déjà commencé : un pronostic doit être enregistré avant le coup d''envoi' using errcode = '23514';
    end if;
    return new;
  end if;

  if new.published and not old.published then
    if new.fixture_id is null then
      raise exception 'Un pronostic publié doit être rattaché à un match' using errcode = '23514';
    end if;
    if v_kickoff <= now() then
      raise exception 'Publication impossible : le match a déjà commencé' using errcode = '23514';
    end if;
  end if;

  if v_kickoff is not null and v_kickoff <= now()
     and (new.market, new.pick, new.odds, new.stake, new.probability, new.justification, new.tier)
         is distinct from
         (old.market, old.pick, old.odds, old.stake, old.probability, old.justification, old.tier) then
    raise exception 'Le match a commencé : le pronostic est figé' using errcode = '23514';
  end if;
  return new;
end $$;
-- Nom choisi pour s'exécuter AVANT predictions_workflow_trg (ordre alphabétique des triggers).
create trigger predictions_timing_trg before insert or update on public.predictions
  for each row execute function public.predictions_timing();

revoke all on function public.team_stats_valid(jsonb), public.fixtures_sync(), public.propagate_names(),
  public.fixtures_lock_scored(), public.predictions_timing() from public, anon, authenticated;
grant execute on function public.team_stats_valid(jsonb) to anon, authenticated, service_role;  -- utilisée par une contrainte CHECK
