# COTEMAÎTRE BF — L'INTELLIGENCE AU SERVICE DU FOOTBALL.

Application React + TypeScript + Tailwind de pronostics football, avec validation humaine obligatoire.

**État : version 0.3.** Deux modes, jamais mélangés :
- **Sans configuration** : **MODE DÉMONSTRATION** (données fictives, connexion simulée).
- **Avec les deux variables publiques Supabase** : **mode réel**. Connexion réelle, et **toutes** les données (championnats, équipes, matchs, scores, statistiques, pronostics, résultats) sont lues et écrites dans la base. Plus aucune donnée fictive, plus de bandeau « démo ». Sans API sportive connectée, l'écran indique **MODE MANUEL** : l'administrateur saisit les données (menu **Données sportives**).

## Lancer

```bash
npm install
npm run dev            # http://localhost:5173
npm run build          # typage + build de production
```

Sans accès au registre npm : `TOOLS=/chemin/node_modules npm run build:offline` produit `dist-offline/index.html`.

## Connecter Supabase (étapes)

### 1. Créer le projet
1. Créez un compte sur supabase.com, puis **New project** (choisissez une région proche de vos utilisateurs, notez le mot de passe de la base dans votre gestionnaire de mots de passe — l'application n'en a pas besoin).
2. Une fois le projet prêt : **Project Settings → API**. Notez l'**URL du projet** et la clé **publique** (« anon » ou « publishable »). Ne copiez **pas** la clé `service_role` / `secret` dans l'application.

### 2. Exécuter les migrations SQL
Les migrations sont dans `supabase/migrations/`, à exécuter **dans l'ordre des noms** :

| Fichier | Contenu |
|---|---|
| `…000100_baseline.sql` | Schéma d'origine (profiles, fixtures, analyses, predictions, scan_runs, subscriptions) |
| `…000200_domain_tables.sql` | Championnats, équipes, classements, stats, cotes, plans d'abonnement, historique des pronostics + colonnes manquantes |
| `…000300_functions_triggers.sql` | Création du profil à l'inscription, règles de validation/publication, journal d'audit, règlement automatique, attribution VIP |
| `…000400_rls_policies.sql` | Privilèges minimaux + politiques RLS |
| `…000500_views_performance.sql` | Vues de statistiques (réussite, ROI par championnat et par pari) |
| `…000600_sports_data_admin.sql` | Saisie admin des données sportives (RLS), identifiants manuels, contraintes (statuts, scores, doublons), cohérence des noms, index manquants, règle « avant le match », validation/publication réservées à un humain |

**Option A — interface :** Supabase → **SQL Editor** → collez et exécutez chaque fichier, dans l'ordre.
**Option B — CLI :** `supabase link --project-ref <ref>` puis `supabase db push`.

`supabase/schema.sql` est une copie consolidée générée (`npm run schema`) : ne la modifiez pas à la main.

### 3. Configurer l'authentification
Dans **Authentication** :
- **Providers → Email** : activé.
- **Sign In / Providers → « Allow new users to sign up »** : **désactivez-le** pour l'instant. L'application n'a pas encore de page d'inscription ; les comptes sont créés par vous.
- **URL Configuration → Site URL** : l'adresse de votre application (ex. `http://localhost:5173` en local, puis votre domaine).

### 4. Créer le premier administrateur
1. **Authentication → Users → Add user** : e-mail + mot de passe (cochez la confirmation automatique).
2. Le profil est créé automatiquement avec le rôle `user`. Ouvrez `supabase/scripts/promote-admin.sql`, remplacez l'adresse e-mail, puis exécutez-le dans le **SQL Editor**.
   Le rôle `admin` ne peut **pas** être attribué depuis l'application : c'est voulu.

### 5. Connecter l'application
```bash
cp .env.example .env.local      # puis éditez .env.local : URL du projet + clé publique
npm run dev
```
Ouvrez la page **Connexion** : le badge « **Authentification Supabase active** » doit apparaître et les identifiants de démonstration disparaissent.
Si le badge n'apparaît pas, la page **Espace administrateur → Intégrations** indique pourquoi (variables absentes, exemples non remplacés, ou clé refusée).

## Sécurité

| Couche | Ce qui est appliqué |
|---|---|
| Navigateur | Seules `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` (publiques). Une clé `service_role` / `sb_secret_…` est **refusée** à l'exécution **et** au build. |
| Rôle | Lu dans `profiles` (protégé par RLS), jamais dans le jeton ni dans `user_metadata`. Si la lecture échoue : rôle `user` (échec fermé). |
| Base (RLS) | Le public ne lit que le **publié et validé** ; le VIP exige un abonnement actif ; seules les écritures d'un admin connecté passent. |
| Base (triggers) | Publier exige : pronostic validé par un **admin connecté**, justification non vide. Modifier un publié le dépublie. Le rôle `service_role` (le bot) **ne peut ni valider ni publier** (testé). Un pronostic doit être enregistré et publié **avant** le coup d'envoi, puis son contenu est figé. |
| Données sportives | Écriture réservée à un admin connecté et aux lignes saisies à la main ; lignes d'API en lecture seule ; contraintes contre les scores/statuts incohérents ; score non modifiable sous des pronostics déjà soldés. |
| Abonnements | Aucune écriture directe depuis l'application ; attribution par la fonction `admin_set_subscription` (admin) ou par le backend. |
| Audit | Chaque création, validation, publication, modification, règlement est journalisé (`prediction_events`). |
| Serveur | `supabase/functions/_shared/guard.ts` : seul le cron (secret) ou un admin vérifié en base peut appeler une fonction. |

Les clés privées (`APIFOOTBALL_KEY`, `CRON_SECRET`, `SUPABASE_SERVICE_ROLE_KEY`) vivent uniquement dans les secrets des fonctions (`supabase/functions/.env.example`), jamais dans `.env.local`.

## Vérifications automatiques

```bash
npm run test:sql        # 148 tests sur PostgreSQL : RLS, rôles, workflow, audit, données sportives (voir scripts/test-sql.sh)
npm run test:e2e        # navigateur : parcours démo (25) + authentification (26) + parcours réel complet sur vraie base PostgreSQL de test (25)
npm run test:live       # VOTRE projet Supabase, clé publique seule : lectures publiques OK, écritures anonymes refusées
npm run check:secrets   # aucun secret dans le code ni dans les fichiers compilés
```
`test:sql` demande un PostgreSQL ≥ 15 de test (jamais votre projet Supabase). `test:e2e` demande `playwright`.
Ces tests ont été exécutés sur PostgreSQL 16 avec un serveur de test qui imite l'API Supabase (`scripts/tests/pg-supabase.mjs`) : ils prouvent que l'interface et les règles SQL fonctionnent ensemble, **pas que votre projet réel est bien configuré**. Lancez `npm run test:live` puis faites une connexion manuelle de contrôle.

## Ce qui n'est pas encore branché
- **API sportive** : aucune clé, aucun appel, **rien de simulé** (mode manuel). Préparation et architecture : `docs/API_INTEGRATION.md`. La fonction `scan-matches` est un squelette **non déployé et non testé** (Deno absent). Le bouton « SCANNER MAINTENANT » le dit honnêtement en mode réel.
- **Moteur d'analyse** : non activé en mode réel — aucune probabilité n'est affichée (pas d'analyse inventée). Les pronostics se proposent à la main.
- **Robot IA, inscription des utilisateurs, abonnement VIP et paiement** : la base est prête (plans, abonnements, historique VIP protégé par RLS) ; pas d'interface d'inscription ni de paiement. Aucun paiement n'est actif.
- **Client Supabase** : client léger maison (`src/lib/supabase/`) car le registre npm était inaccessible ; remplaçable par `@supabase/supabase-js`.
- **Limites des tests** : le vrai Supabase n'était pas joignable depuis l'environnement de développement ; les fonctions Deno n'ont pas été exécutées.

## Structure
```
src/
  config.ts, lib/supabase/{env,client}.ts   configuration validée + client REST (auth, refresh, lecture)
  services/{auth,predictionsRepo,sportsRepo,sportsSource,football,engine}.ts
  pages/SportsData.tsx                      saisie admin des données sportives
  store/ pages/ components/ data/demo.ts    interface (démo conservée)
supabase/
  migrations/        5 migrations ordonnées
  tests/             tests SQL (RLS, workflow) + stub de Supabase pour PostgreSQL ordinaire
  scripts/promote-admin.sql
  functions/         _shared/guard.ts, scan-matches (squelette)
scripts/             build, vérification des secrets, tests e2e, génération du schéma
.env.example         variables publiques du front
```
