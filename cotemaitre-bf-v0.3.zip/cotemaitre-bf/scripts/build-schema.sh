#!/usr/bin/env bash
# Régénère supabase/schema.sql (copie consolidée, en lecture seule) à partir des migrations.
# Source de vérité = supabase/migrations/*.sql. Ne modifiez jamais schema.sql à la main.
set -euo pipefail
cd "$(dirname "$0")/../supabase"
{
  echo "-- GÉNÉRÉ par scripts/build-schema.sh — NE PAS MODIFIER. Source de vérité : supabase/migrations/."
  echo "-- Pour un projet Supabase vierge, exécutez plutôt les migrations dans l'ordre (voir le README)."
  for f in migrations/*.sql; do printf '\n-- ═════ %s ═════\n' "$(basename "$f")"; cat "$f"; done
} > schema.sql
echo "schema.sql régénéré ($(wc -l < schema.sql) lignes)"
