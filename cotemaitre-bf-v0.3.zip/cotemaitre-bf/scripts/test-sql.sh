#!/usr/bin/env bash
# Teste les migrations Supabase et les politiques RLS sur un PostgreSQL ORDINAIRE (jamais sur un vrai projet).
# Prérequis : un serveur PostgreSQL ≥ 15 accessible via les variables PGHOST / PGPORT / PGUSER (superutilisateur).
# Exemple local avec Docker : docker run -d --name pgtest -e POSTGRES_PASSWORD=test -p 54329:5432 postgres:16
#                             PGHOST=localhost PGPORT=54329 PGUSER=postgres PGPASSWORD=test ./scripts/test-sql.sh
set -euo pipefail
cd "$(dirname "$0")/../supabase"
DB="${TEST_DB:-cotemaitre_sql_test}"

dropdb --if-exists "$DB" >/dev/null
createdb "$DB"
trap 'dropdb --if-exists "$DB" >/dev/null 2>&1 || true' EXIT

psql -q -v ON_ERROR_STOP=1 -d "$DB" -f tests/00_stub_supabase.sql
for f in migrations/*.sql; do
  echo "→ migration $(basename "$f")"
  psql -q -v ON_ERROR_STOP=1 -d "$DB" -f "$f"
done
for f in tests/[1-9]*.test.sql; do
  echo "→ tests $(basename "$f")"
  psql -q -v ON_ERROR_STOP=1 -d "$DB" -f "$f"
done
