// Cherche des SECRETS réels dans le code source et dans les fichiers compilés destinés au navigateur.
// Usage : node scripts/check-secrets.mjs [chemins…]   (défaut : src index.html .env.example dist dist-offline)
// Code de sortie 1 si un secret est trouvé. Les clés « anon »/« publishable » sont publiques par conception : autorisées.
import fs from 'node:fs';
import path from 'node:path';
import { jwtRole } from './lib/assert-public-env.mjs';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const targets = process.argv.slice(2).length ? process.argv.slice(2) : ['src', 'index.html', '.env.example', 'dist', 'dist-offline'];

const files = [];
for (const t of targets) (function collect(p) {
  if (!fs.existsSync(p)) return;
  const st = fs.statSync(p);
  if (st.isDirectory()) { for (const f of fs.readdirSync(p)) collect(path.join(p, f)); return; }
  if (/\.(tsx?|jsx?|mjs|html|css|json|md)$/.test(p) || path.basename(p).startsWith('.env')) files.push(p);
})(path.resolve(root, t));

const findings = [];
const JWT = /eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{4,}/g;
for (const f of files) {
  const text = fs.readFileSync(f, 'utf8');
  const rel = path.relative(root, f);
  for (const m of text.matchAll(JWT)) {
    const role = jwtRole(m[0]);
    if (role && role !== 'anon') findings.push(`${rel} : JWT avec rôle « ${role} » (secret probable)`);
  }
  for (const m of text.matchAll(/sb_secret_[A-Za-z0-9_-]{8,}/g)) findings.push(`${rel} : clé sb_secret_… (${m[0].slice(0, 14)}…)`);
  // Signes d'un appel serveur embarqué dans un bundle navigateur : l'en-tête d'API-Football
  // ou la lecture d'une variable d'environnement Deno (Edge Functions). Les simples NOMS de variables
  // affichés dans l'interface (ex. « SUPABASE_SERVICE_ROLE_KEY (serveur) ») ne sont pas des secrets.
  if (/(^|[\\/])dist(-offline)?[\\/]/.test(rel) && /x-apisports-key|Deno\.env\.get/.test(text)) {
    findings.push(`${rel} : code d'appel serveur (API-Football / Deno.env) dans un fichier destiné au navigateur`);
  }
}

if (findings.length) {
  console.error('SECRETS DÉTECTÉS :\n - ' + [...new Set(findings)].join('\n - '));
  process.exit(1);
}
console.log(`OK — aucun secret trouvé (${files.length} fichiers analysés).`);
