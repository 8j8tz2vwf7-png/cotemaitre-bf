// Types minimaux de React, UNIQUEMENT pour vérifier le typage hors-ligne
// (le registre npm étant inaccessible, @types/react n'était pas installable).
// Sur votre machine, @types/react remplace ce fichier : il n'est pas utilisé par `npm run build`.
declare module 'react/jsx-runtime' {
  export const jsx: any; export const jsxs: any; export const Fragment: any;
}
declare module 'react-dom/client' {
  export function createRoot(el: Element | null): { render(n: any): void };
}
declare module 'react' {
  export type ReactNode = any;
  export interface Context<T> { Provider: any; _t?: T }
  export function createContext<T>(d: T): Context<T>;
  export function useContext<T>(c: Context<T>): T;
  export function useState<T>(init: T | (() => T)): [T, (v: T | ((p: T) => T)) => void];
  export function useEffect(f: () => void | (() => void), deps?: readonly unknown[]): void;
  export function useMemo<T>(f: () => T, deps: readonly unknown[]): T;
  export function useCallback<T extends (...a: any[]) => any>(f: T, deps: readonly unknown[]): T;
  export function useRef<T>(v: T): { current: T };
  export function useId(): string;
  export function useReducer<S, I, A>(r: (s: S, a: A) => S, arg: I, init: (a: I) => S): [S, (a: A) => void];
}
declare namespace JSX {
  interface Element {}
  interface IntrinsicAttributes { key?: any }
  interface ElementChildrenAttribute { children: {} }
  interface IntrinsicElements { [tag: string]: any }
}
declare module '*.css';
// import.meta.env (normalement fourni par vite/client)
interface ImportMetaEnv { readonly [key: string]: string | undefined }
interface ImportMeta { readonly env: ImportMetaEnv }
