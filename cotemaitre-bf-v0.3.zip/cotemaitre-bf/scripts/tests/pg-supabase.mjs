// Serveur de TEST : parle le protocole GoTrue/PostgREST utilisé par le client, mais exécute chaque requête
// dans un VRAI PostgreSQL (migrations + RLS + triggers réels) sous le rôle `anon` ou `authenticated`.
// Ce n'est pas Supabase : il prouve que l'interface + les règles SQL fonctionnent ensemble, pas votre projet réel.
import http from 'node:http';
import { execFile } from 'node:child_process';

const lit = (v) => `'${String(v).replace(/'/g, "''")}'`;
const ident = (v) => { if (!/^[a-z_][a-z0-9_]*$/.test(v)) throw new Error('identifiant refusé: ' + v); return v; };
const TABLES = new Set(['profiles', 'leagues', 'teams', 'fixtures', 'team_stats', 'predictions', 'scan_runs', 'analyses', 'subscription_plans', 'subscriptions', 'standings', 'odds']);

function psql(db, sql) {
  return new Promise((resolve) => {
    const p = execFile('psql', ['-X', '-q', '-A', '-t', '-d', db, '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose'], { maxBuffer: 64 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) { const m = /ERROR:\s+(\w{5}): (.*)/.exec(stderr); return resolve({ error: { code: m?.[1] ?? 'XX000', message: (m?.[2] ?? stderr).trim() } }); }
      const lines = stdout.trim().split('\n').filter(Boolean);
      resolve({ out: lines.length ? lines[lines.length - 1] : 'null' });
    });
    p.stdin.end(sql);
  });
}

function filters(url) {
  const out = [];
  for (const [k, v] of url.searchParams) {
    if (['select', 'order', 'limit', 'offset'].includes(k)) continue;
    const m = /^(eq|neq|gt|gte|lt|lte)\.(.*)$/.exec(v); if (!m) throw new Error('filtre non géré: ' + v);
    const op = { eq: '=', neq: '<>', gt: '>', gte: '>=', lt: '<', lte: '<=' }[m[1]];
    out.push(`${ident(k)} ${op} ${lit(m[2])}`);
  }
  return out.length ? ' where ' + out.join(' and ') : '';
}

function buildSql(method, table, url, body) {
  if (!TABLES.has(table)) throw new Error('table inconnue');
  const T = `public.${table}`;
  const w = filters(url);
  if (method === 'GET') {
    const sel = url.searchParams.get('select') ?? '*';
    let cols = sel === '*' ? '*' : sel.includes('fixtures(') ? `t.*, (select to_jsonb(f) from (select home_team, away_team, league_name, kickoff from public.fixtures f where f.id = t.fixture_id) f) as fixtures` : sel.split(',').map(ident).join(',');
    const ord = url.searchParams.get('order');
    const order = ord ? ' order by ' + ord.split(',').map((o) => { const [c, d] = o.split('.'); return `${ident(c)} ${d === 'desc' ? 'desc' : 'asc'}`; }).join(', ') : '';
    const lim = url.searchParams.get('limit') ? ` limit ${Number(url.searchParams.get('limit'))}` : '';
    const off = url.searchParams.get('offset') ? ` offset ${Number(url.searchParams.get('offset'))}` : '';
    return `select coalesce(jsonb_agg(q), '[]'::jsonb) from (select ${cols} from ${T} t${w}${order}${lim}${off}) q`;
  }
  if (method === 'POST') {
    const rows = Array.isArray(body) ? body : [body];
    const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))].map(ident);
    return `with r as (insert into ${T} (${cols.join(',')}) select ${cols.join(',')} from json_populate_recordset(null::${T}, ${lit(JSON.stringify(rows))}::json) returning *) select coalesce(jsonb_agg(r), '[]'::jsonb) from r`;
  }
  if (method === 'PATCH') {
    const cols = Object.keys(body).map(ident);
    return `with r as (update ${T} set (${cols.join(',')}) = (select ${cols.join(',')} from json_populate_record(null::${T}, ${lit(JSON.stringify(body))}::json))${w} returning *) select coalesce(jsonb_agg(r), '[]'::jsonb) from r`;
  }
  if (method === 'DELETE') return `with r as (delete from ${T}${w} returning *) select coalesce(jsonb_agg(r), '[]'::jsonb) from r`;
  throw new Error('méthode non gérée');
}

export async function startPgSupabase({ db, port, users }) {
  // users: { email: { pw, id, admin } } — créés dans auth.users (le trigger crée le profil), admin promu par SQL.
  for (const [email, u] of Object.entries(users)) {
    await psql(db, `insert into auth.users (id, email) values (${lit(u.id)}, ${lit(email)}) on conflict do nothing; ${u.admin ? `update public.profiles set role = 'admin' where id = ${lit(u.id)};` : ''}`);
  }
  const tokens = new Map(); let n = 0;
  const issue = (email) => {
    const u = users[email]; n++; const a = `acc-${n}`, r = `ref-${n}`; tokens.set(a, email); tokens.set(r, email);
    return { access_token: a, refresh_token: r, expires_in: 3600, expires_at: Math.floor(Date.now() / 1000) + 3600, token_type: 'bearer', user: { id: u.id, email } };
  };
  const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'apikey, authorization, content-type, accept, prefer, x-client-info');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    const url = new URL(req.url, 'http://x');
    let raw = ''; req.on('data', (c) => (raw += c)); req.on('end', async () => {
      const send = (code, o) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
      try {
        const body = raw ? JSON.parse(raw) : {};
        if (url.pathname === '/auth/v1/token') {
          if (url.searchParams.get('grant_type') === 'password') {
            const email = String(body.email || '').toLowerCase(); const u = users[email];
            if (!u || u.pw !== body.password) return send(400, { error: 'invalid_grant', error_description: 'Invalid login credentials' });
            return send(200, issue(email));
          }
          const email = tokens.get(body.refresh_token); return email ? send(200, issue(email)) : send(400, { error_description: 'Invalid Refresh Token' });
        }
        if (url.pathname === '/auth/v1/logout') { res.writeHead(204); return res.end(); }
        if (!url.pathname.startsWith('/rest/v1/')) return send(404, { message: 'not found' });
        const email = tokens.get((req.headers.authorization || '').replace('Bearer ', ''));
        const uid = email ? users[email].id : null;
        const path = url.pathname.slice('/rest/v1/'.length);
        let q;
        if (path.startsWith('rpc/')) {
          const fn = ident(path.slice(4));
          const args = Object.entries(body).map(([k, v]) => `${ident(k)} := ${lit(v)}`).join(', ');
          q = `select to_json(public.${fn}(${args}))`;
        } else q = buildSql(req.method, path, url, body);
        const sql = `begin; set local role ${uid ? 'authenticated' : 'anon'}; do $$ begin perform set_config('request.jwt.claim.sub', ${lit(uid ?? '')}, true); end $$; ${q}; commit;`;
        const r = await psql(db, sql);
        if (r.error) { if (process.env.DEBUG_PG) console.log('PGERR', req.method, path, r.error); const c = r.error.code; return send(c === '42501' ? 403 : c.startsWith('23') || c === 'P0001' ? 409 : 400, { code: c, message: r.error.message }); }
        send(req.method === 'POST' ? 201 : 200, JSON.parse(r.out));
      } catch (e) { if (process.env.DEBUG_PG) console.log('SRVERR', req.method, req.url, e.message); send(400, { code: 'XX000', message: String(e.message) }); }
    });
  });
  await new Promise((r) => server.listen(port, '127.0.0.1', r));
  return { server, psql: (sql) => psql(db, sql) };
}
