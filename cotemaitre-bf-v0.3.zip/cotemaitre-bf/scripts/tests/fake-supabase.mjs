// Faux serveur GoTrue + PostgREST (tests uniquement). Pas un vrai Supabase : il valide seulement le protocole utilisé par le client.
import http from 'node:http';
export function startFake({ expiresIn = 3600 } = {}) {
  const USERS = {
    'admin@test.local': { pw: 'pw-admin-1', id: '11111111-1111-1111-1111-111111111111', role: 'admin', name: 'Admin Test' },
    'user@test.local':  { pw: 'pw-user-1',  id: '22222222-2222-2222-2222-222222222222', role: 'user',  name: 'Simple Utilisateur' },
  };
  const tokens = new Map(); // access -> user ; refresh -> user
  const st = { expiresIn, n: 0, logins: 0, badLogins: 0, refreshes: 0, logouts: 0, profileCalls: 0, profilesFail: false, lastProfileAuth: null, lastApikey: null };
  const issue = (u, email) => {
    const n = ++st.n; const access = `acc-${u.id.slice(0, 2)}-${n}`; const refresh = `ref-${u.id.slice(0, 2)}-${n}`;
    tokens.set(access, u); tokens.set(refresh, u);
    return { access_token: access, refresh_token: refresh, expires_in: st.expiresIn, expires_at: Math.floor(Date.now() / 1000) + st.expiresIn, token_type: 'bearer', user: { id: u.id, email } };
  };
  const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'apikey, authorization, content-type, accept, prefer, x-client-info');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    const url = new URL(req.url, 'http://x');
    let body = ''; req.on('data', (c) => (body += c)); req.on('end', () => {
      const json = (code, o) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
      st.lastApikey = req.headers['apikey'] ?? null;
      if (url.pathname === '/auth/v1/token' && req.method === 'POST') {
        const b = body ? JSON.parse(body) : {};
        if (url.searchParams.get('grant_type') === 'password') {
          const email = String(b.email || '').toLowerCase(); const u = USERS[email];
          if (!u || u.pw !== b.password) { st.badLogins++; return json(400, { error: 'invalid_grant', error_description: 'Invalid login credentials' }); }
          st.logins++; return json(200, issue(u, email));
        }
        if (url.searchParams.get('grant_type') === 'refresh_token') {
          const u = tokens.get(b.refresh_token); if (!u) return json(400, { error_description: 'Invalid Refresh Token' });
          st.refreshes++; const email = Object.keys(USERS).find((k) => USERS[k] === u); return json(200, issue(u, email));
        }
      }
      if (url.pathname === '/auth/v1/logout' && req.method === 'POST') { st.logouts++; res.writeHead(204); return res.end(); }
      if (url.pathname === '/auth/v1/user') {
        const u = tokens.get((req.headers.authorization || '').replace('Bearer ', '')); if (!u) return json(401, { msg: 'invalid JWT' });
        return json(200, { id: u.id, email: Object.keys(USERS).find((k) => USERS[k] === u) });
      }
      if (url.pathname === '/rest/v1/profiles' && req.method === 'GET') {
        st.profileCalls++; st.lastProfileAuth = req.headers.authorization ?? null;
        if (st.profilesFail) return json(500, { message: 'boom' });
        const u = tokens.get((req.headers.authorization || '').replace('Bearer ', '')); if (!u) return json(401, { message: 'JWT expired' });
        const idq = (url.searchParams.get('id') || '').replace('eq.', '');
        // RLS simulée : on ne voit que son propre profil
        return json(200, idq === u.id ? [{ role: u.role, display_name: u.name }] : []);
      }
      // Autres tables : lecture vide (ce faux serveur ne teste que l'authentification).
      if (url.pathname.startsWith('/rest/v1/') && req.method === 'GET') return json(200, []);
      json(404, { message: 'not found ' + url.pathname });
    });
  });
  return new Promise((r) => server.listen(0, '127.0.0.1', () => r({ server, st, port: server.address().port, USERS })));
}
