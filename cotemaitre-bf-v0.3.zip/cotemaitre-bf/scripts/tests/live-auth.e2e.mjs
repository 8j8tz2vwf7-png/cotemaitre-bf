// Test navigateur (Playwright). Prérequis : `npm i -D playwright` (ou PLAYWRIGHT_MODULE=/chemin/playwright/index.mjs),
// et soit `npm install` (outils de build), soit TOOLS=/chemin/node_modules pour le build hors-ligne.
import { startFake } from './fake-supabase.mjs';
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const HERE = path.dirname(fileURLToPath(import.meta.url));
const S = fs.mkdtempSync(path.join(os.tmpdir(), 'cbf-live-'));
const PROJ = path.resolve(HERE, '..', '..');
const PORT = 54500;
const b64u = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const ANON = `${b64u({ alg: 'HS256', typ: 'JWT' })}.${b64u({ role: 'anon', iss: 'supabase' })}.fakesignature_for_tests`;
// 1) Compilation « live » avec la config publique pointant vers le faux serveur
execSync('node scripts/build-offline.mjs', { cwd: PROJ, stdio: 'pipe', env: { ...process.env, TOOLS: process.env.TOOLS, VITE_SUPABASE_URL: `http://127.0.0.1:${PORT}`, VITE_SUPABASE_ANON_KEY: ANON } });
fs.copyFileSync(`${PROJ}/dist-offline/index.html`, `${S}/live.html`);
const url = 'file://' + S + '/live.html';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
const { server, st } = await startFake({ expiresIn: 3600 });
await new Promise((r) => { server.close(); setTimeout(r, 50); });
await new Promise((r) => server.listen(PORT, '127.0.0.1', r));
const browser = await chromium.launch();
const errs = [];
const newPage = async (ctx) => { const p = await ctx.newPage(); p.on('pageerror', (e) => errs.push(e.message)); return p; };
const body = async (p) => (await p.innerText('body')).toLowerCase();

const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
let page = await newPage(ctx);
await page.goto(url + '#/connexion'); await page.waitForSelector('text=Connexion administrateur');
let t = await body(page);
ok(t.includes('authentification supabase active'), 'Mode live détecté : badge « Authentification Supabase active »');
ok(!t.includes('admin@demo.local') && !t.includes('demo-admin-2026'), 'Identifiants de démo NON affichés en mode live');
ok(!t.includes('connexion démo en un clic'), 'Bouton « connexion démo » absent en mode live');

// identifiants de démo refusés par le vrai serveur
await page.fill('input[type=email]', 'admin@demo.local'); await page.fill('input[type=password]', 'demo-admin-2026');
await page.click('button:has-text("Se connecter")'); await page.waitForTimeout(700);
ok(st.badLogins === 1 && page.url().includes('connexion'), 'Identifiants de démo refusés en mode live (le serveur les rejette)');
ok((await body(page)).includes('invalid login credentials') || (await body(page)).includes('identifiants'), 'Message d\'erreur affiché');

// mauvais mot de passe d'un vrai compte
await page.fill('input[type=email]', 'admin@test.local'); await page.fill('input[type=password]', 'mauvais');
await page.click('button:has-text("Se connecter")'); await page.waitForTimeout(600);
ok(st.badLogins === 2 && st.logins === 0, 'Mauvais mot de passe refusé, aucune session créée');

// compte non admin : refusé + session fermée
await page.fill('input[type=email]', 'user@test.local'); await page.fill('input[type=password]', 'pw-user-1');
await page.click('button:has-text("Se connecter")'); await page.waitForTimeout(900);
ok((await body(page)).includes("n'a pas les droits"), 'Compte « user » : refus explicite');
ok(st.logouts === 1, 'Compte « user » : session fermée côté serveur (logout appelé)');
await page.evaluate(() => (location.hash = '/admin')); await page.waitForTimeout(300);
ok((await body(page)).includes('espace réservé'), 'Compte « user » : /admin reste verrouillé');

// admin
await page.evaluate(() => (location.hash = '/connexion')); await page.waitForSelector('input[type=email]');
await page.fill('input[type=email]', 'admin@test.local'); await page.fill('input[type=password]', 'pw-admin-1');
await page.click('button:has-text("Se connecter")'); await page.waitForURL('**#/admin'); await page.waitForTimeout(500);
t = await body(page);
ok(t.includes('espace administrateur') && !t.includes('espace réservé'), 'Admin : accès à l\'espace administrateur');
ok(t.includes('données de démonstration locales'), 'Admin : mention honnête « données de démonstration locales »');
ok(st.lastProfileAuth?.startsWith('Bearer acc-11'), 'Le rôle est lu avec le jeton de l\'utilisateur (pas la clé anon)');
ok(st.lastApikey === ANON, 'La clé publique anon est envoyée en en-tête apikey');
const stored = await page.evaluate(() => Object.keys(localStorage).filter((k) => k.includes('session') || k.includes('demo')).join(','));
ok(!(await page.evaluate(() => (localStorage.getItem('cotemaitre-bf-demo-v1') || '').includes('"session"'))), 'La session n\'est pas copiée dans l\'état applicatif local');

// action protégée côté interface : scan (démo) fonctionne pour l'admin
await page.evaluate(() => (location.hash = '/bot')); await page.waitForSelector('text=SCANNER MAINTENANT');
await page.click('text=SCANNER MAINTENANT'); await page.waitForSelector('text=Scan indisponible', { timeout: 8000 });
ok(true, 'Admin (mode réel) : le scan refuse honnêtement de simuler (aucune API connectée)');

// rechargement : session restaurée
const callsBefore = st.profileCalls;
await page.reload(); await page.waitForSelector('text=Tableau de bord').catch(() => {}); await page.evaluate(() => (location.hash = '/admin')); await page.waitForTimeout(900);
ok(!(await body(page)).includes('espace réservé') && st.profileCalls > callsBefore, 'Rechargement : session restaurée et rôle relu en base');

// falsification du stockage : fabriquer une session admin locale ne donne rien
const ctx2 = await browser.newContext(); const p2 = await newPage(ctx2);
await p2.goto(url + '#/'); await p2.waitForTimeout(500);
await p2.evaluate(() => {
  localStorage.setItem('cotemaitre-bf-demo-v1', JSON.stringify({ predictions: [], scans: [], analyzedIds: [], vipPreview: false, session: { email: 'pirate@x', role: 'admin' } }));
  localStorage.setItem('cotemaitre-bf-demo-session', JSON.stringify({ email: 'admin@demo.local', role: 'admin' }));
  localStorage.setItem('cotemaitre-bf-supabase-session', JSON.stringify({ accessToken: 'faux', refreshToken: 'faux', expiresAt: 9999999999, user: { id: '11111111-1111-1111-1111-111111111111', email: 'admin@test.local' } }));
});
await p2.reload(); await p2.evaluate(() => (location.hash = '/admin')); await p2.waitForTimeout(1200);
ok((await body(p2)).includes('espace réservé'), 'Falsification du localStorage (fausse session admin + faux jeton) : accès refusé');
await ctx2.close();

// panne de la base : échec fermé (jamais admin par défaut)
st.profilesFail = true;
const ctx3 = await browser.newContext(); const p3 = await newPage(ctx3);
await p3.goto(url + '#/connexion'); await p3.waitForSelector('input[type=email]');
await p3.fill('input[type=email]', 'admin@test.local'); await p3.fill('input[type=password]', 'pw-admin-1');
await p3.click('button:has-text("Se connecter")'); await p3.waitForTimeout(1000);
ok((await body(p3)).includes("n'a pas les droits"), 'Lecture du profil en erreur (500) : échec fermé, pas d\'accès admin');
await ctx3.close(); st.profilesFail = false;

// déconnexion
await page.evaluate(() => (location.hash = '/')); await page.waitForTimeout(300);
await page.click('text=Se déconnecter'); await page.waitForTimeout(600);
const lo = st.logouts;
ok(lo >= 2, 'Déconnexion : jeton révoqué côté serveur');
await page.reload(); await page.evaluate(() => (location.hash = '/admin')); await page.waitForTimeout(800);
ok((await body(page)).includes('espace réservé'), 'Après déconnexion + rechargement : toujours verrouillé');
ok(!(await page.evaluate(() => localStorage.getItem('cotemaitre-bf-supabase-session'))), 'Jeton effacé du navigateur');
await ctx.close();

// rafraîchissement automatique du jeton
st.expiresIn = 62; const rb = st.refreshes;
const ctx4 = await browser.newContext(); const p4 = await newPage(ctx4);
await p4.goto(url + '#/connexion'); await p4.waitForSelector('input[type=email]');
await p4.fill('input[type=email]', 'admin@test.local'); await p4.fill('input[type=password]', 'pw-admin-1');
await p4.click('button:has-text("Se connecter")'); await p4.waitForURL('**#/admin'); await p4.waitForTimeout(4500);
ok(st.refreshes > rb, `Jeton rafraîchi automatiquement avant expiration (${st.refreshes - rb} refresh)`);
ok(!(await body(p4)).includes('espace réservé'), 'Toujours admin après rafraîchissement');
await ctx4.close();

ok(errs.length === 0, 'Aucune erreur JS ' + JSON.stringify(errs));
await browser.close(); server.close();
console.log(`\n== LIVE AUTH : ${pass} réussi(s), ${fail} échec(s) ==`);

// Le build doit REFUSER une clé secrète dans une variable publique
let refused = false;
const SECRET = `${b64u({ alg: 'HS256' })}.${b64u({ role: 'service_role' })}.sig`;
try { execSync('node scripts/build-offline.mjs', { cwd: PROJ, stdio: 'pipe', env: { ...process.env, TOOLS: process.env.TOOLS, VITE_SUPABASE_URL: 'https://abc.supabase.co', VITE_SUPABASE_ANON_KEY: SECRET } }); } catch (e) { refused = /BUILD REFUSÉ/.test(String(e.stderr)); }
console.log((refused ? 'PASS ' : 'FAIL ') + 'Build refusé si une clé service_role est placée dans VITE_SUPABASE_ANON_KEY');
let refused2 = false;
try { execSync('node scripts/build-offline.mjs', { cwd: PROJ, stdio: 'pipe', env: { ...process.env, TOOLS: process.env.TOOLS, VITE_APIFOOTBALL_KEY: 'abc' } }); } catch (e) { refused2 = /BUILD REFUSÉ/.test(String(e.stderr)); }
console.log((refused2 ? 'PASS ' : 'FAIL ') + 'Build refusé si un nom VITE_* désigne un secret (VITE_APIFOOTBALL_KEY)');
// Restaurer le build de démonstration
execSync('node scripts/build-offline.mjs', { cwd: PROJ, stdio: 'pipe', env: { ...process.env, TOOLS: process.env.TOOLS } });
process.exit(fail || !refused || !refused2 ? 1 : 0);
