// Contrôle de VOTRE projet Supabase réel, avec la seule clé publique (aucun secret demandé).
// Usage : VITE_SUPABASE_URL=… VITE_SUPABASE_ANON_KEY=… npm run test:live
// Tests non destructifs : lectures publiques + tentatives d'écriture anonymes qui DOIVENT être refusées.
const url = process.env.VITE_SUPABASE_URL, key = process.env.VITE_SUPABASE_ANON_KEY;
if (!url || !key) { console.error('Renseignez VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY (clé publique uniquement).'); process.exit(2); }
if (/service_role|sb_secret_/.test(key)) { console.error('Clé secrète détectée : ne l\'utilisez JAMAIS ici.'); process.exit(2); }
const H = { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' };
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
const call = (m, p, b) => fetch(`${url}/rest/v1/${p}`, { method: m, headers: { ...H, Prefer: 'return=representation' }, body: b ? JSON.stringify(b) : undefined });
for (const t of ['leagues', 'teams', 'fixtures']) { const r = await call('GET', `${t}?select=id&limit=1`); ok(r.ok, `Lecture publique de ${t} (${r.status}) — échec = migrations non appliquées`); }
ok((await call('GET', 'predictions?select=id,tier,published,review&limit=200').then((r) => r.json())).every?.((p) => p.published && p.review === 'validated' && p.tier === 'free'), 'Visiteur anonyme : uniquement du gratuit, publié et validé');
for (const [t, b] of [['leagues', { name: 'Intrus' }], ['teams', { name: 'Intrus' }], ['fixtures', { league_id: 1 }], ['predictions', { market: '1X2' }], ['team_stats', { team_id: 1 }]]) {
  const r = await call('POST', t, b); ok(r.status === 401 || r.status === 403, `Écriture anonyme refusée sur ${t} (${r.status})`);
}
const r = await call('GET', 'scan_runs?select=id&limit=1'); ok(r.status === 401 || r.status === 403 || (r.ok && (await r.json()).length === 0), 'Journal des scans illisible pour un anonyme');
console.log(`\n== projet réel : ${pass} réussi(s), ${fail} échec(s) ==`); process.exit(fail ? 1 : 0);
