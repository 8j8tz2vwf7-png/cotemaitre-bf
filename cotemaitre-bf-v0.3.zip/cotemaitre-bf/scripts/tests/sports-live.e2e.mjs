// Parcours réel : interface compilée en mode « Supabase configuré » ←→ serveur de test (pg-supabase.mjs) ←→ vrai PostgreSQL
// (migrations + RLS + triggers). Prérequis : PGHOST/PGPORT/PGUSER (PostgreSQL de TEST), playwright, TOOLS=…/node_modules.
import { startPgSupabase } from './pg-supabase.mjs';
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROJ = path.resolve(HERE, '..', '..');
const S = fs.mkdtempSync(path.join(os.tmpdir(), 'cbf-sports-'));
const DB = 'cbf_e2e_sports', PORT = 54600;
const sh = (c) => execSync(c, { cwd: PROJ, stdio: 'pipe', env: process.env }).toString();
sh(`dropdb --if-exists ${DB}; createdb ${DB}; psql -q -v ON_ERROR_STOP=1 -d ${DB} -f supabase/tests/00_stub_supabase.sql`);
for (const f of fs.readdirSync(path.join(PROJ, 'supabase/migrations')).sort()) sh(`psql -q -v ON_ERROR_STOP=1 -d ${DB} -f supabase/migrations/${f}`);
const b64u = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const ANON = `${b64u({ alg: 'HS256', typ: 'JWT' })}.${b64u({ role: 'anon', iss: 'supabase' })}.fakesignature_for_tests`;
execSync('node scripts/build-offline.mjs', { cwd: PROJ, stdio: 'pipe', env: { ...process.env, VITE_SUPABASE_URL: `http://127.0.0.1:${PORT}`, VITE_SUPABASE_ANON_KEY: ANON } });
fs.copyFileSync(`${PROJ}/dist-offline/index.html`, `${S}/live.html`);
const url = 'file://' + S + '/live.html';
const { server, psql } = await startPgSupabase({ db: DB, port: PORT, users: {
  'admin@test.local': { pw: 'pw-admin-1', id: '11111111-1111-1111-1111-111111111111', admin: true },
  'user@test.local': { pw: 'pw-user-1', id: '22222222-2222-2222-2222-222222222222' } } });
const q = async (sql) => (await psql(`select ${sql}`)).out;

let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
const browser = await chromium.launch();
const errs = [];
const mk = async () => { const c = await browser.newContext({ viewport: { width: 1280, height: 900 } }); const p = await c.newPage(); p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => { if (process.env.DEBUG_PG && m.type() === 'error') console.log('CONSOLE', m.text()); }); p.on('requestfailed', (r) => process.env.DEBUG_PG && console.log('REQFAIL', r.url(), r.failure()?.errorText)); return p; };
const body = async (p) => (await p.innerText('body')).toLowerCase();
const go = async (p, h) => { await p.evaluate((x) => (location.hash = x), h); await p.waitForTimeout(500); };
const dlg = (p) => p.getByRole('dialog');
const saveClose = async (p) => { await dlg(p).getByRole('button', { name: 'Enregistrer' }).click(); await dlg(p).waitFor({ state: 'hidden', timeout: 15000 }).catch(async (e) => { console.log('DIALOG BODY:', (await p.innerText('body')).slice(-1800)); throw e; }); };

// ── Visiteur sur base vide : aucune donnée fictive ──
const v = await mk();
await v.goto(url + '#/'); await v.waitForTimeout(1200);
let t = await body(v);
ok(!t.includes('mode démonstration') && !t.includes('données fictives'), 'Mode réel : aucune mention « démonstration » / « fictif »');
await go(v, '/donnees'); t = await body(v);
ok(t.includes('espace réservé'), 'Visiteur : « Données sportives » verrouillé');
await go(v, '/matchs'); t = await body(v);
ok(!t.includes('manchester') && !t.includes('real madrid'), 'Matchs : base vide → aucun match inventé');

// ── Admin : connexion réelle ──
const a = await mk();
await a.goto(url + '#/connexion'); await a.waitForSelector('input[type=email]');
await a.fill('input[type=email]', 'admin@test.local'); await a.fill('input[type=password]', 'pw-admin-1');
await a.click('button:has-text("Se connecter")'); await a.waitForURL('**#/admin'); await a.waitForTimeout(600);
await go(a, '/donnees'); t = await body(a);
ok(t.includes('mode manuel'), 'Admin : « MODE MANUEL » affiché (aucune API connectée)');

// Championnat
await a.click('button:has-text("Championnats")'); await a.click('button:has-text("Nouveau championnat")');
await dlg(a).getByLabel('Nom', { exact: true }).fill('Championnat du Faso'); await dlg(a).getByLabel('Pays').fill('Burkina Faso');
await saveClose(a);
ok((await q(`count(*) from public.leagues where name='Championnat du Faso' and source='manual' and id >= 9000000000000`)) === '1', 'Championnat enregistré EN BASE (id manuel ≥ 9e12)');
// Doublon
await a.click('button:has-text("Nouveau championnat")'); await dlg(a).getByLabel('Nom', { exact: true }).fill('championnat du faso'); await dlg(a).getByLabel('Pays').fill('Burkina Faso');
await dlg(a).getByRole('button', { name: 'Enregistrer' }).click(); await a.waitForTimeout(800);
ok((await body(a)).includes('existe déjà'), 'Doublon de championnat refusé avec message clair');
await a.keyboard.press('Escape');
// Équipes
await a.click('button:has-text("Équipes")');
for (const n of ['Étoile Filante', 'Racing Club']) {
  await a.click('button:has-text("Nouvelle équipe")'); await dlg(a).getByLabel('Nom', { exact: true }).fill(n);
  await saveClose(a);
}
ok((await q(`count(*) from public.teams where source='manual'`)) === '2', '2 équipes enregistrées en base');
// Match
await a.click('button:has-text("Matchs")'); await a.click('button:has-text("Programmer un match")');
await dlg(a).getByLabel('Championnat').selectOption({ label: 'Championnat du Faso' });
await dlg(a).getByLabel('Domicile').selectOption({ label: 'Étoile Filante' });
await dlg(a).getByLabel('Extérieur').selectOption({ label: 'Racing Club' });
await saveClose(a);
ok((await q(`count(*) from public.fixtures where home_team='Étoile Filante' and away_team='Racing Club' and league_name='Championnat du Faso' and status='scheduled'`)) === '1', 'Match programmé en base, noms et statut cohérents');
// Même équipe des deux côtés
await a.click('button:has-text("Programmer un match")');
await dlg(a).getByLabel('Championnat').selectOption({ label: 'Championnat du Faso' });
await dlg(a).getByLabel('Domicile').selectOption({ label: 'Racing Club' }); await dlg(a).getByLabel('Extérieur').selectOption({ label: 'Racing Club' });
await dlg(a).getByRole('button', { name: 'Enregistrer' }).click(); await a.waitForTimeout(800);
ok((await q(`count(*) from public.fixtures`)) === '1', 'Match « équipe contre elle-même » refusé par la base');
await a.keyboard.press('Escape');
// Statistiques
await a.click('button:has-text("Statistiques")'); await a.click('button:has-text("Ajouter des statistiques")');
await dlg(a).getByLabel('Équipe').selectOption({ label: 'Étoile Filante' }); await dlg(a).getByLabel('Championnat').selectOption({ label: 'Championnat du Faso' });
await dlg(a).getByLabel('Forme', { exact: false }).fill('wwdlw');
await saveClose(a);
ok((await q(`count(*) from public.team_stats where stats->>'form'='WWDLW'`)) === '1', 'Statistiques d\'équipe enregistrées (forme normalisée)');

// Persistance : rechargement complet
await a.reload(); await a.waitForTimeout(1500); await go(a, '/matchs'); await a.click('button:has-text("Demain")'); await a.waitForTimeout(300); t = await body(a);
ok(t.includes('étoile filante') && t.includes('racing club'), 'Après rechargement : le match saisi est toujours là (lu en base)');

// ── Pronostic : création → validation → publication (avant le match) ──
const mid = await q(`id from public.fixtures limit 1`);
await go(a, '/analyse/' + mid); t = await body(a);
ok(t.includes('analyse statistique non disponible'), 'Analyse : message honnête, aucune probabilité inventée');
await a.click('button:has-text("Proposer un pronostic")'); await dlg(a).getByLabel('Justification').fill('Forme à domicile solide');
await dlg(a).getByRole('button', { name: 'Créer la proposition' }).click(); await a.waitForTimeout(900);
ok((await q(`count(*) from public.predictions where review='proposed' and not published and source='admin'`)) === '1', 'Proposition enregistrée en base (proposée, non publiée)');
await go(a, '/admin'); await a.waitForTimeout(500);
await a.click('button:has-text("Valider")'); await a.waitForTimeout(800);
ok((await q(`count(*) from public.predictions where review='validated' and reviewed_by is not null`)) === '1', 'Validation enregistrée avec l\'identité de l\'admin');
ok((await q(`count(*) from public.predictions where published`)) === '0', 'Validé ≠ publié : rien n\'est publié automatiquement');
await go(a, '/admin'); await a.click('button:has-text("Publications & résultats")'); await a.waitForTimeout(400);
await a.click('button:has-text("Publier")'); await a.waitForTimeout(800);
ok((await q(`count(*) from public.predictions p join public.fixtures f on f.id=p.fixture_id where p.published and p.published_at < f.kickoff`)) === '1', 'Publié AVANT le coup d\'envoi (published_at < kickoff)');

// Visiteur : voit le gratuit publié
await go(v, '/pronostics'); await v.reload(); await v.waitForTimeout(1500); await go(v, '/pronostics'); t = await body(v);
ok(t.includes('victoire domicile') || t.includes('étoile filante'), 'Visiteur : le pronostic gratuit publié est visible');

// Score + règlement depuis le score officiel saisi
await go(a, '/donnees'); await a.click('button:has-text("Matchs")');
await a.click('button:has-text("Score / statut")');
await dlg(a).getByLabel('Statut').selectOption({ label: 'Terminé' });
await dlg(a).getByRole('button', { name: 'Enregistrer' }).click(); await a.waitForTimeout(800);
ok((await body(a)).includes('deux scores'), 'Statut « terminé » sans score refusé');
await dlg(a).getByLabel('Buts domicile').fill('2'); await dlg(a).getByLabel('Buts extérieur').fill('1');
await saveClose(a);
ok((await q(`count(*) from public.fixtures where status='finished' and home_goals=2 and away_goals=1 and status_short='FT'`)) === '1', 'Score 2–1 enregistré, statut terminé');
await go(a, '/admin'); await a.click('button:has-text("Publications & résultats")'); await a.waitForTimeout(400);
await a.click("button:has-text(\"Régler d'après le score\")"); await a.waitForTimeout(900);
ok((await q(`count(*) from public.predictions where result='won' and settled_at is not null`)) === '1', 'Pronostic réglé d\'après le score : gagné');
await v.reload(); await v.waitForTimeout(1500); await go(v, '/historique'); t = await body(v);
ok(t.includes('1') && t.includes('taux de réussite'), 'Historique public : résultat réel affiché');
ok((await q(`count(*) from public.predictions where result='won'`)) === (await q(`count(*) from public.predictions where result='won' and published`)), 'Cohérence : tout résultat compté est publié');

// VIP : verrouillé pour le visiteur
await go(v, '/historique'); await v.click('button:has-text("VIP")'); await v.waitForTimeout(400); t = await body(v);
ok(t.includes('historique vip réservé aux abonnés'), 'Visiteur : historique VIP verrouillé');
// Un compte non admin ne peut rien écrire (via l'API réelle)
const u = await mk(); await u.goto(url + '#/connexion'); await u.waitForSelector('input[type=email]');
await u.fill('input[type=email]', 'user@test.local'); await u.fill('input[type=password]', 'pw-user-1'); await u.click('button:has-text("Se connecter")'); await u.waitForTimeout(900);
ok((await body(u)).includes("n'a pas les droits"), 'Compte non admin refusé à la connexion');

ok(errs.length === 0, 'Aucune erreur JS ' + JSON.stringify(errs.slice(0, 3)));
await browser.close(); server.close();
sh(`dropdb --if-exists ${DB}`);
console.log(`\n== sports-live : ${pass} réussi(s), ${fail} échec(s) ==`);
process.exit(fail ? 1 : 0);
