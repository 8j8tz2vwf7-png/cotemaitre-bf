// Test navigateur (Playwright). Prérequis : `npm i -D playwright` (ou PLAYWRIGHT_MODULE=/chemin/playwright/index.mjs),
// et soit `npm install` (outils de build), soit TOOLS=/chemin/node_modules pour le build hors-ligne.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const PROJ = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
import { execSync } from 'node:child_process';
// Build démonstration (sans variables Supabase) pour ne pas dépendre d'un build précédent.
execSync('node scripts/build-offline.mjs', { cwd: path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..'), stdio: 'pipe', env: Object.fromEntries(Object.entries(process.env).filter(([k]) => !k.startsWith('VITE_'))) });
const url = 'file://' + path.join(PROJ, 'dist-offline/index.html');
const out = fs.mkdtempSync(path.join(os.tmpdir(), 'cbf-smoke-'));
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push('PAGEERROR ' + e.message));
page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text())) errors.push('CONSOLE ' + m.text()); });
const txt = async () => (await page.innerText('body')).toLowerCase();
const ok = (c, msg) => console.log((c ? 'PASS ' : 'FAIL ') + msg);

await page.goto(url); await page.waitForSelector('text=Vue d\'ensemble');
ok((await txt()).includes('MODE DÉMONSTRATION'.toLowerCase()), 'Dashboard + bannière démo');
await page.screenshot({ path: out + '/dash.png' });

for (const [route, needle] of [['/matchs','Championnats disponibles'],['/bot','SCANNER MAINTENANT'],['/pronostics','Pronostics gratuits'],['/historique','Taux de réussite'],['/admin','Espace réservé'],['/analyse/m11','Probabilités estimées'],['/inconnu','Page introuvable']]) {
  await page.evaluate((r) => (location.hash = r), route); await page.waitForTimeout(250);
  ok((await txt()).includes(needle.toLowerCase()), 'Route ' + route);
}
// Scan sans login refusé
await page.evaluate(() => (location.hash = '/bot')); await page.waitForTimeout(200);
await page.click('text=SCANNER MAINTENANT'); await page.waitForTimeout(300);
ok(page.url().includes('#/connexion'.toLowerCase()), 'Scan sans admin => redirection connexion');
// Mauvais mot de passe
await page.fill('input[type=email]', 'x@y.z'); await page.fill('input[type=password]', 'nope'); await page.click('button:has-text("Se connecter")'); await page.waitForTimeout(700);
ok((await txt()).includes('Identifiants incorrects'.toLowerCase()), 'Mauvais identifiants refusés');
await page.click('text=Connexion démo en un clic'); await page.waitForURL('**#/admin');
ok(true, 'Connexion démo OK');
// Scan
await page.evaluate(() => (location.hash = '/bot')); await page.waitForSelector('text=SCANNER MAINTENANT');
await page.click('text=SCANNER MAINTENANT'); await page.waitForSelector('text=Scan démo terminé', { timeout: 8000 });
const t1 = await txt();
ok(/nouvelle\(s\) proposition/.test(t1), 'Scan démo exécuté + historique');
await page.screenshot({ path: out + '/bot.png', fullPage: true });
// Second scan : idempotent
await page.waitForTimeout(4000);
await page.click('text=SCANNER MAINTENANT'); await page.waitForTimeout(1600);
ok((await txt()).includes('0 nouvelle(s) proposition'), 'Second scan : aucun doublon');
// Admin: valider sans justification impossible (seed_prop_2) puis justifier
await page.evaluate(() => (location.hash = '/admin')); await page.waitForSelector('text=En attente');
const cards = await page.locator('article').count(); ok(cards >= 3, `Propositions listées (${cards})`);
const target = page.locator('article', { hasText: 'Aucune justification' }).first();
await target.locator('button:has-text("Valider")').click(); await page.waitForTimeout(300);
ok((await txt()).includes('Ajoutez une justification'.toLowerCase()), 'Validation refusée sans justification');
await target.locator('button:has-text("Justifier")').click();
await page.fill('textarea', 'Justification test : défense adverse fragile.'); await page.click('button:has-text("Enregistrer")'); await page.waitForTimeout(300);
await page.locator('article', { hasText: 'Justification test' }).first().locator('button:has-text("Valider")').click(); await page.waitForTimeout(300);
await page.click('button:has-text("Validés")'); await page.waitForTimeout(300);
const vc = page.locator('article', { hasText: 'Justification test' }).first();
ok(await vc.locator('button:has-text("Publier")').isVisible(), 'Validé => bouton Publier');
await vc.locator('button:has-text("Publier")').click(); await page.waitForTimeout(300);
ok(await vc.locator('button:has-text("Dépublier")').isVisible(), 'Publié => bouton Dépublier');
// Visible côté public (la proposition validée est VIP => onglet VIP)
await page.evaluate(() => (location.hash = '/pronostics')); await page.waitForTimeout(300);
await page.click('button:has-text("Pronostics VIP")'); await page.waitForTimeout(300);
ok((await txt()).includes('justification test'), 'Pronostic publié visible (onglet VIP)');
const st = await page.evaluate(() => { const P = JSON.parse(localStorage.getItem('cotemaitre-bf-demo-v1')).predictions; return { scanPublished: P.filter(p => p.source==='demo-scan' && p.published).length, scanTotal: P.filter(p => p.source==='demo-scan').length, scanProposed: P.filter(p => p.source==='demo-scan' && p.review==='proposed').length, mine: P.filter(p => p.justification.startsWith('Justification test') && p.published).length }; });
ok(st.scanTotal > 0 && st.scanPublished === 0 && st.scanProposed === st.scanTotal, `Aucune publication automatique : ${st.scanTotal} proposition(s) du bot, ${st.scanPublished} publiée(s)`);
ok(st.mine === 1, 'Publication manuelle prise en compte');
// Résultat + stats
await page.evaluate(() => (location.hash = '/admin')); await page.waitForTimeout(200);
await page.click('button:has-text("Publications & résultats")'); await page.waitForTimeout(300);
await page.locator('article', { hasText: 'Justification test' }).first().locator('button:has-text("Gagné")').click(); await page.waitForTimeout(300);
ok(true, 'Résultat enregistré');
// VIP
await page.evaluate(() => (location.hash = '/pronostics')); await page.click('button:has-text("Pronostics VIP")'); await page.waitForTimeout(300);
ok((await txt()).includes('Historique des résultats VIP'.toLowerCase()), 'Admin voit le VIP');
await page.click('text=Se déconnecter'); await page.waitForTimeout(300);
await page.evaluate(() => (location.hash = '/pronostics')); await page.click('button:has-text("Pronostics VIP")'); await page.waitForTimeout(300);
ok((await txt()).includes('Activer l\'aperçu VIP'.toLowerCase()), 'Visiteur : VIP verrouillé');
await page.screenshot({ path: out + '/vip.png' });
// Mobile
const m = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true });
const mp = await m.newPage(); mp.on('pageerror', (e) => errors.push('MOBILE ' + e.message));
await mp.goto(url + '#/matchs'); await mp.waitForSelector('text=Championnats disponibles');
const overflow = await mp.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
ok(overflow <= 1, `Mobile : pas de scroll horizontal (${overflow}px)`);
await mp.click('button[aria-label="Menu"]'); await mp.waitForTimeout(300);
await mp.screenshot({ path: out + '/mobile.png' });
ok(errors.length === 0, 'Aucune erreur JS ' + JSON.stringify(errors));
await browser.close();
