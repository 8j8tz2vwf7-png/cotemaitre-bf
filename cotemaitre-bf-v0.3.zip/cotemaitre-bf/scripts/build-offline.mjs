// Compilation sans Vite ni accès réseau : esbuild (JS) + moteur Tailwind v4 (CSS).
// Produit dist-offline/index.html : un fichier unique, ouvrable directement.
// Utilisation :  TOOLS=/chemin/vers/node_modules [VITE_SUPABASE_URL=… VITE_SUPABASE_ANON_KEY=…] node scripts/build-offline.mjs
// Sortie : dist-offline/index.html. Aucune clé privée n'est jamais lue ici (seules les variables VITE_* publiques sont injectées).
// (Sur votre machine, préférez `npm run build` avec Vite.)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { assertPublicEnv } from './lib/assert-public-env.mjs';

assertPublicEnv(process.env);   // refuse de compiler si un secret est dans une variable VITE_* (publique)

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const tools = process.env.TOOLS || path.join(root, 'node_modules');
const imp = (p) => import(pathToFileURL(path.join(tools, p)).href);

const esbuild = await imp('esbuild/lib/main.js');
const { compile } = await imp('tailwindcss/dist/lib.mjs');

// 1) JS
const js = await esbuild.build({
  entryPoints: [path.join(root, 'src/main.tsx')],
  bundle: true, write: false, minify: true, format: 'iife', target: 'es2020',
  jsx: 'automatic', nodePaths: [tools], logLevel: 'warning',
  // Comme Vite : seules les variables PUBLIQUES VITE_* sont injectées dans le navigateur (valeurs figées à la compilation).
  define: {
    'process.env.NODE_ENV': '"production"',
    'import.meta.env.VITE_SUPABASE_URL': JSON.stringify(process.env.VITE_SUPABASE_URL ?? ''),
    'import.meta.env.VITE_SUPABASE_ANON_KEY': JSON.stringify(process.env.VITE_SUPABASE_ANON_KEY ?? ''),
    'import.meta.env.VITE_FORCE_DEMO': JSON.stringify(process.env.VITE_FORCE_DEMO ?? ''),
  },
  loader: { '.css': 'empty' },
});
const jsCode = js.outputFiles[0].text;

// 2) CSS : on extrait les candidats de classes des sources, puis Tailwind génère le CSS.
const srcFiles = [];
(function walk(d) {
  for (const f of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, f.name);
    if (f.isDirectory()) walk(p);
    else if (/\.(tsx?|html)$/.test(f.name)) srcFiles.push(p);
  }
})(path.join(root, 'src'));
srcFiles.push(path.join(root, 'index.html'));
const candidates = new Set();
for (const f of srcFiles) for (const t of fs.readFileSync(f, 'utf8').split(/[\s"'`<>={}(),;]+/)) if (t) candidates.add(t);

const input = fs.readFileSync(path.join(root, 'src/index.css'), 'utf8');
const compiler = await compile(input, {
  base: path.join(root, 'src'),
  loadStylesheet: async (id, base) => {
    const file = id === 'tailwindcss' ? path.join(tools, 'tailwindcss/index.css') : path.resolve(base, id);
    return { path: file, base: path.dirname(file), content: fs.readFileSync(file, 'utf8') };
  },
});
const rawCss = compiler.build([...candidates]);
const css = (await esbuild.transform(rawCss, { loader: 'css', minify: true })).code;

// 3) HTML unique
let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8')
  .replace('<script type="module" src="/src/main.tsx"></script>', '')
  .replace('<!--INLINE_CSS-->', () => `<style>${css}</style>`)
  .replace('<!--INLINE_JS-->', () => `<script>${jsCode.replace(/<\/script/gi, '<\\/script')}</script>`);
fs.mkdirSync(path.join(root, 'dist-offline'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist-offline/index.html'), html);
console.log(`OK dist-offline/index.html — JS ${(jsCode.length / 1024).toFixed(0)} Ko, CSS ${(css.length / 1024).toFixed(0)} Ko`);
