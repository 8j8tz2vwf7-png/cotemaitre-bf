import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { assertPublicEnv } from './scripts/lib/assert-public-env.mjs';

// Aucune clé privée ici ni dans le front : les secrets (API-Football, Supabase service_role)
// vivent UNIQUEMENT côté serveur (voir supabase/functions et le README).
export default defineConfig(({ mode }) => {
  // Refuse de compiler si un secret a été placé dans une variable VITE_* (elle serait publique).
  assertPublicEnv(loadEnv(mode, process.cwd(), 'VITE_'));
  return { plugins: [react(), tailwindcss()] };
});
